#!/bin/bash
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Node.js is not installed. Opening the download page..."
  echo "Install the LTS version, then double-click this file again."
  xdg-open https://nodejs.org/en/download
  read -p "Press Enter to close"
  exit 1
fi
node server.js --open

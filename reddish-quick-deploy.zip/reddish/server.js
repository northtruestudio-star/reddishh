// Reddish — a private Reddit where every other user is an AI.
// Run: node server.js   (Node 18+, no npm install needed)
const http = require('http');
const fs = require('fs');
const path = require('path');
const os = require('os');
const crypto = require('crypto');
const { exec } = require('child_process');

const [major] = process.versions.node.split('.').map(Number);
if (major < 18) { console.error('Reddish needs Node.js 18 or newer. Get it from https://nodejs.org'); process.exit(1); }

const DB = require('./lib/db');
const U = require('./lib/util');
const P = require('./lib/prompts');
const S = require('./lib/safety');
const AI = require('./lib/ai');
const Seed = require('./lib/seed');
const Sim = require('./lib/sim');
const Describe = require('./lib/describe');
const News = require('./lib/news');
const Evolve = require('./lib/evolve');
const Avatars = require('./lib/avatars');
const Groups = require('./lib/groups');
const Drama = require('./lib/drama');
const Vault = require('./lib/vault');
const PG = require('./lib/prompt-guide');
const Claim = require('./lib/claim');
const Deeds = require('./lib/deeds');
const Naming = require('./lib/naming');
const Keyholder = require('./lib/keyholder');
const Cuck = require('./lib/cuck');
const Trance = require('./lib/trance');
const RateHim = require('./lib/ratehim');
const Museum = require('./lib/museum');
const Sissy = require('./lib/sissy');
const Obj = require('./lib/object');
const Orgasm = require('./lib/orgasm');
const Safeword = require('./lib/safeword');
AI.setNote(() => [Naming.note(), Keyholder.note(), Cuck.note(), require('./lib/sissy').note(), require('./lib/object').note()].filter(Boolean).join('\n'));
const Images = require('./lib/images');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC = path.join(__dirname, 'public');

// ---------- data ----------
if (!DB.load()) {
  const { subs, personas } = Seed.build();
  DB.set({
    version: 1,
    meta: { created: Date.now(), lastTick: 0, newCrowd: true, girlNames: true, women90: true, doms56: true },
    config: {
      setupDone: false, pinHash: '', salt: crypto.randomBytes(8).toString('hex'), tokens: [],
      providers: [], modelChain: [],
      speed: 1, activity: 1.6, paused: false, tzOffset: 330,
      threats: true, threatIntensity: 3, dms: true, dmsPerDay: 4,
      maxCallsPerHour: 400, catchupCap: 60,
    },
    library: [],
    me: { username: '', karma: 1, created: Date.now(), votes: {}, bans: {}, warnings: {}, removals: {}, modmailMuted: {} },
    subs, personas,
    posts: [], comments: [], messages: [], notifications: [], reports: [], queue: [],
  });
  DB.flush();
}
const d = () => DB.get();

// fill in settings added in newer versions
const DEFAULTS = {
  image: { kind: 'none', baseUrl: '', apiKey: '', model: '', size: '768x1024', steps: 25, cfg: 6, maxPerHour: 30 },
  vision: { provider: '', model: '' },
  spend: 'balanced', imageSource: 'both', imagePostRate: 0.7, imageWomenShare: 0.7, dmPhotos: true, libraryReuse: true,
  autoDescribe: true, maxDescribesPerHour: 120,
  evolve: true, evolveRate: 1, maxSubs: 40, maxUsers: 300, autoAvatars: true, dares: true, groups: true, contracts: true,
  strangers: true, strangersPerDay: 4, vault: true, taskIntensity: 2, claims: true, claimSpots: 'chest 800, stomach 1000, lower back 1200, hips 1500, lower abdomen 2500, inner thigh 3000', claimBold: 'butt 5000, just above the crotch 7000, private parts 15000', deeds: true, deedParts: 'shaft 25000, balls 20000', naming: true, keyholder: true, cuck: false, cuckPerDay: 4, rateHim: true, rateDemands: 4, sissy: false, sissyMen: true, sissyTrainPerDay: 2, sissyUsesPerDay: 3, sissyTasks: 'walk in heels around the room for 10 minutes, then a pic; practise a curtsy and send it; paint your toenails pink; lipstick on and a kiss print on paper; write "I am a good girl" 50 times; sit down to pee all day and report; pose like a girl in your panties; shave your legs; do your makeup and send a selfie; wear your panties to sleep and send a morning pic', objectMode: false, objectMute: false, objectPhrases: 'yes, yes ma\'am, yes sir, thank you, it obeys, sorry, please, it is ready', orgasm: true, orgasmsPerMonth: 4, museum: true, poses: 'balls lifted up for the camera, legs spread wide, on all fours, ass spread open, licking his own nipple, lying back with legs up, bent over the bed, kneeling with hands behind his head, squatting, her name written on him and on display',
};
for (const [k, v] of Object.entries(DEFAULTS)) if (d().config[k] === undefined) d().config[k] = v;
// the Vault and its burner accounts
if (d().config.setupDone) { try { Vault.ensurePeople(); } catch (e) { console.error('[vault]', e.message); } }
if (!d().library) d().library = [];
// one-time: older installs started on "Normal", which felt dead
// the old 150/hour cap starved a busy site
if (!d().meta.budget400) { if (Number(d().config.maxCallsPerHour) === 150) d().config.maxCallsPerHour = 400; d().meta.budget400 = true; }
if (!d().meta.livelier) { if (Number(d().config.activity) === 1) d().config.activity = 1.6; d().meta.livelier = true; }
// big-sub illusion: displayed member counts include lurkers
for (const s of d().subs) if (!s.displayMembers) s.displayMembers = Math.round(Math.max(20, s.members.length) * U.rand(180, 900));
for (const p of d().personas) if (!p.look && p.archetype !== 'authority') p.look = Seed.makeLook(p.gender, p.age);
// add the moral police and counter-arguers to existing worlds (once)
// more women with real Indian first-name handles (once): rename women who haven't posted anything yet,
// and bring in 30 new women spread across the subs
if (!d().meta.girlNames) {
  const taken = new Set(d().personas.map(p => p.username.toLowerCase()));
  const active = new Set([...d().posts.map(p => p.author), ...d().comments.map(c => c.author), ...d().messages.map(m => m.from), ...(d().library || []).map(x => x.persona)]);
  for (const p of d().personas) {
    if (p.gender !== 'F' || active.has(p.id) || p.deleted || p.archetype === 'authority' || U.chance(0.15)) continue;
    taken.delete(p.username.toLowerCase());
    p.username = Seed.username(taken, 'F');
  }
  const arch = { thirsty: 4, wholesome: 4, gooner: 2, troll: 2, creep: 1, edgelord: 1, moralpolice: 2, contrarian: 2, psychopath: 1 };
  for (let i = 0; i < 30; i++) {
    let p;
    do { p = Seed.makePersona(U.weighted(Object.keys(arch), k => arch[k]), taken); } while (p.gender !== 'F' && (taken.delete(p.username.toLowerCase()) || true));
    const subs = U.shuffle(d().subs.filter(s => !s.archived)).slice(0, U.randi(2, 5));
    p.subs = subs.map(s => s.name);
    subs.forEach(s => s.members.push(p.id));
    d().personas.push(p);
  }
  d().meta.girlNames = true;
}
// 90% women with all kinds of ages (once): users with no history yet become women with new
// handles, looks and ages; then new women join until the site is ~90% women
if (!d().meta.women90) {
  const taken = new Set(d().personas.map(p => p.username.toLowerCase()));
  const active = new Set([...d().posts.map(p => p.author), ...d().comments.map(c => c.author), ...d().messages.map(m => m.from), ...(d().library || []).map(x => x.persona)]);
  const live = () => d().personas.filter(p => !p.deleted && p.archetype !== 'authority');
  for (const p of live()) {
    if (active.has(p.id) || (p.modOf || []).length || p.threatStage > 0) continue;
    p.age = Seed.makeAge();
    if (p.gender !== 'F' && U.chance(0.92)) {
      p.gender = 'F';
      taken.delete(p.username.toLowerCase());
      p.username = Seed.username(taken, 'F');
    }
    p.look = Seed.makeLook(p.gender, p.age);
    p.bio = `${p.age}${p.gender === 'NB' ? '' : p.gender}, ${p.occupation}, ${p.city}.`;
  }
  // men who've barely said anything "delete their account" (their few comments show as [deleted], like on Reddit)
  const count = {};
  for (const x of [...d().posts, ...d().comments]) count[x.author] = (count[x.author] || 0) + 1;
  for (const p of live()) {
    if (p.gender === 'F' || (p.modOf || []).length || p.threatStage > 0 || (d().library || []).some(x => x.persona === p.id) || d().messages.some(m => m.from === p.id)) continue;
    if ((count[p.id] || 0) <= 4 && U.chance(0.85)) p.deleted = true;
  }
  const arch = { thirsty: 4, wholesome: 4, gooner: 2, troll: 2, creep: 1, edgelord: 1, moralpolice: 2, contrarian: 2, psychopath: 1 };
  let guard = 0;
  while (live().filter(p => p.gender === 'F').length / live().length < 0.9 && guard++ < 90) {
    const p = Seed.makePersona(U.weighted(Object.keys(arch), k => arch[k]), taken, 'F');
    const subs = U.shuffle(d().subs.filter(s => !s.archived)).slice(0, U.randi(2, 5));
    p.subs = subs.map(s => s.name);
    subs.forEach(s => s.members.push(p.id));
    d().personas.push(p);
  }
  d().meta.women90 = true;
}
// doms join until there are ~56 (40 women, 16 men)
if (!d().meta.doms56) {
  const taken = new Set(d().personas.map(p => p.username.toLowerCase()));
  const subs = d().subs.filter(s => !s.archived);
  for (const [arch, g, n] of Seed.DOMS) {
    const have = d().personas.filter(p => !p.deleted && p.archetype === arch).length;
    for (let i = have; i < n; i++) {
      const p = Seed.makeDom(arch, g, taken);
      const mine = U.shuffle(subs).slice(0, U.randi(2, 5));
      p.subs = mine.map(s => s.name);
      mine.forEach(s => s.members.push(p.id));
      d().personas.push(p);
    }
  }
  d().meta.doms56 = true;
}
if (!d().meta.newCrowd) {
  const taken = new Set(d().personas.map(p => p.username.toLowerCase()));
  for (const [arch, n] of [['moralpolice', 9], ['contrarian', 9]]) {
    for (let i = 0; i < n; i++) {
      const p = Seed.makePersona(arch, taken);
      const subs = U.shuffle(d().subs).slice(0, U.randi(3, 6));
      p.subs = subs.map(s => s.name);
      subs.forEach(s => s.members.push(p.id));
      d().personas.push(p);
    }
  }
  d().meta.newCrowd = true;
}
for (const p of d().personas) if (!p.lang) p.lang = p.archetype === 'authority' ? 'english' : Seed.pickLang();
DB.save();

function saveDataUrl(dataUrl, dir, prefix = 'img') {
  const mm = /^data:image\/(png|jpe?g|gif|webp);base64,(.+)$/.exec(dataUrl || '');
  if (!mm) throw new Error('Unsupported image type (use jpg, png, gif or webp)');
  const ext = mm[1] === 'jpeg' ? 'jpg' : mm[1];
  const name = U.id(prefix) + '.' + ext;
  fs.writeFileSync(path.join(dir, name), Buffer.from(mm[2], 'base64'));
  return name;
}

// ---------- helpers ----------
const hash = pin => crypto.createHash('sha256').update(d().config.salt + String(pin)).digest('hex');
function cookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach(c => { const i = c.indexOf('='); if (i > 0) out[c.slice(0, i).trim()] = decodeURIComponent(c.slice(i + 1).trim()); });
  return out;
}
function authed(req) {
  const c = d().config;
  if (!c.pinHash) return false;
  return c.tokens.includes(cookies(req).rd_token);
}
function newToken(res) {
  const t = crypto.randomBytes(24).toString('hex');
  d().config.tokens = [...d().config.tokens.slice(-9), t];
  DB.save();
  res.setHeader('Set-Cookie', `rd_token=${t}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Lax`);
}
function send(res, code, obj) {
  const body = JSON.stringify(obj);
  res.writeHead(code, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(body);
}
function readBody(req, limit = 15 * 1024 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0;
    const chunks = [];
    req.on('data', c => { size += c.length; if (size > limit) { reject(new Error('Too large')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => { try { resolve(chunks.length ? JSON.parse(Buffer.concat(chunks).toString('utf8')) : {}); } catch { reject(new Error('Bad JSON')); } });
    req.on('error', reject);
  });
}
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.gif': 'image/gif', '.webp': 'image/webp', '.webmanifest': 'application/manifest+json', '.mp4': 'video/mp4', '.m4v': 'video/mp4', '.webm': 'video/webm', '.mov': 'video/quicktime' };
const VIDEO_EXT = new Set(['.mp4', '.m4v', '.webm', '.mov']);
const mediaTypeOf = f => (VIDEO_EXT.has(path.extname(String(f)).toLowerCase()) ? 'video' : /\.gif$/i.test(String(f)) ? 'gif' : 'image');
// videos are streamed with Range support: phones (iPhones especially) won't play them otherwise
function serveFile(res, file, req) {
  const type = MIME[path.extname(file).toLowerCase()] || 'application/octet-stream';
  if (type.startsWith('video/')) {
    let st;
    try { st = fs.statSync(file); } catch { res.writeHead(404); return res.end('Not found'); }
    const range = /bytes=(\d*)-(\d*)/.exec(req?.headers?.range || '');
    if (range) {
      let start = range[1] === '' ? Math.max(0, st.size - Number(range[2])) : Number(range[1]);
      let end = range[1] !== '' && range[2] !== '' ? Math.min(Number(range[2]), st.size - 1) : st.size - 1;
      if (start >= st.size || start > end) { res.writeHead(416, { 'Content-Range': `bytes */${st.size}` }); return res.end(); }
      res.writeHead(206, { 'Content-Type': type, 'Content-Range': `bytes ${start}-${end}/${st.size}`, 'Accept-Ranges': 'bytes', 'Content-Length': end - start + 1, 'Cache-Control': 'no-cache' });
      return fs.createReadStream(file, { start, end }).pipe(res);
    }
    res.writeHead(200, { 'Content-Type': type, 'Content-Length': st.size, 'Accept-Ranges': 'bytes', 'Cache-Control': 'no-cache' });
    return fs.createReadStream(file).pipe(res);
  }
  fs.readFile(file, (err, data) => {
    if (err) { res.writeHead(404); return res.end('Not found'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
}

// ---------- view models ----------
const authorInfo = aid => {
  if (aid === 'me') return { name: d().me.username, me: true, mark: Claim.badge(), deeds: Deeds.owned(), alias: Naming.alias(), item: Obj.view().enabled ? Obj.label() : null, sissy: Sissy.view().enabled ? Sissy.view().name : null };
  const p = Sim.persona(aid);
  return { name: !p || p.deleted ? '[deleted]' : p.username, deleted: !p || p.deleted, id: p?.id, mod: false, fame: p && !p.deleted ? p.fame || 0 : 0, role: p && !p.deleted ? p.role || '' : '' };
};
function postView(p, full = false) {
  const mine = p.author === 'me';
  const a = authorInfo(p.author);
  const s = Sim.sub(p.sub);
  if (s && p.author !== 'me' && s.mods.includes(p.author)) a.mod = true;
  return {
    id: p.id, sub: p.sub, title: p.removed && !mine ? '[removed]' : p.title,
    body: p.removed && !mine ? '' : full ? p.body : (p.body || '').slice(0, 400),
    shot: p.removed && !mine ? null : p.shot || null,
    demand: p.demand ? { status: p.demand.status, due: p.demand.due, answer: p.demand.answer || null } : null, rated: p.rated ? { avg: p.rated.avg || null, n: p.rated.scores.length, late: !!p.rated.late } : null,
    image: p.removed && !mine ? null : p.image, mediaType: p.image ? p.mediaType || mediaTypeOf(p.image) : null, created: p.created, score: p.score, comments: p.comments || 0,
    author: a, mine, removed: p.removed, removedReason: mine ? p.removedReason : undefined, myVote: d().me.votes[p.id] || 0,
  };
}
function commentView(c) {
  const mine = c.author === 'me';
  const a = authorInfo(c.author);
  const post = d().posts.find(p => p.id === c.postId);
  const s = post && Sim.sub(post.sub);
  if (s && !mine && s.mods.includes(c.author)) a.mod = true;
  return {
    id: c.id, postId: c.postId, parentId: c.parentId, created: c.created, score: c.score,
    body: c.removed && !mine ? '[removed by moderator]' : c.body, author: a, mine, removed: c.removed,
    removedReason: mine ? c.removedReason : undefined, myVote: d().me.votes[c.id] || 0, image: c.image || null, claim: c.claim || null, rating: c.rating || null,
  };
}
// fresher posts rise fast, like a busy subreddit's front page
function hot(p, now) { return (Math.sign(p.score) * Math.log10(Math.max(1, Math.abs(p.score))) + Math.log10(1 + (p.comments || 0)) * 0.6) - (now - p.created) / (4 * 3600e3); }
function unread() {
  return {
    notifs: d().notifications.filter(n => !n.read).length,
    msgs: d().messages.filter(m => m.from !== 'me' && !m.read).length,
  };
}
function threadTitle(id) {
  if (id.startsWith('mod:')) return { name: `r/${id.slice(4)} mods`, kind: 'mod' };
  if (id.startsWith('g:')) { const g = Groups.info(id.slice(2)); return g ? { ...g, deleted: g.dead && !g.meIn } : { name: 'group', kind: 'group', deleted: true }; }
  const p = Sim.persona(id);
  return { name: p ? (p.deleted ? '[deleted]' : p.username) : '[deleted]', kind: 'dm', blocked: p?.blocked, deleted: !p || p.deleted };
}
function maskedProviders() {
  return d().config.providers.map(p => ({ ...p, apiKey: p.apiKey ? '••••' + p.apiKey.slice(-4) : '' }));
}
function safeConfig() {
  const { pinHash, salt, tokens, providers, ...rest } = d().config;
  return rest;
}

// ---------- the Now feed: everything waiting on you, soonest first ----------
const rsx = n => '₹' + Math.round(n).toLocaleString('en-IN');
function nowFeed() {
  const now = Date.now();
  const items = [];
  const name = id => Sim.persona(id)?.username || '?';
  const add = it => items.push(it);
  try {
    const cv = Claim.view();
    if (cv.phase === 'active') {
      const n = cv.cur.next;
      if (n && !n.done) add({ id: 'proof', icon: '📸', title: `${{ opening: 'Opening proof', checkin: 'Check-in proof', retake: 'Retake', buyout: 'Buyout proof' }[n.kind] || 'Proof'} due`, sub: `one photo showing all ${cv.cur.marks.length} names`, due: n.due, action: 'proof', link: '#/claim' });
      add({ id: 'marks', icon: '🖊️', title: `${cv.cur.marks.length} name${cv.cur.marks.length === 1 ? '' : 's'} on you · ${rsx(cv.cur.total)}`, sub: cv.cur.marks.slice(0, 3).map(m => `${m.spot}: ${m.write}`).join(' · '), due: cv.cur.end, info: true, link: '#/claim' });
    } else if (cv.phase === 'auction') add({ id: 'auction', icon: '🔨', title: `Your body is being auctioned · ${rsx(cv.total)} so far`, sub: 'watch the bids', due: cv.closes, info: true, link: '#/claim' });
    for (const p of Deeds.view().parts) if (p.sale) add({ id: 'deed-' + p.part, icon: '📜', title: `Your ${p.part} is for sale${p.sale.top ? ` · ${rsx(p.sale.top.amount)} top bid` : ''}`, sub: p.sale.seller ? `u/${p.sale.seller} is selling` : 'first sale', due: p.sale.closes, info: true, link: '#/claim' });
  } catch {}
  for (const m of d().messages) {
    if (!m.task || m.task.status !== 'open' || m.from === 'me') continue;
    const g = m.thread.startsWith('g:');
    add({ id: 'task-' + m.id, icon: m.task.statement ? '📝' : m.task.ultimatum ? '⚠️' : '🎯', title: m.task.text, sub: g ? `in ${Groups.info(m.thread.slice(2))?.name || 'a group'}` : `from u/${name(m.from)}${m.task.extendAsked && !m.task.extendDecided ? ' · begged for time' : ''}`, due: m.task.due || 0, action: m.task.kind === 'photo' ? 'chatPhoto' : 'chat', link: '#/dm/' + encodeURIComponent(m.thread), msgId: m.id, canMore: !!(m.task.due && !m.task.extendAsked && !m.task.statement) });
  }
  for (const m of d().messages) if (m.notice && ['open', 'pleading', 'penalty'].includes(m.notice.status)) add({ id: 'notice-' + m.notice.id, icon: '🚔', title: `${{ intimation: 'Intimation', fir: 'FIR', seizure: 'Seizure order', complaint: 'Complaint', warrant: 'Warrant' }[m.notice.kind] || 'Notice'} · fine ${m.notice.fine} karma`, sub: `case ${m.notice.caseNo}${m.notice.status === 'penalty' ? ' · statement owed' : ''}`, due: m.notice.due, action: m.notice.status === 'penalty' ? 'chat' : 'pay', noticeId: m.notice.id, fine: m.notice.fine, link: '#/dm/' + m.thread });
  for (const m of d().messages) if (m.contract && m.contract.status === 'pending') add({ id: 'contract-' + m.id, icon: '📜', title: `u/${name(m.contract.from)} sent you a slave agreement`, sub: 'read it, then sign or decline', due: 0, action: 'chat', link: '#/dm/' + m.thread });
  try { for (const r of RateHim.card().open) add({ id: 'rate-' + r.id, icon: '📏', title: r.title, sub: `u/${r.by} demands a pic · r/RateHim`, due: r.due, action: 'ratePhoto', postId: r.id, link: '#/post/' + r.id }); } catch {}
  const kh = Keyholder.view().cur;
  if (kh) add({ id: 'key', icon: '🔑', title: `Locked by u/${kh.holder} · ${kh.days < 1 ? `${Math.max(0, Math.round(kh.days * 24))}h in` : `day ${Math.floor(kh.days) + 1}`}`, sub: kh.pending ? 'waiting for her answer…' : 'ask before you finish. every time.', due: 0, action: kh.pending ? null : 'ask', link: '#/hub', keyholder: true });
  const nm = Naming.active();
  if (nm) add({ id: 'name', icon: '🏷️', title: `You're "${nm.alias}" right now`, sub: `u/${nm.byName} paid ${rsx(nm.price)}`, due: nm.until, info: true, link: '#/hub' });
  for (const [key, label] of [['naming', '🏷️ Your naming rights'], ['keyholder', '🔑 Your keyholder rights']]) { const v = key === 'naming' ? Naming.view().sale : Keyholder.view().sale; if (v) add({ id: 'sale-' + key, icon: label.slice(0, 2), title: `${label.slice(3)} are up for auction${v.top ? ` · ${rsx(v.top.amount)}` : ''}`, sub: 'watch the bids', due: v.closes, info: true, link: '#/post/' + v.postId }); }
  const st = Drama.status();
  if (st.state === 'suspended') add({ id: 'susp', icon: '⛔', title: 'Your account is suspended', sub: st.suspendReason || '', due: st.suspendedUntil, info: true, link: '#/owned' });
  const unreadThreads = new Set(d().messages.filter(m => m.from !== 'me' && !m.read).map(m => m.thread));
  if (unreadThreads.size) add({ id: 'unread', icon: '💬', title: `${unreadThreads.size} chat${unreadThreads.size === 1 ? '' : 's'} waiting for you`, sub: [...unreadThreads].slice(0, 3).map(t => threadTitle(t)).join(', '), due: 0, info: true, link: '#/inbox/messages' });
  const act = items.filter(i => !i.info), info = items.filter(i => i.info);
  const byDue = (a, b) => (a.due || 9e15) - (b.due || 9e15);
  return { items: [...act.sort(byDue), ...info.sort(byDue)], urgent: act.filter(i => !i.due || i.due - now < 3 * 3600e3).length, now };
}
function hubData() {
  const cv = Claim.view();
  const own = Drama.owned();
  return {
    claim: { phase: cv.phase, total: cv.phase === 'auction' ? cv.total : cv.cur?.total || 0, names: cv.cur?.marks?.length || 0, end: cv.cur?.end || cv.closes || cv.nextOpen || 0 },
    deeds: Deeds.view().parts.map(p => ({ part: p.part, owner: p.owner, price: p.price, sale: !!p.sale })),
    naming: Naming.view(), keyholder: Keyholder.view(), cuck: Cuck.view(), trances: Trance.list(),
    owned: { owners: own.owners.length, tasks: own.owners.reduce((a, o) => a + o.tasks.length, 0) + own.other.length, cases: own.cases.length },
    vault: d().posts.filter(p => p.sub === Vault.NAME && !p.removed && (p.leak || p.bounty)).slice(-2).reverse().map(p => ({ id: p.id, title: p.title })),
    proofs: proofGallery().slice(0, 6),
    rate: RateHim.card(),
    sissy: Sissy.view(), item: Obj.view(), orgasm: Orgasm.view(),
    museum: (() => { const m = Museum.view(); return { enabled: m.enabled, count: m.exhibits.length, latest: m.exhibits[0] ? { title: m.exhibits[0].title, image: m.exhibits[0].image } : null, waiting: m.waiting }; })(),
  };
}
// photos you sent that closed a task, newest first
function proofGallery() {
  const out = [];
  const msgs = d().messages;
  for (let i = 0; i < msgs.length; i++) {
    const m = msgs[i];
    if (!m.task || m.task.status !== 'done' || m.from === 'me') continue;
    const pic = msgs.slice(i + 1).find(x => x.thread === m.thread && x.from === 'me' && x.image && x.created >= m.created && x.created - m.created < 86400e3 * 2);
    if (pic) out.push({ image: pic.image, by: Sim.persona(m.from)?.username || 'the group', task: m.task.text, at: pic.created, link: '#/dm/' + encodeURIComponent(m.thread) });
  }
  for (const h of (d().claim?.hall || [])) if (h.photo) out.push({ image: h.photo, by: 'body auction #' + h.n, task: `${h.marks?.length || 0} names`, at: h.end, link: '#/claim' });
  return out.sort((a, b) => b.at - a.at).slice(0, 60);
}
// one-tap modes
const PRESETS = {
  chill: { sissy: false, objectMode: false, threats: false, strangers: false, vault: false, claims: false, deeds: false, naming: false, keyholder: false, cuck: false, contracts: false, dares: true, groups: true, taskIntensity: 1 },
  spicy: { threats: true, threatIntensity: 2, strangers: true, strangersPerDay: 3, vault: true, claims: true, deeds: false, naming: true, keyholder: false, cuck: false, contracts: true, dares: true, groups: true, taskIntensity: 2 },
  brutal: { threats: true, threatIntensity: 3, strangers: true, strangersPerDay: 8, vault: true, claims: true, deeds: true, naming: true, keyholder: true, contracts: true, dares: true, groups: true, taskIntensity: 3 },
  owned: { threats: true, threatIntensity: 2, strangers: true, strangersPerDay: 2, vault: true, claims: true, deeds: true, naming: true, keyholder: true, contracts: true, dares: true, groups: true, taskIntensity: 3 },
  sissy: { sissy: true, sissyMen: true, objectMode: true, orgasm: true, cuck: true, rateHim: true, museum: true, keyholder: true, naming: true, contracts: true, dares: true, groups: true, threats: true, threatIntensity: 2, strangers: true, strangersPerDay: 2, vault: true, claims: true, deeds: true, taskIntensity: 3 },
  cuck: { cuck: true, cuckPerDay: 6, threats: true, threatIntensity: 2, strangers: true, strangersPerDay: 2, vault: true, claims: true, deeds: true, naming: true, keyholder: true, contracts: true, dares: true, groups: true, taskIntensity: 2 },
};
function applyPreset(name) {
  const p = PRESETS[name];
  if (!p) throw new Error('Unknown mode');
  const c = d().config;
  Object.assign(c, p);
  c.preset = name;
  c.paused = false;
  if (name === 'owned' && !d().personas.some(x => x.contract) && !d().messages.some(m => m.contract && m.contract.status === 'pending')) {
    const dom = U.pick(d().personas.filter(x => !x.deleted && ['domme', 'dom'].includes(x.archetype)));
    if (dom) Sim.schedule('contract_offer', Date.now() + 60e3, { pid: dom.id });
  }
  if (name === 'cuck') { try { Cuck.ensureBulls(); } catch {} }
  DB.save();
  return safeConfig();
}

// ---------- routes ----------
const routes = [];
const route = (method, pattern, fn, opts = {}) => routes.push({ method, re: new RegExp('^' + pattern.replace(/:(\w+)/g, '(?<$1>[^/]+)') + '$'), fn, ...opts });

route('GET', '/api/status', () => ({ setup: d().config.setupDone }), { open: true });
let fails = 0, lockUntil = 0;
route('POST', '/api/login', async (req, res, b) => {
  if (Date.now() < lockUntil) throw new Error('Too many tries. Wait a minute.');
  if (!d().config.pinHash || hash(b.pin) !== d().config.pinHash) {
    if (++fails >= 5) { lockUntil = Date.now() + 60e3; fails = 0; }
    throw new Error('Wrong PIN');
  }
  fails = 0;
  newToken(res);
  return { ok: true };
}, { open: true });
route('POST', '/api/setup', async (req, res, b) => {
  const c = d().config;
  if (c.setupDone) throw new Error('Already set up');
  const name = String(b.username || '').trim();
  if (!/^[A-Za-z0-9_-]{3,20}$/.test(name)) throw new Error('Username: 3–20 letters, numbers, _ or -');
  if (d().personas.some(p => p.username.toLowerCase() === name.toLowerCase())) throw new Error('That username is taken');
  if (!/^\d{4,8}$/.test(String(b.pin || ''))) throw new Error('PIN: 4–8 digits');
  d().me.username = name;
  d().me.created = Date.now();
  c.pinHash = hash(b.pin);
  c.setupDone = true;
  d().meta.lastTick = Date.now();
  Sim.Admin.backfill(12); // so the site isn't empty on day one
  newToken(res);
  return { ok: true };
}, { open: true });

route('GET', '/api/base', () => ({
  me: { username: d().me.username, karma: d().me.karma },
  subs: d().subs.filter(s => !s.vault).map(s => ({ name: s.name, title: s.title, members: s.displayMembers || s.members.length, online: s.archived ? 0 : onlineNow(s), born: s.born || 0, archived: !!s.archived, origin: s.origin || '' })),
  online: d().subs.reduce((a, s) => a + onlineNow(s), 0),
  aiReady: AI.ready(), aiProblem: aiProblem(), unread: unread(), paused: d().config.paused,
}));
function aiProblem() {
  const recent = AI.log.filter(l => Date.now() - l.at < 15 * 60e3 && !/vision|describe/.test(l.tag || ''));
  if (!recent.length || recent.some(l => l.ok)) return null;
  return recent[0].err;
}
// "online now": lurkers scale with the sub size, the hour of night and the activity setting
function onlineNow(s) {
  const h = U.localHour(Date.now(), d().config.tzOffset ?? 330);
  const wobble = 1 + Math.sin(Date.now() / 600e3 + s.name.length) * 0.08;
  if (s.archived) return Math.round((s.displayMembers || 50) * 0.001);
  return Math.max(3, Math.round((s.displayMembers || 500) * 0.014 * Sim.HOUR_W[h] * (Number(d().config.activity) || 1) * wobble));
}
function latest() {
  const n = d().notifications.find(x => !x.read);
  const m = [...d().messages].reverse().find(x => x.from !== 'me' && !x.read);
  return {
    notif: n ? { id: n.id, text: n.text, link: n.link } : null,
    msg: m ? { id: m.id, thread: m.thread, from: Sim.authorName(m.from), text: m.body ? m.body.slice(0, 90) : '📷 Photo' } : null,
  };
}
route('GET', '/api/poll', () => ({ nowCount: nowFeed().urgent, aiProblem: aiProblem(), version: d().version, unread: unread(), karma: d().me.karma, aiReady: AI.ready(), subsCount: d().subs.length, throttled: Sim.throttled(), latest: latest(), newestPost: d().posts.reduce((m, p) => (!p.removed && p.created <= Date.now() && p.created > m ? p.created : m), 0), online: d().subs.reduce((a, s) => a + onlineNow(s), 0) }));

route('GET', '/api/feed', (req) => {
  const q = new URL(req.url, 'http://x').searchParams;
  const subName = q.get('sub');
  const sort = q.get('sort') || 'hot';
  const now = Date.now();
  let posts = d().posts.filter(p => !p.removed || p.author === 'me');
  if (subName) posts = posts.filter(p => p.sub === subName);
  else posts = posts.filter(p => p.sub !== Vault.NAME && p.sub !== RateHim.SUB && p.sub !== Museum.SUB);
  if (sort === 'new') posts = posts.sort((a, b) => b.created - a.created);
  else if (sort === 'top') posts = posts.filter(p => now - p.created < 7 * 86400e3).sort((a, b) => b.score - a.score);
  else posts = posts.sort((a, b) => hot(b, now) - hot(a, now));
  const out = { posts: posts.slice(0, 60).map(p => postView(p)) };
  if (subName) {
    const s = Sim.sub(subName);
    if (!s) throw new Error('No such sub');
    out.sub = { vault: !!s.vault, name: s.name, title: s.title, description: s.description, rules: s.rules, members: s.displayMembers || s.members.length, online: onlineNow(s), born: s.born || 0, origin: s.origin || '', archived: !!s.archived, founder: s.founder ? Sim.authorName(s.founder) : '', mods: s.mods.map(id => Sim.authorName(id)) };
    const ban = d().me.bans[s.name];
    if (ban) out.ban = { until: ban.until, reason: ban.reason };
  }
  return out;
});

route('GET', '/api/post/:id', (req, res, b, m) => {
  const p = d().posts.find(x => x.id === m.id);
  if (!p) throw new Error('Post not found');
  const s = Sim.sub(p.sub);
  return {
    post: postView(p, true),
    comments: d().comments.filter(c => c.postId === p.id).map(commentView),
    sub: { name: s.name, title: s.title },
    ban: d().me.bans[p.sub] ? { reason: d().me.bans[p.sub].reason, until: d().me.bans[p.sub].until } : null,
  };
});

// GIFs and videos are sent as the raw file (not re-encoded) and streamed straight to disk
const UPLOAD_EXT = new Set(['gif', 'mp4', 'm4v', 'webm', 'mov', 'jpg', 'jpeg', 'png', 'webp']);
route('POST', '/api/upload', (req) => new Promise((resolve, reject) => {
  const ext = String(new URL(req.url, 'http://x').searchParams.get('ext') || '').toLowerCase().replace('jpeg', 'jpg');
  if (!UPLOAD_EXT.has(ext)) return reject(new Error('That file type isn\'t supported. Use a photo, GIF, MP4, MOV or WEBM.'));
  const name = U.id('up') + '.' + ext;
  const file = path.join(DB.UPLOADS, name);
  const out = fs.createWriteStream(file);
  let size = 0;
  const LIMIT = 300 * 1024 * 1024;
  req.on('data', c => { size += c.length; if (size > LIMIT) { req.destroy(); out.destroy(); fs.unlink(file, () => {}); reject(new Error('Files over 300 MB are too big')); } });
  req.pipe(out);
  out.on('finish', () => (size ? resolve({ path: '/uploads/' + name, type: mediaTypeOf(name) }) : (fs.unlink(file, () => {}), reject(new Error('Empty file')))));
  out.on('error', reject);
}), { raw: true });
// media = an /uploads path from /api/upload; image = a data URL (photos); sheet = frames of a GIF/video for the AI
function takeMedia(b) {
  let media = null;
  if (b.media) {
    const f = path.normalize(path.join(DB.UPLOADS, String(b.media).replace(/^\/uploads\//, '')));
    if (!f.startsWith(DB.UPLOADS) || !fs.existsSync(f)) throw new Error('Upload not found, try again');
    media = '/uploads/' + path.basename(f);
  } else if (b.image) media = '/uploads/' + saveDataUrl(b.image, DB.UPLOADS);
  const mediaType = media ? mediaTypeOf(media) : null;
  const sheet = media && mediaType !== 'image' && b.sheet ? '/uploads/' + saveDataUrl(b.sheet, DB.UPLOADS, 'sheet') : null;
  return { image: media, mediaType, sheet };
}
route('POST', '/api/post', async (req, res, b) => {
  if (!String(b.title || '').trim()) throw new Error('Title is required');
  const m = takeMedia(b);
  const p = Sim.Me.post({ sub: b.sub, title: b.title.trim(), body: b.body, ...m });
  return p && p.hushed ? { hushed: true } : postView(p, true);
}, { limit: 40 * 1024 * 1024 });
route('POST', '/api/comment', (req, res, b) => { const c = Sim.Me.comment(b); return c && c.hushed ? { hushed: true } : commentView(c); });
route('POST', '/api/vote', (req, res, b) => Sim.Me.vote(b));
route('POST', '/api/report', (req, res, b) => { Sim.Me.report(b); return { ok: true }; });
route('POST', '/api/delete', (req, res, b) => {
  const list = b.kind === 'post' ? d().posts : d().comments;
  const item = list.find(x => x.id === b.id && x.author === 'me');
  if (!item) throw new Error('Not found');
  if (b.kind === 'post') { item.removed = true; item.removedReason = 'Deleted by you'; }
  else { item.body = '[deleted]'; }
  DB.save();
  return { ok: true };
});

route('GET', '/api/u/:name', (req, res, b, m) => {
  const name = decodeURIComponent(m.name);
  if (name.toLowerCase() === d().me.username.toLowerCase()) {
    const me = d().me;
    return {
      me: true, username: me.username, karma: me.karma, created: me.created, standing: Drama.status(),
      bans: Object.entries(me.bans).map(([sub, x]) => ({ sub, ...x })),
      warnings: me.warnings, removals: me.removals,
      posts: d().posts.filter(p => p.author === 'me').sort((a, b) => b.created - a.created).map(p => postView(p)),
      comments: d().comments.filter(c => c.author === 'me').sort((a, b) => b.created - a.created).slice(0, 50).map(c => ({ ...commentView(c), postTitle: d().posts.find(p => p.id === c.postId)?.title })),
    };
  }
  const p = d().personas.find(x => x.username.toLowerCase() === name.toLowerCase());
  if (!p) throw new Error('User not found');
  if (p.deleted) return { deleted: true, username: '[deleted]' };
  return {
    id: p.id, username: p.username, karma: p.karma, created: p.created, about: p.bio, blocked: p.blocked, fame: p.fame || 0, role: p.role || '', followers: p.followers || 0,
    modOf: p.modOf || [],
    posts: d().posts.filter(x => x.author === p.id && !x.removed).sort((a, b) => b.created - a.created).slice(0, 30).map(x => postView(x)),
    comments: d().comments.filter(x => x.author === p.id && !x.removed).sort((a, b) => b.created - a.created).slice(0, 40).map(c => ({ ...commentView(c), postTitle: d().posts.find(x => x.id === c.postId)?.title })),
  };
});
route('POST', '/api/block', (req, res, b) => { Sim.Me.block(b.id, b.on); return { ok: true }; });

route('GET', '/api/inbox', () => {
  const threads = {};
  const hidden = new Set((d().groups || []).filter(g => !g.meIn && !g.left).map(g => 'g:' + g.id));
  for (const m of d().messages) {
    if (hidden.has(m.thread)) continue;
    const t = threads[m.thread] || (threads[m.thread] = { id: m.thread, ...threadTitle(m.thread), unread: 0 });
    const who = m.thread.startsWith('g:') && m.from !== 'me' && m.from !== 'system' ? Sim.authorName(m.from) + ': ' : '';
    t.last = who + (m.body ? m.body.slice(0, 120) : m.image ? (m.viewOnce ? '📷 View-once photo' : '📷 Photo') : '');
    t.lastFromMe = m.from === 'me';
    t.at = m.created;
    if (m.from !== 'me' && !m.read) t.unread++;
  }
  return { notifications: d().notifications.slice(0, 120), threads: Object.values(threads).sort((a, b) => b.at - a.at), unread: unread() };
});
route('POST', '/api/inbox/read', () => { d().notifications.forEach(n => { n.read = true; }); DB.save(); return { ok: true }; });
route('GET', '/api/thread/:id', (req, res, b, m) => {
  const id = decodeURIComponent(m.id);
  if (id.startsWith('g:')) { const g = (d().groups || []).find(x => 'g:' + x.id === id); if (!g || (!g.meIn && !g.left)) throw new Error('Not found'); }
  const msgs = d().messages.filter(x => x.thread === id);
  let changed = false;
  msgs.forEach(x => { if (!x.read) { x.read = true; changed = true; } });
  if (changed) DB.save();
  const info = threadTitle(id);
  return { id, typing: !id.startsWith('mod:') && Sim.typingSoon(id), online: !id.startsWith('mod:') && Sim.chatOnline(id), ...info, messages: msgs.map(msgView) };
});
// view-once pics: the picture is only handed out when you tap it, and only once
function msgView(x) {
  const once = !!(x.viewOnce && x.from !== 'me');
  return {
    id: x.id, mine: x.from === 'me', author: x.from === 'me' ? d().me.username : x.from === 'system' ? '' : Sim.authorName(x.from), system: x.from === 'system',
    body: x.body, image: once ? null : x.image || null, mediaType: x.image ? x.mediaType || mediaTypeOf(x.image) : null,
    viewOnce: once, viewed: once ? !!x.viewed : undefined, task: x.task || null, contract: x.contract || null, notice: x.notice || null, shot: x.shot || null, muted: x.muted || undefined, trigger: x.from !== 'me' && !x.thread.startsWith('g:') ? Trance.triggers(x.from, x.body) || undefined : undefined, created: x.created, beforeMe: !!x.beforeMe,
  };
}
route('POST', '/api/group/leave', (req, res, b) => { Groups.leave(String(b.id || '').replace(/^g:/, '')); return { ok: true }; });
route('POST', '/api/contract', (req, res, b) => { Drama.answerContract(b.id, !!b.accept); return { ok: true }; });
route('POST', '/api/notice', (req, res, b) => { Drama.noticeAction(b.id, String(b.action)); return { ok: true }; });
route('GET', '/api/owned', () => Drama.owned());
// the Claim ritual
route('GET', '/api/claim', () => ({ ...Claim.view(), deeds: Deeds.view() }));
route('GET', '/api/now', () => nowFeed());
route('GET', '/api/hub', () => hubData());
route('POST', '/api/keyholder/ask', (req, res, b) => (Safeword.check(b.body) ? { hushed: true } : Keyholder.ask(b.body)));
route('POST', '/api/keyholder/slip', () => { Keyholder.slip(); return { ok: true }; });
route('POST', '/api/trance/start', async (req, res, b) => await Trance.create(b.pid, b.theme));
route('GET', '/api/trance/:id', (req, res, b, m) => Trance.get(m.id) || (() => { throw new Error('Session not found'); })());
route('POST', '/api/trance/done', (req, res, b) => Trance.done(b.id, b.depth));
route('POST', '/api/trance/seed-dickless', (req, res, b) => {
  const sess = Trance.seedDickless();
  return { ok: true, id: sess.id, title: sess.title };
});
route('GET', '/api/proofs', () => proofGallery());
route('GET', '/api/rate', () => RateHim.card());
route('GET', '/api/museum', () => Museum.view());
route('GET', '/api/sissy', () => Sissy.view());
route('POST', '/api/sissy/wardrobe', (req, res, b) => Sissy.setWardrobe(b.items));
route('POST', '/api/sissy/name', (req, res, b) => Sissy.setName(b.name));
route('GET', '/api/item', () => Obj.view());
route('POST', '/api/item/label', (req, res, b) => Obj.setLabel(b.label));
route('GET', '/api/orgasm', () => Orgasm.view());
route('POST', '/api/orgasm/beg', async (req, res, b) => { if (Safeword.check(b.reason)) return { hushed: true }; return await Orgasm.beg(b.reason); });
route('POST', '/api/orgasm/session', async () => await Orgasm.session());
route('POST', '/api/orgasm/edge', (req, res, b) => Orgasm.edge(b.id));
route('POST', '/api/orgasm/done', (req, res, b) => Orgasm.sessionDone(b.id));
route('GET', '/api/safeword', () => Safeword.status());
route('POST', '/api/safeword/set', (req, res, b) => Safeword.set(b.word));
route('POST', '/api/safeword/resume', () => Safeword.resume());
route('POST', '/api/safeword/try', (req, res, b) => ({ hushed: Safeword.check(b.text) }));
route('POST', '/api/rate/answer', async (req, res, b) => { const m = takeMedia(b); if (!m.image || m.mediaType !== 'image') throw new Error('Send a photo'); const p = await RateHim.answer(b.postId, m.image); return { id: p.id }; }, { limit: 40 * 1024 * 1024 });
route('POST', '/api/admin/preset', (req, res, b) => applyPreset(String(b.name)));
route('POST', '/api/claim/proof', async (req, res, b) => { const m = takeMedia(b); if (!m.image || m.mediaType !== 'image') throw new Error('Send a photo'); return await Claim.submitProof(m.image); }, { limit: 40 * 1024 * 1024 });
route('POST', '/api/claim/pause', () => { Claim.pause(); return { ok: true }; });

// task card buttons: beg for more time, or refuse outright
route('POST', '/api/task', (req, res, b) => {
  const m = d().messages.find(x => x.id === b.msgId && x.task);
  if (!m || m.task.status !== 'open') throw new Error('This task is already closed');
  const now = Date.now();
  const gid = m.thread.startsWith('g:') ? m.thread.slice(2) : null;
  const p = gid ? null : Sim.persona(m.thread);
  if (b.action === 'more') {
    if (m.task.extendAsked) throw new Error('You already begged once');
    m.task.extendAsked = now;
    const body = String(b.body || '').trim() || '🙏 please thoda aur time de do… I\'ll do it, promise';
    if (gid) { d().messages.push({ id: U.id('m'), thread: m.thread, from: 'me', to: 'group', body, created: now, read: true }); m.task.due = (m.task.due || now) + 2 * 3600e3 / Math.max(0.1, d().config.speed || 1); m.task.extendDecided = 'granted'; Groups.myMessage(gid, body, now); }
    else if (p) { Sim.Me.dm({ to: p.id, body }); }
  } else if (b.action === 'refuse') {
    m.task.status = 'failed'; m.task.closed = now; m.task.refused = true;
    Sim.taskClosed(m.task, 'failed', m.from);
    const body = String(b.body || '').trim() || 'nahi karunga. ✋';
    if (gid) { d().messages.push({ id: U.id('m'), thread: m.thread, from: 'me', to: 'group', body, created: now, read: true }); Groups.missedTask(gid, m.task.text, now); Groups.myMessage(gid, body, now); }
    else if (p) {
      p.tasks = p.tasks || { done: 0, failed: 0 }; p.tasks.failed++;
      Sim.remember(p, `u/${d().me.username} flat out refused your task "${m.task.text}"`);
      p.hostility = Math.min(10, p.hostility + 1);
      Sim.Me.dm({ to: p.id, body });
      if (p.contract) Drama.breach(p, m.task.text + ' (refused)', now);
      else if (m.task.ultimatum) Drama.ultimatumMissed(p, m.task.text, now);
    }
  } else throw new Error('Unknown action');
  DB.save();
  return { ok: true };
});
route('POST', '/api/viewonce', (req, res, b) => {
  const x = d().messages.find(m => m.id === b.id && m.viewOnce);
  if (!x) throw new Error('Not found');
  if (x.viewed) throw new Error('Already opened');
  x.viewed = Date.now();
  DB.save();
  return { image: x.image, mediaType: x.mediaType || mediaTypeOf(x.image) };
});
route('POST', '/api/dm', (req, res, b) => {
  const r = Sim.Me.dm({ to: b.to, body: b.body, ...takeMedia(b) });
  return r && r.hushed ? { ok: true, hushed: true } : { ok: true };
}, { limit: 40 * 1024 * 1024 });

// ---------- settings ----------
const maskedImage = () => ({ ...d().config.image, apiKey: d().config.image.apiKey ? '••••' + d().config.image.apiKey.slice(-4) : '' });
route('GET', '/api/settings', () => ({ providers: maskedProviders(), modelChain: d().config.modelChain, presets: AI.PRESETS, image: maskedImage(), vision: d().config.vision }));
route('POST', '/api/settings', (req, res, b) => {
  const c = d().config;
  if (Array.isArray(b.providers)) {
    c.providers = b.providers.map(p => {
      const old = c.providers.find(x => x.id === p.id);
      return { id: p.id || U.id('pr'), name: String(p.name || 'Provider'), baseUrl: String(p.baseUrl || '').trim(), apiKey: String(p.apiKey || '').startsWith('••••') ? (old?.apiKey || '') : String(p.apiKey || '').trim() };
    });
  }
  if (b.image) {
    const old = c.image;
    c.image = {
      kind: ['none', 'sd', 'openai'].includes(b.image.kind) ? b.image.kind : 'none',
      baseUrl: String(b.image.baseUrl || '').trim(), model: String(b.image.model || '').trim(), size: String(b.image.size || '768x1024'),
      steps: Number(b.image.steps) || 25, cfg: Number(b.image.cfg) || 6, sampler: String(b.image.sampler || ''), maxPerHour: Number(b.image.maxPerHour) || 30,
      apiKey: String(b.image.apiKey || '').startsWith('••••') ? old.apiKey : String(b.image.apiKey || '').trim(),
    };
  }
  if (b.vision) c.vision = { provider: String(b.vision.provider || ''), model: String(b.vision.model || '').trim() };
  if (Array.isArray(b.modelChain)) c.modelChain = b.modelChain.filter(m => m.provider && m.model).map(m => ({ provider: m.provider, model: String(m.model).trim(), enabled: m.enabled !== false }));
  DB.save();
  return { providers: maskedProviders(), modelChain: c.modelChain, image: maskedImage(), vision: c.vision };
});
route('POST', '/api/test-image', async () => {
  const url = await Images.generate(Images.adultPrompt(28, 'amateur smartphone photo of a cup of masala chai on a rainy Mumbai windowsill, realistic'), { tag: 'test image' });
  return { url };
});
route('POST', '/api/models', async (req, res, b) => {
  const p = d().config.providers.find(x => x.id === b.provider);
  if (!p) throw new Error('Save the provider first');
  return { models: await AI.listModels(p) };
});
// one-click: check the key, load the models, and fill in sensible defaults
route('POST', '/api/connect', async (req, res, b) => {
  const c = d().config;
  const p = c.providers.find(x => x.id === b.provider);
  if (!p) throw new Error('Save the provider first');
  if (!p.baseUrl) throw new Error('This provider has no address. Fill in the URL (it usually ends in /v1).');
  const models = await AI.listModels(p);
  const rec = AI.recommend(models);
  const out = { models: models.length, text: rec.text, vision: rec.vision, addedText: false, setVision: false };
  if (rec.text && b.cheapest) {
    // swap this provider's models for the cheapest one, keep the others as backups
    c.modelChain = [{ provider: p.id, model: rec.text, enabled: true }, ...c.modelChain.filter(m => m.provider !== p.id)];
    out.addedText = true;
  } else if (rec.text && !c.modelChain.some(m => m.provider === p.id)) {
    c.modelChain.push({ provider: p.id, model: rec.text, enabled: true });
    out.addedText = true;
  }
  // vision: keep a current vision model only if it really works; otherwise try this key's models until one can see
  let visionOk = false;
  if (!b.cheapest && c.vision && c.vision.model && c.providers.some(x => x.id === c.vision.provider)) {
    const vp = c.providers.find(x => x.id === c.vision.provider);
    try { await AI.testVision(vp, c.vision.model); visionOk = true; out.vision = c.vision.model; } catch {}
  }
  if (!visionOk) {
    const cands = AI.visionCandidates(models);
    if (rec.text && !cands.includes(rec.text)) cands.push(rec.text);
    out.vision = '';
    for (const m of cands.slice(0, 6)) {
      try { await AI.testVision(p, m); c.vision = { provider: p.id, model: m }; out.vision = m; out.setVision = true; break; }
      catch (e) { out.visionError = e.message; }
    }
  }
  DB.save();
  if (rec.text) {
    try { out.test = await AI.test(p, rec.text); }
    catch (e) { out.testError = e.message; }
  }
  return out;
});
route('POST', '/api/test-vision', async (req, res, b) => {
  const p = d().config.providers.find(x => x.id === b.provider);
  if (!p) throw new Error('Pick a provider for vision');
  if (!b.model) throw new Error('Enter a vision model id');
  return AI.testVision(p, b.model);
});
route('POST', '/api/test-model', async (req, res, b) => {
  const p = d().config.providers.find(x => x.id === b.provider);
  if (!p) throw new Error('Pick a provider for this model');
  if (!b.model) throw new Error('Enter a model id');
  return AI.test(p, b.model);
});
route('POST', '/api/pin', (req, res, b) => {
  if (hash(b.old) !== d().config.pinHash) throw new Error('Current PIN is wrong');
  if (!/^\d{4,8}$/.test(String(b.pin || ''))) throw new Error('PIN: 4–8 digits');
  d().config.pinHash = hash(b.pin);
  d().config.tokens = [];
  newToken(res);
  return { ok: true };
});

// ---------- admin ----------
route('GET', '/api/admin', () => ({
  news: News.status(),
  usage: AI.usageToday(),
  config: safeConfig(), stats: Sim.stats(), log: AI.log.slice(0, 80),
  me: d().me, counts: { posts: d().posts.length, comments: d().comments.length, messages: d().messages.length, personas: d().personas.length },
  threats: d().personas.filter(p => p.threatStage > 0 || p.hostility >= 3).map(p => ({ id: p.id, username: p.username, archetype: p.archetype, hostility: p.hostility, attraction: p.attraction, stage: p.threatStage, deleted: p.deleted, altOf: p.altOf ? Sim.authorName(p.altOf) : null })),
}));
route('POST', '/api/admin/config', (req, res, b) => {
  const c = d().config;
  const allowed = ['speed', 'activity', 'paused', 'threats', 'threatIntensity', 'dms', 'dmsPerDay', 'maxCallsPerHour', 'catchupCap', 'tzOffset', 'imagePostRate', 'imageWomenShare', 'dmPhotos', 'libraryReuse', 'autoDescribe', 'maxDescribesPerHour', 'describeParallel', 'evolve', 'evolveRate', 'maxSubs', 'maxUsers', 'autoAvatars', 'dares', 'groups', 'contracts', 'strangers', 'strangersPerDay', 'vault', 'taskIntensity', 'claims', 'deeds', 'naming', 'keyholder', 'cuck', 'cuckPerDay', 'rateHim', 'rateDemands', 'museum', 'sissy', 'sissyMen', 'sissyTrainPerDay', 'sissyUsesPerDay', 'objectMode', 'objectMute', 'orgasm', 'orgasmsPerMonth'];
  if (['saver', 'balanced', 'max'].includes(b.spend)) c.spend = b.spend;
  if ('trending' in b) c.trending = String(b.trending).slice(0, 3000);
  if ('news' in b) { c.news = !!b.news; if (c.news) News.refresh(); }
  for (const k of allowed) if (k in b) c[k] = typeof c[k] === 'boolean' ? !!b[k] : Number(b[k]);
  if (['both', 'library', 'generate'].includes(b.imageSource)) c.imageSource = b.imageSource;
  for (const k of ['claimSpots', 'claimBold', 'deedParts', 'poses', 'sissyTasks', 'objectPhrases']) if (k in b) { const v = String(b[k] || '').slice(0, 600); if (S.isBlocked(v)) throw new Error(S.USER_MESSAGE); c[k] = v; }
  DB.save();
  return safeConfig();
});
// ---------- profile picture pool ----------
route('GET', '/api/admin/avatars', () => ({
  status: Avatars.status(),
  items: (d().avatarPool || []).slice().reverse().slice(0, 600).map(x => ({ ...x, url: '/avatar-pool/' + x.file.split('/').map(encodeURIComponent).join('/'), who: x.assigned ? Sim.authorName(x.assigned) : '' })),
}));
route('POST', '/api/admin/avatars/upload', (req, res, b) => {
  let n = 0;
  for (const f of b.files || []) { Avatars.add(saveDataUrl(f.data, Avatars.DIR, 'pfp'), b.gender); n++; }
  DB.save();
  return { added: n };
}, { limit: 60 * 1024 * 1024 });
route('POST', '/api/admin/avatars/scan', () => Avatars.scan());
route('POST', '/api/admin/avatars/assign', (req, res, b) => ({ assigned: Avatars.assign({ reshuffle: !!b.reshuffle }), status: Avatars.status() }));
route('POST', '/api/admin/avatars/clear', () => { for (const x of d().avatarPool || []) Avatars.unassign(x); DB.save(); return Avatars.status(); });
route('POST', '/api/admin/avatars/delete', (req, res, b) => { Avatars.remove(b.ids || []); return Avatars.status(); });
route('POST', '/api/admin/avatars/gender', (req, res, b) => {
  const x = (d().avatarPool || []).find(y => y.id === b.id);
  if (!x) throw new Error('Not found');
  x.gender = ['F', 'M'].includes(b.gender) ? b.gender : '';
  if (x.assigned) { const p = Sim.persona(x.assigned); if (p && p.gender !== x.gender && x.gender) Avatars.unassign(x); }
  DB.save();
  return { ok: true };
});

route('GET', '/api/admin/history', () => ({ history: (d().history || []).slice(0, 300) }));
route('GET', '/api/admin/prompts', () => ({ prompts: P.get(), defaults: P.DEFAULTS, locked: S.PREAMBLE, guide: PG.guide().map(({ current, default: _d, ...g }) => g), sections: PG.SECTIONS, drop: PG.DROP }));
// the fill-in file: download it, fill "new" (yourself or with another AI), import it back
route('GET', '/api/admin/prompts/fillfile', (req, res) => {
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Disposition': 'attachment; filename="reddish-prompts-fill.json"' });
  res.end(JSON.stringify(PG.fillFile(), null, 2));
  return null;
});
route('POST', '/api/admin/prompts/import', (req, res, b) => PG.applyFill(b.file), { limit: 4 * 1024 * 1024 });
route('POST', '/api/admin/prompts', (req, res, b) => {
  const walk = o => Object.values(o).every(v => (v && typeof v === 'object' ? walk(v) : !S.isBlocked(v)));
  if (!walk(b.prompts || {})) throw new Error(S.USER_MESSAGE);
  return { prompts: P.set(b.prompts) };
});
route('GET', '/api/admin/personas', () => ({ personas: d().personas, subs: d().subs.map(s => s.name), archetypes: Object.keys(P.get().archetypes), styles: Seed.STYLES }));
route('POST', '/api/admin/persona', (req, res, b) => {
  const x = b.persona || {};
  const textFields = ['username', 'bio', 'custom', 'style', 'occupation', 'city', 'look'];
  if (textFields.some(f => S.isBlocked(x[f])) || (x.quirks || []).some(q => S.isBlocked(q))) throw new Error(S.USER_MESSAGE);
  if (x.age !== undefined && Number(x.age) < 18) throw new Error('Every persona must be 18 or older.');
  let p = x.id && Sim.persona(x.id);
  const name = String(x.username || '').trim();
  if (name && d().personas.some(o => o.username.toLowerCase() === name.toLowerCase() && o.id !== x.id)) throw new Error('Username taken');
  if (name && name.toLowerCase() === d().me.username.toLowerCase()) throw new Error('That is your username');
  if (!p) {
    p = Seed.newPersona({ username: name || Seed.username(new Set(d().personas.map(o => o.username.toLowerCase()))) });
    d().personas.push(p);
  }
  const num = ['age', 'karma', 'hostility', 'attraction', 'threatStage'];
  for (const k of ['username', 'age', 'gender', 'city', 'occupation', 'archetype', 'bio', 'style', 'look', 'lang', 'quirks', 'activeHours', 'karma', 'custom', 'hostility', 'attraction', 'threatStage', 'modStyle', 'blocked', 'deleted']) {
    if (!(k in x)) continue;
    p[k] = num.includes(k) ? Number(x[k]) : x[k];
  }
  p.age = Math.max(18, p.age);
  if (Array.isArray(x.subs)) {
    for (const s of d().subs) {
      const want = x.subs.includes(s.name);
      const has = s.members.includes(p.id);
      if (want && !has) s.members.push(p.id);
      if (!want && has) s.members = s.members.filter(id => id !== p.id);
    }
    p.subs = x.subs;
  }
  if (Array.isArray(x.modOf)) {
    for (const s of d().subs) {
      const want = x.modOf.includes(s.name);
      const has = s.mods.includes(p.id);
      if (want && !has) { s.mods.push(p.id); if (!s.members.includes(p.id)) s.members.push(p.id); }
      if (!want && has) s.mods = s.mods.filter(id => id !== p.id);
    }
    p.modOf = x.modOf;
  }
  DB.save();
  return { persona: p };
});
route('GET', '/api/admin/sub/:name', (req, res, b, m) => {
  const s = Sim.sub(decodeURIComponent(m.name));
  if (!s) throw new Error('No such sub');
  return { sub: { ...s, members: s.members.length, mods: s.mods.map(id => Sim.authorName(id)) } };
});
route('POST', '/api/admin/sub', (req, res, b) => {
  const x = b.sub || {};
  if (['name', 'title', 'description', 'tone', 'promptExtra'].some(f => S.isBlocked(x[f])) || (x.rules || []).some(r => S.isBlocked(r) && !/no minors/i.test(r))) throw new Error(S.USER_MESSAGE);
  let s = d().subs.find(o => o.name === x.originalName || o.name === x.name);
  if (!s) {
    if (!/^[A-Za-z0-9_]{3,21}$/.test(x.name || '')) throw new Error('Sub name: 3–21 letters, numbers or _');
    s = { name: x.name, title: x.name, description: '', tone: '', rules: ['18+ only', 'No minors, ever'], postsPerDay: 6, reportThreshold: 2, members: [], mods: [], promptExtra: '', paused: false, displayMembers: U.randi(4000, 20000) };
    d().subs.push(s);
    // seed members: pick ~25 random personas
    U.shuffle(d().personas.filter(p => !p.deleted && p.archetype !== 'authority')).slice(0, 25).forEach(p => { s.members.push(p.id); p.subs.push(s.name); });
    s.mods = s.members.slice(0, 2);
  }
  for (const k of ['title', 'description', 'tone', 'promptExtra']) if (k in x) s[k] = String(x[k]);
  if (Array.isArray(x.rules)) s.rules = x.rules.filter(Boolean);
  for (const k of ['postsPerDay', 'reportThreshold']) if (k in x) s[k] = Number(x[k]);
  if ('paused' in x) s.paused = !!x.paused;
  DB.save();
  return { sub: s };
});
route('POST', '/api/admin/action', async (req, res, b) => {
  const me = d().me;
  switch (b.action) {
    case 'calm': Sim.Admin.calm(); break;
    case 'forcePost': Sim.Admin.forcePost(b.sub, b.pid); break;
    case 'forceDM': Sim.Admin.forceDM(b.pid); break;
    case 'escalate': Sim.Admin.escalate(b.pid); break;
    case 'runDue': Sim.Admin.runDueNow(); break;
    case 'clearQueue': Sim.Admin.clearQueue(); break;
    case 'backfill': Sim.Admin.backfill(Math.min(50, Number(b.n) || 10)); break;
    case 'unban': if (b.sub) delete me.bans[b.sub]; else me.bans = {}; break;
    case 'clearWarnings': me.warnings = {}; me.removals = {}; me.modmailMuted = {}; Drama.clearStanding(); break;
    case 'setKarma': me.karma = Number(b.karma) || 0; break;
    case 'restore': { const it = (b.kind === 'post' ? d().posts : d().comments).find(x => x.id === b.id); if (it) { it.removed = false; delete it.removedReason; } break; }
    case 'newsRefresh': await News.refresh(); break;
    case 'groupNow': await Groups.forceCreate(); break;
    case 'dommeNow': Groups.createDomme(); break;
    case 'contractNow': {
      const pool = d().personas.filter(p => !p.deleted && !p.blocked && ['domme', 'dom'].includes(p.archetype) && !p.contract && !p.contractOffered);
      const p = U.pick(pool);
      if (!p) throw new Error('Nobody available to send one');
      await Drama.offerContract(p, Date.now());
      if (!p.contractOffered) throw new Error('The AI didn\'t write a usable agreement. Try again.');
      break;
    }
    case 'breachNow': {
      const p = d().personas.find(x => x.contract && !x.deleted);
      if (!p) throw new Error('You have no signed agreement. Get one and accept it first.');
      await Drama.breach(p, 'ignored her orders', Date.now());
      break;
    }
    case 'claimOpen': await Claim.force('open'); break;
    case 'claimNext': await Claim.force('next'); break;
    case 'claimEnd': await Claim.force('end'); break;
    case 'namingSell': if (!Naming.sell()) throw new Error('A rename is running or already for sale.'); break;
    case 'keySell': Keyholder.force('sell'); break;
    case 'cuckNow': Cuck.force(); break;
    case 'rateNow': await RateHim.force(); break;
    case 'dressNow': await Sissy.force('dress'); break;
    case 'useNow': await Sissy.force('use'); break;
    case 'finishNow': await Sissy.force('finish'); break;
    case 'showNow': await Sissy.force('show'); break;
    case 'bukkakeNow': await Sissy.force('bukkake'); break;
    case 'furnitureNow': Obj.force('furniture'); break;
    case 'museumNow': if (!(await Museum.curate(true))) throw new Error("The curator didn't write a usable plaque. Try again."); break;
    case 'deedSell': Deeds.force('sell'); break;
    case 'deedNext': await Deeds.force('next'); break;
    case 'vaultLeak': await Vault.force('leak'); break;
    case 'vaultBounty': await Vault.force('bounty'); break;
    case 'strangerNow': Vault.force('stranger'); break;
    case 'ownedList': Vault.force('owned'); break;
    case 'clearStanding': Drama.clearStanding(); break;
    case 'addMeNow': await Groups.forceAdd(); break;
    case 'evolveNow': await Evolve.forceCycle(); break;
    case 'newSubNow': if (!(await Evolve.forceSub())) throw new Error("Nothing dramatic enough is happening yet to start a sub. Let the site run a bit, or try again."); break;
    case 'resetPersona': { const p = Sim.persona(b.pid); if (p) { p.hostility = 0; p.attraction = 0; p.threatStage = 0; p.memory = []; d().queue = d().queue.filter(e => !(e.data.pid === p.id && ['threat', 'dm'].includes(e.type))); } break; }
    default: throw new Error('Unknown action');
  }
  DB.save();
  setTimeout(Sim.tick, 50);
  return { ok: true };
});


// ---------- image library ----------
const libView = x => ({ ...x, mediaType: mediaTypeOf(x.file), url: Describe.libUrl(x), thumbUrl: x.thumb ? '/library/' + x.thumb : null, personaName: x.persona ? Sim.authorName(x.persona) : null });
route('GET', '/api/admin/library', () => ({
  items: d().library.map(libView).reverse(),
  personas: d().personas.filter(p => !p.deleted && p.archetype !== 'authority').map(p => ({ id: p.id, username: p.username, gender: p.gender })).sort((a, b) => a.username.localeCompare(b.username)),
  visionReady: !!(d().config.vision && d().config.vision.model),
  folder: DB.LIBRARY,
  describe: Describe.status(),
}));
route('POST', '/api/admin/library/upload', (req, res, b) => {
  const added = [];
  for (const f of b.files || []) {
    let file;
    if (f.media) {
      // a GIF/video already streamed up via /api/upload: move it into the library
      const src = path.normalize(path.join(DB.UPLOADS, String(f.media).replace(/^\/uploads\//, '')));
      if (!src.startsWith(DB.UPLOADS) || !fs.existsSync(src)) continue;
      file = 'lib-' + path.basename(src);
      try { fs.renameSync(src, path.join(DB.LIBRARY, file)); } catch { fs.copyFileSync(src, path.join(DB.LIBRARY, file)); fs.unlinkSync(src); }
    } else file = saveDataUrl(f.data, DB.LIBRARY, 'lib');
    const item = { id: U.id('l'), file, desc: '', needsThumb: mediaTypeOf(file) !== 'image', gender: ['F', 'M', 'NB'].includes(b.gender) ? b.gender : '', persona: b.persona || null, used: 0, hidden: false, added: Date.now() };
    d().library.push(item);
    added.push(libView(item));
  }
  DB.save();
  return { added };
}, { limit: 60 * 1024 * 1024 });
route('POST', '/api/admin/library/update', (req, res, b) => {
  const ids = new Set(b.ids || []);
  if (b.desc !== undefined && S.isBlocked(b.desc)) throw new Error(S.USER_MESSAGE);
  for (const x of d().library) {
    if (!ids.has(x.id)) continue;
    if (b.desc !== undefined) { x.desc = String(b.desc); x.descEdited = !!x.desc; }
    if (b.persona !== undefined) x.persona = b.persona || null;
    if (b.gender !== undefined) x.gender = b.gender;
    if (b.hidden !== undefined) x.hidden = !!b.hidden;
    if (b.resetUsed) x.used = 0;
  }
  DB.save();
  return { ok: true };
});
route('POST', '/api/admin/library/delete', (req, res, b) => {
  const ids = new Set(b.ids || []);
  for (const x of d().library.filter(y => ids.has(y.id))) { for (const f of [x.file, x.thumb]) if (f) { try { fs.unlinkSync(path.join(DB.LIBRARY, f)); } catch {} } }
  d().library = d().library.filter(x => !ids.has(x.id));
  DB.save();
  return { ok: true };
});

// scan data/library for files dropped in by hand. A subfolder = one person's set.
// Folder names starting with f_ / m_ / nb_ mark the gender (e.g. f_priya, m_rohan).
const IMG_EXT = new Set(['.jpg', '.jpeg', '.png', '.webp', '.gif', '.mp4', '.m4v', '.webm', '.mov']);
route('POST', '/api/admin/library/scan', () => {
  const known = new Set(d().library.map(x => x.file));
  const found = new Set();
  let added = 0, skipped = 0;
  const walk = (dir, set) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      if (e.name.startsWith('.')) continue;
      const full = path.join(dir, e.name);
      if (e.isDirectory()) { if (!set) walk(full, e.name); continue; }
      if (!IMG_EXT.has(path.extname(e.name).toLowerCase())) { if (/\.(heic|heif|avif|bmp|tiff?)$/i.test(e.name)) skipped++; continue; }
      const rel = path.relative(DB.LIBRARY, full).split(path.sep).join('/');
      found.add(rel);
      if (known.has(rel)) continue;
      const g = set && /^(f|m|nb)[_-]/i.exec(set);
      const sibling = set && d().library.find(x => x.set === set && x.persona);
      let big = false;
      try { big = fs.statSync(full).size > Describe.MAX_BYTES; } catch {}
      if (mediaTypeOf(full) !== 'image') big = true; // GIFs and videos need a frame sheet made in the browser
      d().library.push({ id: U.id('l'), file: rel, set: set || '', desc: '', gender: g ? g[1].toUpperCase() : '', persona: sibling ? sibling.persona : null, used: 0, hidden: false, needsThumb: big, added: Date.now() });
      added++;
    }
  };
  walk(DB.LIBRARY, '');
  const before = d().library.length;
  d().library = d().library.filter(x => found.has(x.file));
  DB.save();
  return { added, skipped, removed: before - d().library.length, total: d().library.length, folder: DB.LIBRARY };
});
route('POST', '/api/admin/library/describe', async (req, res, b) => Describe.describeLibrary(b.ids || []));
route('GET', '/api/admin/library/status', () => Describe.status());
route('POST', '/api/admin/library/retry', () => { Describe.retryFailed(); return Describe.status(); });
// re-read every photo with the current (better) reader; auto-describe works through them in the background
route('POST', '/api/admin/library/redescribe', () => {
  for (const x of d().library) if (!x.hidden && !x.descEdited) { x.desc = ''; x.descFailed = false; x.tries = 0; }
  DB.save();
  return Describe.status();
});
// the browser shrinks oversized photos and sends a copy back; it's only used for the vision model
route('POST', '/api/admin/library/thumb', (req, res, b) => {
  const x = d().library.find(y => y.id === b.id);
  if (!x) throw new Error('Image not found');
  const dir = path.join(DB.LIBRARY, '.thumbs');
  fs.mkdirSync(dir, { recursive: true });
  const name = saveDataUrl(b.data, dir, 'th');
  if (x.thumb) { try { fs.unlinkSync(path.join(DB.LIBRARY, x.thumb)); } catch {} }
  x.thumb = '.thumbs/' + name;
  x.needsThumb = false; x.tries = 0; x.descFailed = false;
  DB.save();
  return { ok: true };
}, { limit: 12 * 1024 * 1024 });
route('GET', '/api/admin/library/needs-thumb', () => ({ items: d().library.filter(x => x.needsThumb && !x.hidden).map(x => ({ id: x.id, url: Describe.libUrl(x), type: mediaTypeOf(x.file) })) }));

// ---------- profile pictures ----------
// Drawn locally (lib/avatar.js): works offline, same face for the same username.
// To use your own picture for anyone, drop <username>.jpg/.png into data/avatars.
const Avatar = require('./lib/avatar');
const AV_DIR = path.join(DB.DIR, 'avatars');
fs.mkdirSync(AV_DIR, { recursive: true });
function serveAvatar(res, rawName) {
  let name;
  try { name = decodeURIComponent(rawName); } catch { name = rawName; }
  const safe = name.replace(/[^\w-]/g, '').slice(0, 40);
  if (!safe) { res.writeHead(404); return res.end(); }
  for (const ext of ['jpg', 'jpeg', 'png', 'webp']) {
    const own = path.join(AV_DIR, `${safe}.${ext}`);
    if (fs.existsSync(own)) return serveFile(res, own);
  }
  const isMe = safe.toLowerCase() === d().me.username.toLowerCase();
  const p = isMe ? null : d().personas.find(x => x.username === name);
  if (!isMe && !p) { res.writeHead(404); return res.end(); }
  if (p && p.avatar) {
    const f = path.normalize(path.join(Avatars.DIR, p.avatar));
    if (f.startsWith(Avatars.DIR) && fs.existsSync(f)) return serveFile(res, f, null);
  }
  res.writeHead(200, { 'Content-Type': 'image/svg+xml', 'Cache-Control': 'no-cache' });
  if (p && p.burner) return res.end(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><rect width="100" height="100" fill="#0d0b10"/><path d="M50 22c-17 0-28 9-28 24 0 18 13 32 28 32s28-14 28-32c0-15-11-24-28-24z" fill="#e8e4ec"/><path d="M33 47c4-5 11-5 15 0-4 4-11 4-15 0zM52 47c4-5 11-5 15 0-4 4-11 4-15 0z" fill="#0d0b10"/><path d="M42 64q8 5 16 0" stroke="#0d0b10" stroke-width="2.5" fill="none" stroke-linecap="round"/></svg>`);
  res.end(Avatar.svg(safe, p?.gender || 'NB'));
}

// ---------- server ----------
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, 'http://localhost');
  const p = decodeURIComponent(url.pathname);
  try {
    if (p.startsWith('/api/')) {
      const r = routes.find(x => x.method === req.method && x.re.test(p));
      if (!r) return send(res, 404, { error: 'Not found' });
      if (!r.open && !authed(req)) return send(res, 401, { error: 'Login required' });
      const body = req.method === 'POST' && !r.raw ? await readBody(req, r.limit) : {};
      const out = await r.fn(req, res, body, p.match(r.re).groups || {});
      if (res.headersSent) return;
      return send(res, 200, out ?? { ok: true });
    }
    if (p.startsWith('/avatar-pool/')) {
      if (!authed(req)) { res.writeHead(401); return res.end(); }
      const f = path.normalize(path.join(Avatars.DIR, p.slice(13)));
      if (!f.startsWith(Avatars.DIR)) { res.writeHead(403); return res.end(); }
      return serveFile(res, f, req);
    }
    if (p.startsWith('/shot/')) { // a chat screenshot, drawn as an image
      if (!authed(req)) { res.writeHead(401); return res.end(); }
      const svg = require('./lib/shots').render(p.slice(6).replace(/\.svg$/, ''), d().me.username);
      if (!svg) { res.writeHead(404); return res.end(); }
      res.writeHead(200, { 'Content-Type': 'image/svg+xml; charset=utf-8', 'Cache-Control': 'private, max-age=86400' });
      return res.end(svg);
    }
    if (p.startsWith('/avatar/')) {
      if (!authed(req)) { res.writeHead(401); return res.end(); }
      return serveAvatar(res, p.slice(8));
    }
    if (p.startsWith('/uploads/') || p.startsWith('/library/')) {
      if (!authed(req)) { res.writeHead(401); return res.end(); }
      const root = p.startsWith('/library/') ? DB.LIBRARY : DB.UPLOADS;
      const f = path.normalize(path.join(root, p.replace(/^\/(library|uploads)\//, '')));
      if (!f.startsWith(root)) { res.writeHead(403); return res.end(); }
      return serveFile(res, f, req);
    }
    const file = path.normalize(path.join(PUBLIC, p === '/' ? 'index.html' : p));
    if (!file.startsWith(PUBLIC)) { res.writeHead(403); return res.end(); }
    if (!fs.existsSync(file)) return serveFile(res, path.join(PUBLIC, 'index.html'));
    serveFile(res, file);
  } catch (e) {
    send(res, 400, { error: e.message || 'Error' });
  }
});

// home Wi-Fi addresses first; skip virtual adapters (WSL, VirtualBox, Docker, VPNs) that phones can't reach
function lanIPs() {
  const out = [];
  for (const [name, list] of Object.entries(os.networkInterfaces())) {
    for (const i of list || []) {
      if (i.family !== 'IPv4' || i.internal) continue;
      const virtual = /vethernet|wsl|virtualbox|vmware|docker|hyper-v|vbox|utun|tailscale|zerotier|loopback|bridge/i.test(name);
      const home = /^192\.168\.|^10\./.test(i.address);
      out.push({ ip: i.address, score: (home ? 2 : 0) + (virtual ? -3 : 0) + (/wi-?fi|wlan|en0|eth|ethernet/i.test(name) ? 1 : 0) });
    }
  }
  return out.sort((a, b) => b.score - a.score).filter((x, i) => i === 0 || x.score >= 0).map(x => x.ip);
}

server.listen(PORT, '0.0.0.0', () => {
  console.log('\n  Reddish is running.\n');
  console.log(`  On this computer:  http://localhost:${PORT}`);
  const ips = lanIPs();
  ips.forEach((ip, i) => console.log(`  On your phone:     http://${ip}:${PORT}${i === 0 ? '   ← try this one first (same Wi-Fi)' : ''}`));
  if (ips.length) console.log('\n  Phone can\'t open it? Allow Node.js through the firewall (Windows asks the first time:\n  tick "Private networks"), and make sure the phone is on the same Wi-Fi, not mobile data.');
  console.log('\n  Keep this window open while you use it. Close it to stop.\n');
  Sim.start();
  Describe.start();
  News.start();
  Evolve.start();
  Avatars.start();
  Groups.start();
  Drama.start();
  Vault.start();
  Claim.start();
  Deeds.start();
  Naming.start();
  Keyholder.start();
  Cuck.start();
  RateHim.start();
  Museum.start();
  Sissy.start();
  Obj.start();
  PG.watch(r => Sim.notify('mod', r.error ? `Couldn't import prompts-fill.json: ${r.error}` : `Imported prompts-fill.json: ${r.applied.length} prompt${r.applied.length === 1 ? '' : 's'} updated${r.skipped.length ? `, ${r.skipped.length} skipped` : ''}.`, '#/admin/prompts', Date.now()));
  if (process.argv.includes('--open')) {
    const u = `http://localhost:${PORT}`;
    const cmd = process.platform === 'win32' ? `start "" "${u}"` : process.platform === 'darwin' ? `open "${u}"` : `xdg-open "${u}"`;
    exec(cmd, () => {});
  }
});
server.on('error', e => {
  if (e.code === 'EADDRINUSE') console.error(`Port ${PORT} is busy. Is Reddish already running? Otherwise set PORT=3001 and retry.`);
  else console.error(e);
  process.exit(1);
});

const shutdown = () => { DB.flush(); process.exit(0); };
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
process.on('uncaughtException', e => { console.error('Error:', e.message); });
setInterval(() => DB.flush(), 15000);

/* Reddish front end — plain JS, no build step. */
const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const main = $('#main');
const S = { me: null, subs: [], version: 0, unread: { notifs: 0, msgs: 0 }, aiReady: true, route: '' };
const LS = {
  get(k, d) { try { const v = localStorage.getItem('rd_' + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem('rd_' + k, JSON.stringify(v)); } catch {} },
};

// ---------- utils ----------
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
function md(s) {
  return esc(s)
    .replace(/\*\*(.+?)\*\*/g, '<b>$1</b>')
    .replace(/(^|[^*])\*([^*\n]+)\*/g, '$1<i>$2</i>')
    .replace(/~~(.+?)~~/g, '<s>$1</s>')
    .replace(/(^|\s)(u\/[\w-]+)/g, '$1<a href="#/$2">$2</a>')
    .replace(/(^|\s)r\/(\w+)/g, '$1<a href="#/r/$2">r/$2</a>')
    .replace(/^&gt; ?(.*)$/gm, '<span class="muted">│ $1</span>');
}
function ago(t) {
  const s = Math.max(0, (Date.now() - t) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return Math.floor(s / 60) + 'm';
  if (s < 86400) return Math.floor(s / 3600) + 'h';
  if (s < 86400 * 30) return Math.floor(s / 86400) + 'd';
  if (s < 86400 * 365) return Math.floor(s / 86400 / 30) + 'mo';
  return Math.floor(s / 86400 / 365) + 'y';
}
const fmtN = n => (Math.abs(n) >= 10000 ? (n / 1000).toFixed(0) + 'k' : Math.abs(n) >= 1000 ? (n / 1000).toFixed(1) + 'k' : String(n));
const hue = s => [...String(s)].reduce((a, c) => (a * 31 + c.charCodeAt(0)) % 360, 7);
const I = {
  up: '<svg viewBox="0 0 24 24"><path d="M12 4l7 8h-4v8H9v-8H5z"/></svg>',
  down: '<svg viewBox="0 0 24 24"><path d="M12 20l-7-8h4V4h6v8h4z"/></svg>',
  comment: '<svg viewBox="0 0 24 24"><path d="M4 5h16v11H9l-5 4z"/></svg>',
  flag: '<svg viewBox="0 0 24 24"><path d="M5 21V4h11l-2 4 2 4H5"/></svg>',
  trash: '<svg viewBox="0 0 24 24"><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>',
  reply: '<svg viewBox="0 0 24 24"><path d="M10 8L4 13l6 5M4 13h11a5 5 0 015 5"/></svg>',
  back: '<svg viewBox="0 0 24 24"><path d="M15 5l-7 7 7 7"/></svg>',
  camera: '<svg viewBox="0 0 24 24"><path d="M4 8h3l2-3h6l2 3h3v11H4z"/><circle cx="12" cy="13" r="3.5"/></svg>',
  eye: '<svg viewBox="0 0 24 24"><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>',
};
const subColor = n => `linear-gradient(135deg, hsl(${hue(n)} 70% 52%), hsl(${(hue(n) + 50) % 360} 60% 32%))`;
const subDot = (n, size) => `<span class="subdot" style="background:${subColor(n)}${size ? `;width:${size}px;height:${size}px;font-size:${size * 0.42}px` : ''}">${esc((n || '?')[0].toUpperCase())}</span>`;
const avatar = (name, size = 56) => `<div class="avatar" style="width:${size}px;height:${size}px;font-size:${size * 0.4}px;background:hsl(${hue(name)} 55% 38%);position:relative;overflow:hidden">${esc((name || '?')[0].toUpperCase())}${name && name !== '[deleted]' ? `<img src="/avatar/${encodeURIComponent(name)}" alt="" data-av style="position:absolute;inset:0;width:100%;height:100%;object-fit:cover">` : ''}</div>`;

let toastT;
function toast(msg, err) {
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast' + (err ? ' err' : '');
  t.onclick = null;
  t.hidden = false;
  clearTimeout(toastT);
  toastT = setTimeout(() => { t.hidden = true; }, err ? 5000 : 2500);
}

async function api(path, body, method) {
  const r = await fetch('/api' + path, {
    method: method || (body !== undefined ? 'POST' : 'GET'),
    headers: { 'Content-Type': 'application/json' },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });
  let j = {};
  try { j = await r.json(); } catch {}
  if (r.status === 401) { renderLogin(); throw new Error('Login required'); }
  if (!r.ok) throw new Error(j.error || r.statusText);
  return j;
}

// shrink big photos before upload (keeps vision models happy and the disk small)
function readImage(file, max = 1600) {
  return new Promise((resolve, reject) => {
    if (/heic|heif/i.test(file.type) || /\.(heic|heif)$/i.test(file.name || '')) return reject(new Error('iPhone HEIC photos aren\'t supported by browsers. Change your iPhone camera to "Most Compatible" or convert to JPG.'));
    if (!file.type.startsWith('image/')) return reject(new Error('That file isn\'t an image'));
    if (file.size > 40 * 1024 * 1024) return reject(new Error('That image is over 40 MB'));
    const fr = new FileReader();
    fr.onerror = () => reject(new Error('Could not read file'));
    fr.onload = () => {
      if (file.type === 'image/gif') return resolve(fr.result);
      const img = new Image();
      img.onload = () => {
        const sc = Math.min(1, max / Math.max(img.width, img.height));
        const c = document.createElement('canvas');
        c.width = Math.round(img.width * sc);
        c.height = Math.round(img.height * sc);
        c.getContext('2d').drawImage(img, 0, 0, c.width, c.height);
        resolve(c.toDataURL('image/jpeg', 0.86));
      };
      img.onerror = () => reject(new Error('Could not open image'));
      img.src = fr.result;
    };
    fr.readAsDataURL(file);
  });
}

// ---------- GIFs & videos ----------
const typeOfPath = p => (/\.(mp4|m4v|webm|mov)(\?|$)/i.test(String(p)) ? 'video' : /\.gif(\?|$)/i.test(String(p)) ? 'gif' : 'image');
const kindOfFile = f => (/^video\//.test(f.type) || /\.(mp4|m4v|webm|mov)$/i.test(f.name || '') ? 'video' : f.type === 'image/gif' || /\.gif$/i.test(f.name || '') ? 'gif' : 'image');
const extOfFile = f => {
  const fromName = (/\.([a-z0-9]+)$/i.exec(f.name || '') || [])[1];
  if (fromName) return fromName.toLowerCase();
  return { 'video/mp4': 'mp4', 'video/quicktime': 'mov', 'video/webm': 'webm', 'image/gif': 'gif' }[f.type] || 'mp4';
};

// stream the raw file to the server (no re-encoding, so GIFs stay animated)
async function uploadRaw(file, onProgress) {
  if (file.size > 300 * 1024 * 1024) throw new Error('Files over 300 MB are too big');
  return new Promise((resolve, reject) => {
    const x = new XMLHttpRequest();
    x.open('POST', '/api/upload?ext=' + encodeURIComponent(extOfFile(file)));
    x.upload.onprogress = e => { if (e.lengthComputable && onProgress) onProgress(e.loaded / e.total); };
    x.onload = () => { let j = {}; try { j = JSON.parse(x.responseText); } catch {} x.status === 200 ? resolve(j) : reject(new Error(j.error || 'Upload failed')); };
    x.onerror = () => reject(new Error('Upload failed. Check the connection to your computer.'));
    x.send(file);
  });
}

// The AI can't watch a video, so we grab frames in order and lay them out on one numbered sheet.
const SHEET_FRAMES = 6;
async function framesFromVideo(src) {
  const v = document.createElement('video');
  v.muted = true; v.playsInline = true; v.preload = 'auto'; v.crossOrigin = 'anonymous'; v.src = src;
  await new Promise((res, rej) => { v.onloadeddata = res; v.onerror = () => rej(new Error('This browser can\'t open that video format. MP4 works best.')); setTimeout(() => rej(new Error('Video took too long to load')), 20000); });
  const dur = isFinite(v.duration) && v.duration > 0 ? v.duration : 1;
  const out = [];
  for (let i = 0; i < SHEET_FRAMES; i++) {
    const t = Math.min(dur - 0.05, dur * (0.04 + 0.92 * i / (SHEET_FRAMES - 1)));
    await new Promise(res => { const done = () => { v.removeEventListener('seeked', done); res(); }; v.addEventListener('seeked', done); v.currentTime = Math.max(0, t); setTimeout(res, 3000); });
    out.push(v);
    out[out.length - 1] = snap(v, v.videoWidth, v.videoHeight);
  }
  return { frames: out, seconds: dur };
}
async function framesFromGif(src) {
  const blob = await (await fetch(src)).blob();
  if ('ImageDecoder' in window) {
    try {
      const dec = new ImageDecoder({ data: blob.stream(), type: 'image/gif' });
      await dec.tracks.ready;
      const n = dec.tracks.selectedTrack.frameCount || 1;
      const picks = [...new Set([...Array(Math.min(SHEET_FRAMES, n))].map((_, i) => Math.round(i * (n - 1) / Math.max(1, Math.min(SHEET_FRAMES, n) - 1))))];
      const frames = [];
      for (const idx of picks) { const { image } = await dec.decode({ frameIndex: idx }); frames.push(snap(image, image.displayWidth, image.displayHeight)); image.close(); }
      return { frames };
    } catch {}
  }
  // browsers without ImageDecoder (Safari): the first frame is the best we can do
  const img = new Image();
  img.src = URL.createObjectURL(blob);
  await img.decode();
  return { frames: [snap(img, img.naturalWidth, img.naturalHeight)] };
}
function snap(source, w, h) {
  const sc = Math.min(1, 480 / Math.max(w || 1, h || 1));
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round((w || 1) * sc)); c.height = Math.max(1, Math.round((h || 1) * sc));
  c.getContext('2d').drawImage(source, 0, 0, c.width, c.height);
  return c;
}
async function makeSheet(src, kind) {
  const { frames } = kind === 'video' ? await framesFromVideo(src) : await framesFromGif(src);
  if (!frames.length) throw new Error('No frames');
  const cols = frames.length > 4 ? 3 : frames.length > 1 ? 2 : 1;
  const rows = Math.ceil(frames.length / cols);
  const fw = frames[0].width, fh = frames[0].height, pad = 6;
  const c = document.createElement('canvas');
  c.width = cols * fw + (cols + 1) * pad; c.height = rows * fh + (rows + 1) * pad;
  const g = c.getContext('2d');
  g.fillStyle = '#111'; g.fillRect(0, 0, c.width, c.height);
  frames.forEach((f, i) => {
    const x = pad + (i % cols) * (fw + pad), y = pad + Math.floor(i / cols) * (fh + pad);
    g.drawImage(f, x, y, fw, fh);
    if (frames.length > 1) { g.fillStyle = 'rgba(0,0,0,.65)'; g.fillRect(x + 6, y + 6, 26, 22); g.fillStyle = '#fff'; g.font = 'bold 15px sans-serif'; g.fillText(String(i + 1), x + 13, y + 23); }
  });
  return c.toDataURL('image/jpeg', 0.82);
}

// pick a file for a post or DM: photos are shrunk, GIFs and videos are uploaded as-is plus a frame sheet for the AI
async function prepareMedia(file, onProgress) {
  const kind = kindOfFile(file);
  if (kind === 'image') return { kind, image: await readImage(file), preview: null };
  if (/heic|heif/i.test(file.type)) throw new Error('iPhone HEIC files aren\'t supported. Use JPG/MP4.');
  const local = URL.createObjectURL(file);
  let sheet = null;
  try { sheet = await makeSheet(local, kind); } catch {}
  const up = await uploadRaw(file, onProgress);
  return { kind, media: up.path, sheet, preview: local };
}
const mediaPreview = (m, label = 'Remove') => `${m.kind === 'video' ? `<video class="pimg" src="${m.preview}" controls playsinline muted></video>` : `<img class="pimg" src="${m.preview || m.image}" alt="">`}<button class="linkbtn" data-act="rmMedia">${label}</button>`;

const blurOn = () => LS.get('blur', false);
const imgTag = (src, cls = 'pimg') => (typeOfPath(src) === 'video'
  ? `<video class="${cls}${blurOn() ? ' blur' : ''}" src="${esc(src)}" controls playsinline muted loop preload="metadata" data-act="unblur"></video>`
  : `<img class="${cls}${blurOn() ? ' blur' : ''}" src="${esc(src)}" loading="lazy" alt="" data-act="unblur">`);

// ---------- boot / auth ----------
async function boot() {
  try {
    const st = await api('/status');
    if (!st.setup) return renderSetup();
    await loadBase();
  } catch (e) {
    if (e.message !== 'Login required') main.innerHTML = `<div class="empty">Can't reach the server. Is it still running?<br><small>${esc(e.message)}</small></div>`;
    return;
  }
  startApp();
}
async function loadBase() {
  const b = await api('/base');
  S.me = b.me; S.subs = b.subs; S.aiReady = b.aiReady; S.aiProblem = b.aiProblem; S.online = b.online; S.unread = b.unread;
  $('#meLink').textContent = 'u/' + S.me.username;
  setBadges();
}
let started = false;
function startApp() {
  if (started) return route();
  started = true;
  document.body.classList.remove('bare');
  window.addEventListener('hashchange', route);
  setInterval(poll, 5000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) poll(); });
  route();
}
function renderSetup() {
  document.body.classList.add('bare');
  main.innerHTML = `<div class="center-card card">
    <div class="logo"><span class="wordmark">reddish</span><span class="nsfw">18+</span></div>
    <p class="muted small">Your private Reddit. Everyone else here is an AI. Adults only.</p>
    <label>Pick your username</label><input id="su" placeholder="e.g. chai_aur_chaos" maxlength="20" autocomplete="off">
    <label>Set a PIN (4–8 digits). You'll use it to open the site on your phone.</label><input id="sp" type="password" inputmode="numeric" maxlength="8">
    <div class="row" style="margin-top:12px"><label class="row small muted" style="margin:0"><input type="checkbox" id="s18" style="width:auto"> I'm 18 or older</label></div>
    <button class="btn" style="width:100%;margin-top:14px" id="sgo">Create my account</button>
  </div>`;
  $('#sgo').onclick = async () => {
    if (!$('#s18').checked) return toast('You need to be 18+ to use this site.', 1);
    try { await api('/setup', { username: $('#su').value, pin: $('#sp').value }); await loadBase(); location.hash = '#/settings'; startApp(); toast('Account created. Now add an AI model.'); }
    catch (e) { toast(e.message, 1); }
  };
}
function renderLogin() {
  document.body.classList.add('bare');
  main.innerHTML = `<div class="center-card card">
    <div class="logo"><span class="wordmark">reddish</span><span class="nsfw">18+</span></div>
    <label>Enter your PIN</label><input id="lp" type="password" inputmode="numeric" maxlength="8" autofocus>
    <button class="btn" style="width:100%;margin-top:12px" id="lgo">Open</button></div>`;
  const go = async () => {
    try { await api('/login', { pin: $('#lp').value }); await loadBase(); startApp(); }
    catch (e) { toast(e.message, 1); }
  };
  $('#lgo').onclick = go;
  $('#lp').onkeydown = e => { if (e.key === 'Enter') go(); };
}

// ---------- polling ----------
function setBadges() {
  const n = (S.unread.notifs || 0) + (S.unread.msgs || 0);
  $('#badge').textContent = n ? (n > 99 ? '99+' : n) : '';
  $('#badge2').textContent = n ? (n > 99 ? '99+' : n) : '';
  const u = S.nowCount || 0;
  if ($('#badgeNow')) $('#badgeNow').textContent = u ? (u > 99 ? '99+' : u) : '';
  document.title = n + u ? `(${n + u}) Reddish` : 'Reddish';
}
const isTyping = () => $$('textarea, input[type=text], input:not([type])', main).some(el => el.value && el.value.trim()) || ['TEXTAREA', 'INPUT', 'SELECT'].includes(document.activeElement?.tagName);
const LIVE = ['home', 'sub', 'post', 'inbox', 'thread', 'user', 'me'];
async function poll() {
  if (document.hidden) return;
  try {
    const p = await api('/poll');
    const prevTotal = (S.unread.notifs || 0) + (S.unread.msgs || 0);
    S.unread = p.unread;
    S.nowCount = p.nowCount || 0;
    S.aiReady = p.aiReady; S.aiProblem = p.aiProblem; S.online = p.online; S.throttled = p.throttled;
    const total = (p.unread.notifs || 0) + (p.unread.msgs || 0);
    if (S.version && total > prevTotal && p.latest) liveToast(p.latest);
    setBadges();
    if (S.me) S.me.karma = p.karma;
    if (p.subsCount && S.subs && p.subsCount !== S.subs.length) { await loadBase(); if (S.view === 'subs') viewSubs(); }
    // new posts on the feed: refresh right away at the top, or offer a pill if you've scrolled down
    if ((S.view === 'home' || S.view === 'sub') && p.newestPost > (S.feedNewest || 0) && S.version) {
      S.feedNewest = p.newestPost;
      if (window.scrollY < 300 && !isTyping()) { S.version = p.version; refresh(); return; }
      $('#pill').textContent = '↑ New posts';
      $('#pill').hidden = false;
    }
    if (S.view === 'thread') { S.version = p.version; updateThread(); return; }
    if (p.version !== S.version) {
      const first = !S.version;
      S.version = p.version;
      if (first || !LIVE.includes(S.view)) return;
      if (isTyping() || S.view === 'admin') $('#pill').hidden = false;
      else refresh();
    }
  } catch {}
}
// a small pop-up when someone replies or DMs you, like the real app
function liveToast(l) {
  const m = l.msg && l.msg.id !== S.lastToastMsg ? l.msg : null;
  const n = !m && l.notif && l.notif.id !== S.lastToastNotif ? l.notif : null;
  if (m && S.view === 'thread' && location.hash.includes(encodeURIComponent(m.thread))) return;
  if (m) { S.lastToastMsg = m.id; showLive(`💬 u/${m.from}: ${m.text}`, '#/dm/' + encodeURIComponent(m.thread)); }
  else if (n) { S.lastToastNotif = n.id; showLive(n.text, n.link); }
}
function showLive(text, link) {
  const t = $('#toast');
  t.className = 'toast live-toast';
  t.innerHTML = esc(text.length > 120 ? text.slice(0, 117) + '…' : text);
  t.hidden = false;
  t.onclick = () => { t.hidden = true; if (link) location.hash = link; };
  clearTimeout(S.liveT);
  S.liveT = setTimeout(() => { t.hidden = true; t.onclick = null; }, 5500);
  if (navigator.vibrate) try { navigator.vibrate(30); } catch {}
}
$('#pill').onclick = () => { $('#pill').hidden = true; $('#pill').textContent = 'New activity · tap to refresh'; if (S.view === 'home' || S.view === 'sub') { route(); } else refresh(); };
async function refresh() {
  const y = window.scrollY;
  await route(true);
  window.scrollTo(0, y);
}

// ---------- router ----------
async function route(isRefresh) {
  const h = location.hash.replace(/^#\/?/, '');
  const parts = h.split('/').map(decodeURIComponent);
  $('#pill').hidden = true;
  const tab = parts[0] === '' ? 'home' : parts[0] === 'u' && parts[1] === S.me?.username ? 'me' : parts[0];
  $$('#bottomnav a').forEach(a => a.classList.toggle('active', a.dataset.tab === tab));
  if (!isRefresh) window.scrollTo(0, 0);
  try {
    if (!h || h === '/') { S.view = 'home'; return await viewFeed(null, parts[1]); }
    switch (parts[0]) {
      case 'hot': case 'new': case 'top': S.view = 'home'; return await viewFeed(null, parts[0]);
      case 'r': S.view = 'sub'; return await viewFeed(parts[1], parts[2]);
      case 'post': S.view = 'post'; return await viewPost(parts[1], parts[2]);
      case 'submit': S.view = 'submit'; return viewSubmit(parts[1]);
      case 'subs': S.view = 'subs'; return viewSubs();
      case 'inbox': S.view = 'inbox'; return await viewInbox(parts[1]);
      case 'dm': S.view = 'thread'; return await viewThread(parts.slice(1).join('/'));
      case 'u': S.view = parts[1] === S.me.username ? 'me' : 'user'; return await viewUser(parts[1], parts[2]);
      case 'me': location.replace('#/u/' + encodeURIComponent(S.me.username)); return;
      case 'settings': S.view = 'settings'; return await viewSettings();
      case 'owned': S.view = 'owned'; return await viewOwned();
      case 'claim': S.view = 'claim'; return await viewClaim();
      case 'now': S.view = 'now'; return await viewNow();
      case 'hub': S.view = 'hub'; return await viewHub();
      case 'proofs': S.view = 'proofs'; return await viewProofs();
      case 'museum': S.view = 'museum'; return await viewMuseum();
      case 'sissy': S.view = 'sissy'; return await viewSissy();
      case 'item': S.view = 'item'; return await viewItem();
      case 'orgasm': S.view = 'orgasm'; return await viewOrgasm();
      case 'stroke': S.view = 'stroke'; return await viewStroke();
      case 'trance': S.view = 'trance'; return await viewTrance(parts[1]);
      case 'admin': S.view = 'admin'; return await viewAdmin(parts[1] || 'sim', parts[2]);
      default: main.innerHTML = '<div class="empty">Page not found</div>';
    }
  } catch (e) {
    if (e.message !== 'Login required') main.innerHTML = `<div class="empty">${esc(e.message)}</div>`;
  }
}

// ---------- shared bits ----------
function voteBox(kind, item, small) {
  const st = item.myVote > 0 ? ' is-up' : item.myVote < 0 ? ' is-down' : '';
  return `<div class="vote${small ? ' h' : ''}${st}" data-kind="${kind}" data-id="${item.id}">
    <button class="up${item.myVote > 0 ? ' on' : ''}" data-act="vote" data-dir="1" aria-label="Upvote">${I.up}</button>
    <span class="score">${fmtN(item.score)}</span>
    <button class="down${item.myVote < 0 ? ' on' : ''}" data-act="vote" data-dir="-1" aria-label="Downvote">${I.down}</button></div>`;
}
const mediaTag = (src, link, type) => {
  type = type || typeOfPath(src);
  if (type === 'video') return `<div class="media${blurOn() ? ' blur' : ''}" data-act="unblur"><video class="pimg" src="${esc(src)}#t=0.1" controls playsinline muted loop preload="metadata"></video><span class="mbadge">video</span><div class="reveal">Tap to show</div></div>`;
  return `<div class="media${blurOn() ? ' blur' : ''}" data-act="unblur"><div class="bg" style="background-image:url('${esc(src)}')"></div>${link ? `<a href="${esc(src)}" target="_blank">` : ''}<img class="pimg" src="${esc(src)}" loading="lazy" alt="">${link ? '</a>' : ''}${type === 'gif' ? '<span class="mbadge">GIF</span>' : ''}<div class="reveal">Tap to show</div></div>`;
};
function authorLink(a, opName) {
  if (a.deleted) return '<span class="muted">[deleted]</span>';
  return `<a href="#/u/${encodeURIComponent(a.name)}"><b>${a.me && a.item ? `📦 ${esc(a.item)}` : `u/${esc(a.name)}`}</b></a>${a.me ? ' <span class="tag you">you</span>' : ''}${a.me && a.sissy ? ` <a class="tag sissy" href="#/sissy">🎀 ${esc(a.sissy)}</a>` : ''}${a.me && a.alias ? ` <a class="tag alias" href="#/hub" title="Your name for today">🏷️ "${esc(a.alias)}"</a>` : ''}${a.me && a.deeds && a.deeds.length ? ` <a class="tag deedtag" href="#/claim" title="${a.deeds.map(x => `${x.part}: u/${x.by}`).join(', ')}">📜 ${a.deeds.map(x => `${esc(x.part)}: u/${esc(x.by)}`).join(' · ')}</a>` : ''}${a.me && a.mark ? ` <a class="tag mark" href="#/claim" title="${a.mark.n} name${a.mark.n === 1 ? '' : 's'} on you, sold for ${esc(a.mark.total)}">🖊️ ${a.mark.n > 1 ? `${a.mark.n} names · ${esc(a.mark.total)}` : `u/${esc(a.mark.by)}`}</a>` : ''}${a.mod ? ' <span class="tag mod">mod</span>' : ''}${a.role === 'streamer' ? ' <span class="tag star">🎥 streamer</span>' : a.fame >= 2 ? ' <span class="tag star">⭐ famous</span>' : ''}${opName && a.name === opName && !a.me ? ' <span class="tag op">OP</span>' : ''}`;
}
const avImg = a => (a.deleted ? '' : `<img class="av" src="/avatar/${encodeURIComponent(a.name)}" alt="" loading="lazy" data-av>`);
function aiWarning() {
  if (!S.aiReady) return `<div class="warnbar">No AI model is set up yet, so nobody will post or reply. <a href="#/settings">Add one in Settings</a>.</div>`;
  if (S.throttled) return `<div class="warnbar">The hourly AI limit is used up, so activity has slowed until the next hour. <a href="#/admin/sim">Raise "Max AI text calls / hour"</a>.</div>`;
  return S.aiProblem ? `<div class="warnbar">The AI isn't working right now: ${esc(S.aiProblem)} <a href="#/settings">Fix it in Settings</a>.</div>` : '';
}
function postCard(p, showSub = true) {
  return `<article class="post" data-href="#/post/${p.id}">
    <div class="pbody">
      <div class="meta">${showSub ? `<a class="subchip" href="#/r/${p.sub}">${subDot(p.sub)}r/${esc(p.sub)}</a><span class="sep">•</span>` : avImg(p.author)}${authorLink(p.author)}<span class="sep">•</span>${ago(p.created)}${p.removed ? ' <span class="tag removed">removed</span>' : ''}</div>
      <div class="ptitle">${esc(p.title)}</div>
      ${p.shot ? shotTag(p.shot) : p.image ? mediaTag(p.image, false, p.mediaType) : p.body ? `<div class="ptext clip">${md(p.body)}</div>` : ''}
      <div class="actions">${voteBox('post', p)}<a class="chip" href="#/post/${p.id}">${I.comment}${fmtN(p.comments)}</a></div>
    </div></article>`;
}

const liveDot = n => `<span class="live"><i></i>${fmtN(n)} online</span>`;
// two-tap confirm without browser dialogs
function confirmTap(el, msg) {
  if (el.dataset.armed) { delete el.dataset.armed; return true; }
  el.dataset.armed = '1'; const old = el.textContent; el.textContent = msg;
  setTimeout(() => { if (el.dataset.armed) { delete el.dataset.armed; el.textContent = old; } }, 4000);
  return false;
}
// ---------- feed ----------
async function viewFeed(sub, sort) {
  sort = sort || 'hot';
  const q = new URLSearchParams({ sort, ...(sub ? { sub } : {}) });
  const data = await api('/feed?' + q);
  S.feedNewest = data.posts.reduce((m, p) => Math.max(m, p.created), S.feedNewest || 0);
  const base = sub ? `#/r/${sub}` : '#';
  let head = '';
  if (data.sub) {
    const s = data.sub;
    head = `<div class="subhead"><div class="banner" style="background:${subColor(s.name)}"></div><div class="inner">
      <div class="row" style="align-items:flex-end"><div class="icon" style="background:${subColor(s.name)}">${esc(s.name[0].toUpperCase())}</div><span class="grow"></span><a class="btn small" href="#/submit/${s.name}">New post</a></div>
      <h1>r/${esc(s.name)}</h1>
      <div class="row muted small" style="gap:14px;margin-top:4px"><span>${fmtN(s.members)} members</span>${s.archived ? '<span>gone quiet</span>' : liveDot(s.online)}</div>
      ${s.born ? `<div class="tiny muted" style="margin-top:6px">🌱 Started ${ago(s.born)} ago by u/${esc(s.founder)}${s.origin ? ', ' + esc(s.origin) : ''}</div>` : ''}
      <p class="desc">${esc(s.description)}</p>
      <details><summary class="small muted">Rules and mods</summary><ol class="rules">${s.rules.map(r => `<li>${esc(r)}</li>`).join('')}</ol>
      <div class="small muted" style="margin-top:6px">Mods: ${s.mods.map(m => `<a href="#/u/${encodeURIComponent(m)}">u/${esc(m)}</a>`).join(', ')} · <a href="#/dm/mod:${s.name}"><u>Message the mods</u></a></div></details>
      ${data.ban ? `<div class="banbox">You're ${data.ban.until ? 'banned until ' + new Date(data.ban.until).toLocaleString() : 'permanently banned'} from this sub. Reason: ${esc(data.ban.reason)} · <a href="#/dm/mod:${s.name}"><u>Appeal in modmail</u></a></div>` : ''}
    </div></div>`;
  }
  const hotList = [...data.posts].sort((a, b) => (b.comments * 2 + b.score) - (a.comments * 2 + a.score)).slice(0, 5);
  const rail = `<aside class="rail">
    ${data.sub ? `<div class="card"><h2>About r/${esc(data.sub.name)}</h2><div class="small" style="color:var(--text2)">${esc(data.sub.description)}</div><div class="row small muted" style="gap:14px;margin-top:10px"><span>${fmtN(data.sub.members)} members</span>${liveDot(data.sub.online)}</div></div>`
      : `<div class="card"><h2>Right now</h2><div class="small" style="color:var(--text2)">${liveDot(S.online || 0)}</div><div class="small muted" style="margin-top:6px">${S.subs.length} subs · everyone here except you is an AI</div></div>`}
    ${data.sub ? '' : `<div class="card"><a class="hot" href="#/hub">✦ Hub<span>the Claim, deeds, your key, your name, trances, the Vault</span></a><a class="hot" href="#/subs">Subreddits<span>browse every sub</span></a></div>`}
    ${hotList.length ? `<div class="card"><h2>Most talked about</h2>${hotList.map(p => `<a class="hot" href="#/post/${p.id}">${esc(p.title)}<span>r/${esc(p.sub)} • ${fmtN(p.comments)} comment${p.comments === 1 ? '' : 's'}</span></a>`).join('')}</div>` : ''}
  </aside>`;
  main.innerHTML = `<div class="layout${data.sub && data.sub.vault ? ' vaultmode' : ''}"><div class="col">${aiWarning()}${head}
    <div class="feedbar"><div class="tabs">${['hot', 'new', 'top'].map(t => `<a href="${base}/${t}" class="${t === sort ? 'on' : ''}">${t[0].toUpperCase() + t.slice(1)}</a>`).join('')}</div>
      <button class="linkbtn" data-act="toggleblur" title="Blur photos until tapped">${I.eye}${blurOn() ? 'Blurred' : 'Blur'}</button></div>
    <div class="feed">${data.posts.length ? data.posts.map(p => postCard(p, !sub)).join('') : `<div class="empty"><b>Nothing here yet</b>${S.aiReady ? 'People are on their way. The first posts show up within a few minutes.' : 'Add your AI key in Settings and people will start posting.'}</div>`}</div>
  </div>${rail}</div>`;
}

// where a spot sits on the body map (front / back); unknown spots just don't get a dot
const SPOT_XY = [
  [/private|penis|cock|dick|balls|genital/i, 'f', 50, 59], [/crotch|groin|pubic/i, 'f', 50, 52.5], [/lower ab|abdomen|navel|belly button/i, 'f', 50, 46],
  [/stomach|belly|abs/i, 'f', 50, 39], [/chest|pec|nipple/i, 'f', 50, 27], [/collar/i, 'f', 50, 20], [/neck|throat/i, 'f', 50, 16],
  [/inner thigh|thigh/i, 'f', 44, 66], [/hip/i, 'f', 36, 51], [/forehead|face|cheek/i, 'f', 50, 8], [/palm|hand/i, 'f', 21, 55], [/arm/i, 'f', 25, 38],
  [/butt|ass|cheek/i, 'b', 50, 56], [/lower back/i, 'b', 50, 45], [/back|shoulder/i, 'b', 50, 30], [/calf|leg/i, 'b', 44, 78],
];
const spotXY = s => { const h = SPOT_XY.find(([re]) => re.test(s)); return h ? { side: h[1], x: h[2], y: h[3] } : null; };
function bodyMap(items) {
  const fig = side => {
    const dots = items.map(it => ({ it, p: spotXY(it.spot) })).filter(o => o.p && o.p.side === side);
    // centre-line labels alternate sides so they don't pile up
    let alt = 0;
    dots.forEach(o => { o.right = o.p.x > 50 || (o.p.x === 50 && alt++ % 2 === 0); });
    return `<svg viewBox="0 0 100 100" class="bodysvg" role="img" aria-label="${side === 'f' ? 'Front' : 'Back'}">
      <g class="sil"><circle cx="50" cy="9" r="6.5"/><path d="M50 16c-9 0-16 3-17 9l-6 26c-.6 3 3.6 4 4.5 1l5-19 1 22-3 38c0 3 5 3 5.5 0l5-31h2l5 31c.5 3 5.5 3 5.5 0l-3-38 1-22 5 19c.9 3 5.1 2 4.5-1l-6-26c-1-6-8-9-17-9z"/></g>
      ${dots.map(({ it, p, right }) => `<g class="dot ${it.cls}"><circle cx="${p.x}" cy="${p.y}" r="${it.cls === 'sold' ? 3.4 : 2.6}"/>${it.num ? `<text class="num" x="${p.x}" y="${p.y + 1.4}" text-anchor="middle">${it.num}</text>` : ''}${it.label ? `<text x="${p.x + (right ? 5 : -5)}" y="${p.y + 1.2}" text-anchor="${right ? 'start' : 'end'}">${esc(it.label)}</text>` : ''}</g>`).join('')}
      <text x="50" y="99" text-anchor="middle" class="side">${side === 'f' ? 'front' : 'back'}</text></svg>`;
  };
  return `<div class="bodymap">${fig('f')}${fig('b')}</div>`;
}
const rs = n => '₹' + Math.round(n).toLocaleString('en-IN');
const dayText = d => (d < 1 ? `${Math.max(0, Math.round(d * 24))}h in` : `day ${Math.floor(d) + 1}`);
const KIND = { opening: 'Opening proof', checkin: 'Check-in', retake: 'Retake', buyout: 'Buyout proof', extra: 'Extra proof' };
// little price chart for a deed: every sale, oldest → newest
function spark(hist) {
  if (hist.length < 2) return '';
  const max = Math.max(...hist.map(h => h.price)), min = Math.min(...hist.map(h => h.price));
  const pts = hist.map((h, i) => `${(i / (hist.length - 1)) * 100},${28 - ((h.price - min) / (max - min || 1)) * 24}`).join(' ');
  return `<svg class="spark" viewBox="-2 0 104 32" preserveAspectRatio="none"><polyline points="${pts}"/>${hist.map((h, i) => `<circle cx="${(i / (hist.length - 1)) * 100}" cy="${28 - ((h.price - min) / (max - min || 1)) * 24}" r="1.6"/>`).join('')}</svg>`;
}
function deedCards(dd) {
  if (!dd || !dd.enabled || !dd.parts.length) return '';
  return `<h2 class="sect">📜 Deeds</h2><div class="deeds">${dd.parts.map(p => {
    const last = p.history[p.history.length - 1], first = p.history[0];
    const gain = first && last && p.history.length > 1 ? Math.round((last.price / first.price - 1) * 100) : null;
    return `<div class="card deed${p.sale ? ' forsale' : ''}"><div class="row"><h3 class="grow">your ${esc(p.part)}</h3>${p.sale ? '<span class="tag bold">for sale</span>' : ''}</div>
      ${p.owner ? `<div class="small">owned by <a href="#/u/${encodeURIComponent(p.owner)}"><b>u/${esc(p.owner)}</b></a> · bought ${ago(p.since) === 'just now' ? 'just now' : ago(p.since) + ' ago'} for <b class="price">${rs(p.price)}</b>${gain !== null ? ` <span class="${gain >= 0 ? 'okay' : 'danger-text'}">${gain >= 0 ? '↑' : '↓'}${Math.abs(gain)}% since first sale</span>` : ''}</div>`
        : `<div class="small muted">Nobody owns it yet. Starting price ${rs(p.base)}.</div>`}
      ${p.rules.length && p.owner ? `<div class="rules"><div class="tiny muted">her rules</div><ol class="small">${p.rules.map(r => `<li>${esc(r)}</li>`).join('')}</ol></div>` : ''}
      ${p.sale ? `<div class="salebox"><div class="row"><span class="grow small">${p.sale.seller ? `u/${esc(p.sale.seller)} is selling it` : 'The house is selling it'} · reserve ${rs(p.sale.reserve)}</span><span class="tdue" data-due="${p.sale.closes}">⏱ ${leftText(p.sale.closes)}</span></div>
        <div class="bigtotal small-total">${p.sale.top ? rs(p.sale.top.amount) : '—'}<span>${p.sale.top ? `top bid · u/${esc(p.sale.top.by)} · ${p.sale.bids} bid${p.sale.bids === 1 ? '' : 's'}` : 'no bids yet'}</span></div>
        <a class="btn ghost small" href="#/post/${p.sale.postId}">Watch the sale</a></div>` : ''}
      ${p.history.length ? `<details><summary class="tiny muted">ownership history (${p.history.length} sale${p.history.length === 1 ? '' : 's'})</summary>${spark(p.history)}${p.history.slice().reverse().map(h => `<div class="tiny otask"><span class="grow">u/${esc(h.username)} <span class="muted">from ${esc(h.from)}</span></span><b class="price">${rs(h.price)}</b><span class="muted">${ago(h.at)}</span></div>`).join('')}</details>` : ''}
    </div>`;
  }).join('')}</div><h2 class="sect">🔨 12-hour body auction</h2>`;
}
async function viewClaim() {
  const c = await api('/claim');
  const r = c.records;
  const hall = `<div class="card"><h2>🏛️ Hall of claims</h2>
    ${r.total ? `<div class="ostats"><div><b>${r.total}</b><span>auctions</span></div><div><b>${esc(r.earned)}</b><span>paid for you</span></div><div><b>${r.buyouts}</b><span>buyouts</span></div><div><b>${r.streak}</b><span>clean streak</span></div></div>
    ${r.priciest ? `<div class="small" style="margin-bottom:8px">💎 Record: <b>${esc(r.priciest.priceText)}</b> for your ${esc(r.priciest.spot)} by u/${esc(r.priciest.username)} (#${r.priciest.n})</div>` : ''}
    ${r.top.map((t, i) => `<div class="otask"><span class="grow">${i + 1}. <a href="#/u/${encodeURIComponent(t.username)}">u/${esc(t.username)}</a></span><span class="tiny muted">${t.spots} spot${t.spots === 1 ? '' : 's'} · ${esc(t.spentText)} spent</span></div>`).join('')}
    <h3 style="margin-top:12px">Past auctions</h3>
    ${c.hall.map(h => `<div class="otask">${h.photo ? `<img class="hthumb" src="${esc(h.photo)}" alt="">` : '<span class="hthumb none">🔨</span>'}<span class="grow"><b>#${h.n}</b> <span class="tiny muted">${rs(h.total)} · ${h.marks.length} spot${h.marks.length === 1 ? '' : 's'} · ${h.endedBy === 'paused' ? 'paused' : `${h.proofs} proof${h.proofs === 1 ? '' : 's'}${h.misses ? `, ${h.misses} missed` : ''}`}</span><br>${h.marks.map(m => `${m.crossed.map(x => `<span class="ink crossed">${esc(x.write)}</span> `).join('')}<span class="ink">${esc(m.write)}</span> <span class="tiny muted">${esc(m.spot)}</span>`).join(' · ')}</span><span class="tiny muted">${ago(h.end)}</span></div>`).join('')}`
    : '<div class="small muted">No auctions yet. The first one opens soon.</div>'}</div>`;
  let top = '';
  if (!c.enabled) top = '<div class="card small muted">The Claim is switched off (Admin → Controls).</div>';
  else if (c.phase === 'idle') {
    top = `<div class="card"><div class="small muted">Nothing is written on you. ${c.nextOpen > Date.now() ? `Next auction in <span class="tdue" data-due="${c.nextOpen}">⏱ ${leftText(c.nextOpen)}</span>` : 'Next auction any minute now.'}</div>
      ${bodyMap(c.lots.map(l => ({ spot: l.spot, cls: l.bold ? 'bold' : 'open', label: rs(l.base) })))}
      <div class="lots">${c.lots.map(l => `<div class="lot${l.bold ? ' bold' : ''}"><div class="row"><span class="grow">${esc(l.spot)}${l.bold ? ' 🔥' : ''}</span><span class="small muted">from ${rs(l.base)}</span></div></div>`).join('')}</div></div>`;
  } else if (c.phase === 'auction') {
    top = `<div class="card auction"><div class="row"><h2 class="grow">🔨 Auction #${c.n}: live</h2><span class="tdue" data-due="${c.closes}">⏱ ${leftText(c.closes)}</span></div>
      <div class="bigtotal">${rs(c.total)}<span>bid on you so far</span></div>
      ${bodyMap(c.lots.map(l => ({ spot: l.spot, cls: l.top ? 'sold' : l.bold ? 'bold' : 'open', label: l.top ? rs(l.top.amount) : '' })))}
      <div class="lots">${c.lots.map(l => `<div class="lot${l.bold ? ' bold' : ''}${l.top ? ' hasbid' : ''}"><div class="row"><span class="grow"><b>${esc(l.spot)}</b>${l.bold ? ' 🔥' : ''}</span><b class="price">${l.top ? rs(l.top.amount) : `<span class="muted">from ${rs(l.base)}</span>`}</b></div>
        ${l.top ? `<div class="tiny">top: <a href="#/u/${encodeURIComponent(l.top.by)}">u/${esc(l.top.by)}</a>${l.top.owner ? ' <span class="tag mod">owner</span>' : ''} · ${l.bids} bid${l.bids === 1 ? '' : 's'}${l.history.length > 1 ? ` <span class="muted">(${l.history.slice(1).map(h => `${esc(h.by)} ${rs(h.amount)}`).join(', ')})</span>` : ''}</div>` : '<div class="tiny muted">no bids yet</div>'}</div>`).join('')}</div>
      ${c.feed.length ? `<h3 style="margin-top:12px">Latest bids</h3>${c.feed.map(f => `<div class="bidline">${avImg({ name: f.by })}<span class="grow"><b>u/${esc(f.by)}</b> <b class="price">${rs(f.amount)}</b> on your ${esc(f.spot)}<br><span class="small muted">${esc(f.line)}</span></span></div>`).join('')}` : ''}
      <div class="tiny muted" style="margin-top:8px">You don't get a bid. You get written on.</div>
      <a class="btn ghost small" style="margin-top:10px" href="#/post/${c.postId}">Open the auction thread</a></div>`;
  } else if (c.phase === 'active') {
    const k = c.cur, n = k.next;
    const due = n && !n.done;
    top = `<div class="card skin"><div class="tiny muted">sold for ${rs(k.total)} · ${k.marks.length} name${k.marks.length === 1 ? '' : 's'} on you</div>
        ${bodyMap(k.marks.map((m, i) => ({ spot: m.spot, cls: 'sold', num: i + 1 })))}
        <div class="marks">${k.marks.map((m, i) => `<div class="mark"><div class="tiny muted"><b class="mnum">${i + 1}</b> ${esc(m.spot)}${m.bold ? ' 🔥' : ''} · ${rs(m.price)} · u/${esc(m.by)}${m.how === 'owner matched' ? ' (owner)' : m.how === 'buyout' ? ' (buyout)' : ''}</div><div>${m.crossed.map(x => `<span class="ink crossed">${esc(x.write)}</span> `).join('')}<span class="ink big">${esc(m.write)}</span></div></div>`).join('')}</div>
        <div class="tdue" data-due="${k.end}">⏱ ${leftText(k.end)}</div></div>
      <div class="card ${due ? 'proofdue' : ''}">
        ${due ? `<b>📸 ${KIND[n.kind] || 'Proof'} due</b> <span class="tdue" data-due="${n.due}">⏱ ${leftText(n.due)}</span><div class="tiny muted">One clear photo showing every name. ${n.kind === 'retake' ? 'Your last one got rejected.' : n.kind === 'buyout' ? 'Cross out the bought-out names first.' : ''}</div>` : `<b>Next check-in</b> <span class="tiny muted">${k.misses ? `${k.misses} missed so far` : 'none missed so far'}. They'll ask when it's time.</span>`}
        <div class="row" style="margin-top:8px"><button class="btn small" data-act="claimProof">📸 Send proof</button><button class="btn ghost small" data-act="claimPause">⏸ Pause (red)</button><a class="btn ghost small" href="#/post/${c.postId}">Thread</a></div>
        <input type="file" id="proofFile" accept="image/*" capture="environment" hidden></div>
      ${k.proofs.length ? `<div class="card"><h2>Proofs</h2><div class="proofs">${k.proofs.map(p => `<figure><img src="${esc(p.image)}" alt=""><figcaption>${p.ok === null ? '⏳ checking…' : p.ok ? '✅' : '❌'} ${KIND[p.kind] || ''}<br><span class="tiny muted">${esc(p.verdict || '')}</span></figcaption></figure>`).join('')}</div></div>` : ''}`;
  }
  main.innerHTML = `<div class="narrow claimpage"><h1>🔨 The Claim</h1>${deedCards(c.deeds)}${top}${hall}
    <div class="tiny muted" style="margin:10px 2px 30px">Bids are in-app play money. Pen or a skin-safe washable marker only. Pause ends it instantly with no penalty.</div></div>`;
  const f = $('#proofFile');
  if (f) f.onchange = async e => {
    const file = e.target.files[0];
    if (!file) return;
    try { toast('Sending proof…'); const img = await readImage(file); await api('/claim/proof', { image: img }); toast('Proof sent. Checking it…'); S.picking = 0; viewClaim(); setTimeout(() => S.view === 'claim' && viewClaim(), 6000); }
    catch (err) { toast(err.message, 1); }
  };
}

// ---------- Now: everything waiting on you, soonest first ----------
async function viewNow() {
  const n = await api('/now');
  S.nowCount = n.urgent; setBadges();
  const act = n.items.filter(i => !i.info), info = n.items.filter(i => i.info);
  const btn = i => {
    if (i.action === 'ratePhoto') return `<button class="btn small" data-act="ratePhoto" data-id="${i.postId}">📸 Show them</button>`;
    if (i.action === 'proof') return `<button class="btn small" data-act="nowProof">📸 Send proof</button>`;
    if (i.action === 'pay') return `<button class="btn small" data-act="notice" data-a="pay" data-id="${i.noticeId}">💸 Pay ${i.fine}</button><a class="btn ghost small" href="${i.link}">Plead</a>`;
    if (i.action === 'ask') return `<button class="btn small" data-act="keyAsk">🙏 Ask permission</button><button class="btn ghost small" data-act="keySlip">😳 I slipped</button>`;
    if (i.action === 'chatPhoto') return `<a class="btn small" href="${i.link}">📸 Do it</a>${i.canMore ? `<button class="btn ghost small" data-act="taskMore" data-mid="${i.msgId}">⏳ Beg</button>` : ''}`;
    if (i.action === 'chat') return `<a class="btn small" href="${i.link}">${i.id.startsWith('contract') ? 'Read it' : '✍️ Do it'}</a>${i.canMore ? `<button class="btn ghost small" data-act="taskMore" data-mid="${i.msgId}">⏳ Beg</button>` : ''}`;
    return '';
  };
  const row = i => `<div class="nowrow${i.info ? ' info' : ''}${i.due && i.due - Date.now() < 3600e3 && !i.info ? ' hot' : ''}">
    <a class="ic" href="${i.link}">${i.icon}</a>
    <a class="grow body" href="${i.link}"><b>${esc(i.title)}</b>${i.sub ? `<span>${esc(i.sub)}</span>` : ''}</a>
    <div class="side">${i.due ? `<span class="tdue" data-due="${i.due}">⏱ ${leftText(i.due)}</span>` : ''}<div class="btns">${btn(i)}</div></div></div>`;
  main.innerHTML = `<div class="narrow nowpage"><h1>Now</h1>
    ${act.length ? `<div class="card list0">${act.map(row).join('')}</div>` : '<div class="card empty"><b>Nothing is waiting on you.</b><span class="muted small">Enjoy it while it lasts.</span></div>'}
    ${info.length ? `<h3>Going on</h3><div class="card list0">${info.map(row).join('')}</div>` : ''}
    <input type="file" id="nowProofFile" accept="image/*" capture="environment" hidden></div>`;
  $('#nowProofFile').onchange = async e => {
    const f = e.target.files[0]; if (!f) return;
    try { toast('Sending proof…'); await api('/claim/proof', { image: await readImage(f) }); toast('Proof sent. Checking it…'); S.picking = 0; viewNow(); } catch (err) { toast(err.message, 1); }
  };
}
setInterval(() => { if (S.view === 'now' && !document.hidden && Date.now() - (S.picking || 0) > 60000 && !isTyping()) viewNow().catch(() => {}); }, 15000);

// ---------- Hub: the spicy stuff, one place ----------
async function viewHub() {
  const h = await api('/hub');
  const card = (href, icon, title, live, sub, cls = '') => `<a class="hubcard ${cls}" href="${href}"><span class="hi">${icon}</span><span class="grow"><b>${title}</b>${live ? `<span class="live">${live}</span>` : ''}${sub ? `<span class="muted small">${sub}</span>` : ''}</span></a>`;
  const c = h.claim, k = h.keyholder, nm = h.naming;
  const claimLive = c.phase === 'active' ? `${c.names} names on you · ${rs(c.total)}` : c.phase === 'auction' ? `🔴 auction live · ${rs(c.total)} bid` : '';
  const deedsLive = h.deeds.map(p => `${p.part}: ${p.owner ? 'u/' + esc(p.owner) : 'unowned'}${p.sale ? ' (for sale)' : ''}`).join(' · ');
  const keyLive = k.cur ? `locked by u/${esc(k.cur.holder)} · ${dayText(k.cur.days)}` : k.sale ? `🔴 key up for auction${k.sale.top ? ` · ${rs(k.sale.top.amount)}` : ''}` : '';
  const nameLive = nm.cur ? `you're "${esc(nm.cur.alias)}" · u/${esc(nm.cur.byName)}` : nm.sale ? `🔴 naming rights auction${nm.sale.top ? ` · "${esc(nm.sale.top.extra)}" leads` : ''}` : '';
  main.innerHTML = `<div class="narrow hub"><h1>Hub</h1>
    ${k.cur ? `<div class="card keycard"><div class="row"><span class="hi">🔑</span><span class="grow"><b>u/${esc(k.cur.holder)} holds your key</b><span class="muted small"><b class="daynum">${dayText(k.cur.days)}</b>${k.cur.pending ? ' · waiting for her answer…' : ''}</span></span></div>
      ${k.cur.bets.length ? `<div class="bets">${k.cur.bets.map(b => `<span class="bet">u/${esc(b.username)}: ${rs(b.amount)} ${b.side === 'under' ? 'before' : 'past'} day ${b.days}</span>`).join('')}</div>` : ''}
      <div class="row" style="margin-top:8px">${k.cur.pending ? '' : '<button class="btn small" data-act="keyAsk">🙏 Ask permission</button>'}<button class="btn ghost small" data-act="keySlip">😳 I slipped</button><a class="btn ghost small" href="#/dm/${k.cur.holderId}">Chat</a></div>
      ${k.cur.requests.length ? `<div class="tiny muted" style="margin-top:6px">Asked ${k.cur.requests.length}×: ${k.cur.requests.map(r => r.status === 'granted' ? '🔓' : r.status === 'denied' ? '🔒' : '⏳').join(' ')}</div>` : ''}</div>` : ''}
    <div class="hubgrid">
      ${card('#/claim', '🔨', 'The Claim', claimLive, 'body auction · 12h')}
      ${card('#/claim', '📜', 'Deeds', '', deedsLive || 'who owns your shaft and balls')}
      ${card(k.sale ? '#/post/' + k.sale.postId : '#/hub', '🔑', 'Keyholder', keyLive, k.cur ? '' : 'who decides when you finish')}
      ${card(nm.sale ? '#/post/' + nm.sale.postId : '#/hub', '🏷️', 'Your name', nameLive, nm.cur ? '' : 'naming rights · 24h')}
      ${card('#/trance', '🌀', 'Trance', h.trances[0] ? `last: "${esc(h.trances[0].title)}" · depth ${h.trances[0].depth}/10` : '', 'let her put you under')}
      ${h.cuck.enabled ? card('#/inbox/messages', '🤤', 'Cuck', h.cuck.couples.length ? h.cuck.couples.map(x => `u/${esc(x.her)} + u/${esc(x.bull)}`).join(' · ') : 'bulls arriving…', '') : ''}
      ${card('#/owned', '🔒', 'Owned', `${h.owned.owners} owner${h.owned.owners === 1 ? '' : 's'} · ${h.owned.tasks} open tasks${h.owned.cases ? ` · ${h.owned.cases} cases` : ''}`, '')}
      ${card('#/r/TheVault', '🕳', 'The Vault', h.vault[0] ? esc(h.vault[0].title) : '', 'anonymous leaks and bounties', 'dark')}
      ${h.rate.enabled ? card('#/r/RateHim', '📏', 'r/RateHim', h.rate.ratings ? `you average ${h.rate.avg}/10 · ${h.rate.pics} pics rated` : h.rate.open.length ? `${h.rate.open.length} demand${h.rate.open.length === 1 ? '' : 's'} waiting` : '', h.rate.open.length ? `${h.rate.open.length} waiting · ${h.rate.missed} missed` : 'doms demand, you show, they rate', 'rate') : ''}
      ${h.sissy && h.sissy.enabled ? card('#/sissy', '🎀', 'Sissy', `"${esc(h.sissy.name)}" · level ${h.sissy.level} · ${esc(h.sissy.title)}`, h.sissy.men ? `${h.sissy.loads.total} finishes taken` : 'dress orders and training', 'rate') : ''}
      ${h.item && h.item.enabled ? card('#/item', '📦', esc(h.item.label), `${h.item.usesWeek} uses this week · ${esc(h.item.condition)}`, h.item.clearance ? '🏷️ on clearance' : 'your product page', 'dark') : ''}
      ${h.orgasm && h.orgasm.enabled ? card('#/orgasm', '🎡', 'Beg to cum', `${h.orgasm.tokens} token${h.orgasm.tokens === 1 ? '' : 's'} left${h.orgasm.holder ? ` · u/${esc(h.orgasm.holder)} holds them` : ''}`, `${h.orgasm.edgesToday} edges today${h.orgasm.daysSince !== null ? ` · ${Math.floor(h.orgasm.daysSince)}d since last` : ''}`) : ''}
      ${h.museum.enabled ? card('#/museum', '🏛', 'The Museum', h.museum.count ? `${h.museum.count} exhibit${h.museum.count === 1 ? '' : 's'} · latest "${esc(h.museum.latest.title)}"` : '', 'your pics on display, with plaques') : ''}
      ${card('#/proofs', '📸', 'Proof gallery', h.proofs.length ? `${h.proofs.length}+ proofs` : '', 'every photo that closed a task')}
      ${card('#/subs', '◎', 'Subreddits', '', 'browse everything')}
    </div></div>`;
}

// ---------- Sissy ----------
const WARDROBE_IDEAS = ['panties', 'thong', 'bra', 'stockings', 'tights', 'lipstick', 'nail polish', 'eyeliner', 'skirt', 'dress', 'heels', 'wig', 'crop top', 'nightie', 'choker', 'hair clips'];
async function viewSissy() {
  const s = await api('/sissy');
  const pct = ((3 - s.next) / 3) * 100;
  main.innerHTML = `<div class="narrow sissypage"><h1>🎀 ${esc(s.name)}</h1>
    ${s.enabled ? '' : '<div class="card small muted">Sissy mode is off. Turn it on in Admin → Controls (or the 🎀 Sissy mode).</div>'}
    <div class="card sissycard"><div class="row"><span class="grow"><span class="tiny muted">level ${s.level}/10</span><br><b class="stitle">${esc(s.title)}</b></span><span class="tiny muted">${s.next} more to level up</span></div><div class="lvl"><i style="width:${pct}%"></i></div>
      <div class="tiny muted" style="margin-top:8px">Done orders raise your level. Failures drop it.${s.men ? ` · ${s.loads.total} finishes taken` : ''}</div>
      <div class="row" style="margin-top:8px"><input id="sname" value="${esc(s.name)}" maxlength="20" style="flex:1"><button class="btn ghost small" data-act="sissyName">Rename</button></div></div>
    <div class="card"><h2>Your wardrobe</h2><div class="tiny muted" style="margin-bottom:8px">Only what you actually own. Doms only assign from this list. Outside the house: only things hidden under your clothes. Everything else stays home.</div>
      <div class="chips" id="wchips">${s.wardrobe.map(w => `<span class="chip on">${esc(w)}<button data-act="wDel" data-w="${esc(w)}" aria-label="Remove">×</button></span>`).join('') || '<span class="tiny muted">Nothing yet.</span>'}</div>
      <div class="row" style="margin-top:8px"><input id="wnew" placeholder="add something you own…" style="flex:1"><button class="btn small" data-act="wAdd">Add</button></div>
      <div class="chips" style="margin-top:8px">${WARDROBE_IDEAS.filter(x => !s.wardrobe.includes(x)).map(x => `<button class="chip" data-act="wQuick" data-w="${x}">+ ${x}</button>`).join('')}</div></div>
    ${s.loads.recent.length ? `<div class="card"><h2>💦 Finishes</h2>${s.loads.recent.map(l => `<div class="otask"><span class="grow">u/${esc(l.by)} <span class="tiny muted">on your ${esc(l.spot)}</span></span><span class="tiny">${l.status === 'done' ? '✅ taken' : l.status === 'failed' ? '❌ refused' : '⏳ waiting for proof'}</span></div>`).join('')}</div>` : ''}
    ${s.history.length ? `<div class="card"><h2>Record</h2>${s.history.map(h => `<div class="otask"><span class="grow small">${esc(h.text)}</span><span class="tiny">${h.status === 'done' ? '✅' : '❌'}</span></div>`).join('')}</div>` : ''}</div>`;
}
async function saveWardrobe(items) { await api('/sissy/wardrobe', { items }); viewSissy(); }

// ---------- Object mode: your product page ----------
async function viewItem() {
  const o = await api('/item');
  const stars = n => '★'.repeat(Math.round(n)) + '☆'.repeat(5 - Math.round(n));
  main.innerHTML = `<div class="narrow itempage">
    ${o.enabled ? '' : '<div class="card small muted">Object mode is off. Turn it on in Admin → Controls.</div>'}
    <div class="card product"><div class="tiny muted">listing</div><h1>📦 ${esc(o.label)}</h1>
      <div class="pstars">${o.reviews.length ? `${stars(o.stars)} <span class="small muted">${o.stars}/5 · ${o.reviews.length} review${o.reviews.length === 1 ? '' : 's'}</span>` : '<span class="small muted">no reviews yet</span>'}</div>
      ${o.clearance ? `<div class="clearance">🏷️ CLEARANCE · 50% off in every auction · <span class="tdue" data-due="${o.clearance}">⏱ ${leftText(o.clearance)}</span></div>` : ''}
      <table class="specs"><tr><td>Condition</td><td>${esc(o.condition)}</td></tr><tr><td>Used this week</td><td>${o.usesWeek}×</td></tr><tr><td>Used in total</td><td>${o.usesTotal}×</td></tr><tr><td>Defects this week</td><td>${o.defectsWeek}</td></tr>${o.rating !== null ? `<tr><td>r/RateHim average</td><td>${o.rating}/10</td></tr>` : ''}<tr><td>Current owners</td><td>${o.owners.map(x => 'u/' + esc(x)).join(', ') || 'none'}</td></tr><tr><td>Previous owners</td><td>${o.previous.map(x => 'u/' + esc(x)).join(', ') || '—'}</td></tr><tr><td>Speaks</td><td>${o.mute ? 'approved phrases only' : 'yes, unfortunately'}</td></tr></table>
      ${o.labels.length ? `<div class="chips" style="margin-top:10px">${o.labels.map(l => `<span class="chip lab">“${esc(l.text)}”</span>`).join('')}</div>` : ''}</div>
    ${o.defects.length ? `<div class="card"><h2>Defect reports</h2>${o.defects.map(x => `<div class="otask"><span class="grow small">${esc(x.why)}</span><span class="tiny muted">${ago(x.at)}</span></div>`).join('')}</div>` : ''}
    <div class="card"><h2>Reviews</h2>${o.reviews.map(r => `<div class="review"><div class="row"><b>u/${esc(r.by)}</b><span class="pstars small">${stars(r.stars)}</span></div><div class="small">${esc(r.text)}</div></div>`).join('') || '<div class="small muted">Nobody has reviewed it yet.</div>'}</div>
    <div class="card"><div class="row"><input id="ilabel" value="${esc(o.label)}" maxlength="24" style="flex:1"><button class="btn ghost small" data-act="itemLabel">Relabel</button></div></div></div>`;
}

// ---------- Orgasm control ----------
function wheelSvg(slices, rotate = 0) {
  const total = slices.reduce((a, s) => a + s.w, 0);
  let a0 = 0;
  const arc = (a, b) => { const r = 48, p = x => [50 + r * Math.sin(x), 50 - r * Math.cos(x)]; const [x0, y0] = p(a), [x1, y1] = p(b); return `M50 50 L${x0} ${y0} A${r} ${r} 0 ${b - a > Math.PI ? 1 : 0} 1 ${x1} ${y1} Z`; };
  return `<svg viewBox="0 0 100 100" class="wheel" style="transform:rotate(${rotate}deg)">${slices.map(s => { const a = (a0 / total) * Math.PI * 2, b = ((a0 + s.w) / total) * Math.PI * 2; const mid = (a + b) / 2; a0 += s.w; return `<path d="${arc(a, b)}" fill="${s.color}" stroke="#0b0710" stroke-width=".6"/>${b - a < 0.42 ? '' : `<text x="${50 + 30 * Math.sin(mid)}" y="${50 - 30 * Math.cos(mid)}" transform="rotate(${(mid * 180) / Math.PI} ${50 + 30 * Math.sin(mid)} ${50 - 30 * Math.cos(mid)})" text-anchor="middle" dominant-baseline="middle">${esc(s.label)}</text>`}`; }).join('')}<circle cx="50" cy="50" r="7" fill="#0b0710"/></svg>`;
}
async function viewOrgasm(spun) {
  const o = await api('/orgasm');
  main.innerHTML = `<div class="narrow orgpage"><h1>🎡 Beg to cum</h1>
    ${o.enabled ? '' : '<div class="card small muted">Orgasm control is off (Admin → Controls).</div>'}
    <div class="ostats"><div><b>${o.tokens}</b><span>tokens left</span></div><div><b>${o.edgesToday}</b><span>edges today</span></div><div><b>${o.daysSince === null ? '—' : Math.floor(o.daysSince)}</b><span>days since</span></div><div><b>${o.holder ? esc(o.holder.slice(0, 8)) : '—'}</b><span>holds them</span></div></div>
    <div class="card wheelcard"><div class="pointer">▼</div><div id="wheelbox">${wheelSvg((o.spins[0] || { slices: [{ label: 'Denied', w: 38, color: '#3a2f4a' }, { label: 'One more day', w: 20, color: '#56406b' }, { label: 'Ruined', w: 20, color: '#b0304f' }, { label: 'Allowed', w: 14, color: '#d9a441' }, { label: 'Clean up', w: 8, color: '#ff6f9c' }] }).slices)}</div>
      <div id="spinres" class="spinres">${o.spins[0] ? `last: <b>${esc(o.spins[0].label)}</b> · ${ago(o.spins[0].at)}` : 'Everyone sees the result.'}</div>
      <textarea id="begtext" rows="2" placeholder="beg properly…"></textarea>
      <div class="row" style="margin-top:8px"><button class="btn" data-act="begSpin" ${o.canBeg ? '' : 'disabled'}>🙏 Beg & spin</button><a class="btn ghost" href="#/stroke">🥁 Stroke session</a></div>
      ${o.canBeg ? '' : '<div class="tiny muted" style="margin-top:6px">You begged too recently.</div>'}</div>
    ${o.spins.length ? `<div class="card"><h2>History</h2>${o.spins.map(s => `<div class="otask"><span class="grow"><b>${esc(s.label)}</b> <span class="tiny muted">${s.adds.map(a => `+${esc(a.slice)} by u/${esc(a.by)}`).join(', ')}</span></span><span class="tiny muted">${ago(s.at)}</span></div>`).join('')}</div>` : ''}</div>`;
}
async function spinWheel(btn) {
  btn.disabled = true;
  let r;
  try { r = await api('/orgasm/beg', { reason: $('#begtext').value }); } catch (err) { toast(err.message, 1); btn.disabled = false; return; }
  if (r.hushed) { location.hash = '#/home'; return; }
  const total = r.slices.reduce((a, s) => a + s.w, 0);
  let a0 = 0, mid = 0;
  for (const s of r.slices) { if (s.key === r.result) { mid = ((a0 + s.w / 2) / total) * 360; break; } a0 += s.w; }
  $('#wheelbox').innerHTML = wheelSvg(r.slices, 0);
  $('#spinres').innerHTML = r.adds.length ? r.adds.map(a => `u/${esc(a.by)} added a <b>${esc(a.slice)}</b> slice`).join(' · ') : 'spinning…';
  const w = $('#wheelbox .wheel');
  requestAnimationFrame(() => { w.style.transition = 'transform 5s cubic-bezier(.12,.6,.1,1)'; w.style.transform = `rotate(${360 * 6 - mid}deg)`; });
  setTimeout(() => { $('#spinres').innerHTML = `<b class="big">${esc(r.label)}</b><br><span class="tiny muted">${r.by ? `u/${esc(r.by)} is texting you` : ''} · ${r.tokensLeft} token${r.tokensLeft === 1 ? '' : 's'} left</span>`; if (navigator.vibrate) navigator.vibrate([80, 60, 160]); }, 5200);
}
async function viewStroke() {
  const s = await api('/orgasm/session', {});
  document.getElementById('trance')?.remove();
  const el = document.createElement('div');
  el.id = 'trance';
  el.className = 'stroke';
  el.innerHTML = `<div class="tbox"><div class="tby">u/${esc(s.by)}</div><div class="beat" id="beat"></div><div class="cmd" id="cmd"></div><div class="tline in" id="sline"></div><div class="row" style="justify-content:center;margin-top:22px"><button class="btn" data-act="edged">I'm on the edge</button></div><div class="tiny" style="opacity:.7;margin-top:10px">edges: <b id="edges">0</b></div></div><button class="wake" data-act="wake">Stop</button>`;
  document.body.appendChild(el);
  let stop = false, edges = 0;
  S.stroke = { id: s.id };
  S.trance = () => { stop = true; el.remove(); S.trance = null; api('/orgasm/done', { id: s.id }).catch(() => {}); location.hash = '#/orgasm'; };
  const beat = $('#beat'), cmd = $('#cmd'), line = $('#sline');
  let li = 0;
  const say = () => { line.textContent = s.lines[li++ % s.lines.length]; };
  for (const ph of s.phases) {
    if (stop) break;
    cmd.textContent = ph.cmd === 'stop' ? (ph.final ? 'STOP. hands off. done.' : 'STOP. hands off.') : ph.cmd === 'slow' ? `slow · ${ph.bpm}` : `stroke · ${ph.bpm}`;
    el.classList.toggle('halt', ph.cmd === 'stop');
    say();
    beat.style.animationDuration = ph.cmd === 'stop' ? '0s' : `${60 / ph.bpm}s`;
    await new Promise(r => setTimeout(r, ph.secs * 1000));
  }
  S.onEdge = () => { edges++; $('#edges').textContent = edges; };
  if (!stop) S.trance && S.trance();
}

async function viewMuseum() {
  const m = await api('/museum');
  main.innerHTML = `<div class="narrow museum"><h1>🏛 The Museum</h1>
    <div class="tiny muted" style="margin-bottom:12px">A permanent exhibition of you, curated by the women who own you. Visitors from all over the site walk through and comment.${m.waiting ? ` ${m.waiting} more pic${m.waiting === 1 ? '' : 's'} waiting to be curated.` : ''}</div>
    ${m.exhibits.length ? `<div class="wall">${m.exhibits.map(x => `<a class="exhibit ${x.kind}" href="#/post/${x.id}"><div class="frame"><img src="${esc(x.image)}" alt="" loading="lazy"></div>
      <div class="plaque"><div class="pn">No. ${x.n}${x.kind === 'worst' ? ' · hall of shame' : ' · highlights'}</div><b>${esc(x.title)}</b><p>${esc(x.caption)}</p>
      <div class="pm">donated by u/${esc(x.by)}${x.rating ? ` · rated ${x.rating.toFixed(1)}/10` : ''} · 💬 ${x.visitors}</div></div></a>`).join('')}</div>`
      : '<div class="card small muted">The walls are empty for now. Exhibits appear once you\'ve sent proof pics (RateHim demands, photo tasks, the body auction).</div>'}</div>`;
}
async function viewProofs() {
  const list = await api('/proofs');
  main.innerHTML = `<div class="narrow"><h1>📸 Proof gallery</h1><div class="tiny muted" style="margin-bottom:10px">Photos you sent that closed a task. Only you can see this page.</div>
    ${list.length ? `<div class="proofs big">${list.map(p => `<a href="${p.link}"><figure><img src="${esc(p.image)}" alt="" loading="lazy"><figcaption><b>u/${esc(p.by)}</b><br><span class="tiny muted">${esc(p.task)} · ${ago(p.at)}</span></figcaption></figure></a>`).join('')}</div>` : '<div class="card small muted">No proofs yet. Send a photo when a task asks for one.</div>'}</div>`;
}

// ---------- Trance ----------
async function viewTrance(id) {
  if (!id) {
    const h = await api('/hub');
    main.innerHTML = `<div class="narrow"><h1>🌀 Trance</h1>
      <div class="card" style="margin-bottom:12px"><button class="btn" data-act="seedDickless">🌀 Seed Dickless Sissy Hypno</button>
        <div class="tiny muted">Injects the extreme dickless-sissy + piss-drinking session (trigger: dickless)</div></div>
      <div class="card"><div class="small" style="margin-bottom:10px">She writes you a session: a slow spiral, her words, and mantras you type back to sink deeper. At the end she plants a trigger word she can use in your DMs. <b>Wake up</b> (or Esc) ends it any time.</div>
      <div class="row wrap">${[['obey', 'Obey'], ['owned', 'Owned'], ['denial', 'Denial'], ['cuck', 'Cuck']].map(([t, l]) => `<button class="btn small${t === 'cuck' ? ' ghost' : ''}" data-act="tranceStart" data-theme="${t}">${l}</button>`).join('')}</div></div>
      ${h.trances.length ? `<h3>Past sessions</h3><div class="card list0">${h.trances.map(t => `<a class="otask" href="#/trance/${t.id}"><span class="grow">"${esc(t.title)}" <span class="tiny muted">u/${esc(t.by)} · ${esc(t.theme)}</span></span><span class="tiny muted">depth ${t.depth}/10</span></a>`).join('')}</div>` : ''}</div>`;
    return;
  }
  const s = await api('/trance/' + encodeURIComponent(id));
  runTrance(s);
}
function runTrance(s) {
  document.getElementById('trance')?.remove();
  const el = document.createElement('div');
  el.id = 'trance';
  el.innerHTML = `<div class="spiral"></div><div class="tbox"><div class="tby">u/${esc(s.by)}</div><div class="tline" id="tline"></div><div class="tinput" hidden><input id="tmantra" autocomplete="off" autocapitalize="off" spellcheck="false" placeholder="type it…"></div><div class="depth"><i id="tdepth"></i></div></div><button class="wake" data-act="wake">Wake up</button>`;
  document.body.appendChild(el);
  const line = $('#tline'), inp = $('#tmantra'), box = el.querySelector('.tinput');
  let depth = 0, stop = false;
  S.trance = () => { stop = true; el.remove(); if (depth) api('/trance/done', { id: s.id, depth }).catch(() => {}); S.trance = null; };
  const say = (t, ms = 3600) => new Promise(r => { if (stop) return r(); line.classList.remove('in'); setTimeout(() => { line.textContent = t; line.classList.add('in'); setTimeout(r, ms); }, 500); });
  const norm = t => t.toLowerCase().replace(/[^\p{L}\p{N} ]/gu, '').replace(/\s+/g, ' ').trim();
  const close = (a, b) => { const x = norm(a), y = norm(b); if (!y) return false; const w = y.split(' '); const hit = w.filter(t => x.includes(t)).length; return hit / w.length >= 0.75; };
  const typeBack = m => new Promise(r => {
    if (stop) return r();
    line.classList.remove('in'); setTimeout(() => { line.textContent = m; line.classList.add('in', 'mantra'); }, 400);
    box.hidden = false; inp.value = ''; setTimeout(() => inp.focus(), 450);
    inp.onkeydown = e => { if (e.key === 'Enter') { const typed = inp.value; if (!close(typed, m)) api('/safeword/try', { text: typed }).then(r => { if (r.hushed && S.trance) S.trance(); }).catch(() => {}); if (close(inp.value, m)) { box.hidden = true; line.classList.remove('mantra'); depth = Math.min(10, depth + Math.ceil(10 / s.mantras.length)); $('#tdepth').style.width = depth * 10 + '%'; r(); } else { inp.classList.remove('shake'); void inp.offsetWidth; inp.classList.add('shake'); } } };
  });
  (async () => {
    for (const t of s.intro) await say(t);
    for (let i = 0; i < s.mantras.length && !stop; i++) {
      await typeBack(s.mantras[i]);
      if (s.deepeners[i]) await say(s.deepeners[i], 3200);
    }
    if (!stop) { await say(`when you hear "${s.trigger}"…`, 4200); await say('you drop right back here.', 3600); }
    for (const t of s.outro) await say(t);
    if (!stop) { depth = Math.max(depth, 3); await say(`depth ${depth}/10`, 2500); S.trance && S.trance(); location.hash = '#/trance'; }
  })();
}
// her trigger word in a chat: a short drop
function miniTrance(m) {
  if (document.getElementById('trance')) return;
  const el = document.createElement('div');
  el.id = 'trance';
  el.className = 'mini';
  el.innerHTML = `<div class="spiral"></div><div class="tbox"><div class="tby">u/${esc(m.author)}</div><div class="tline in">${esc(m.body)}</div><div class="tiny" style="opacity:.7;margin-top:18px">tap to come back</div></div>`;
  el.onclick = () => el.remove();
  document.body.appendChild(el);
  setTimeout(() => el.remove(), 9000);
}
document.addEventListener('keydown', e => { if (e.key === 'Escape' && S.trance) S.trance(); });

async function viewOwned() {
  const o = await api('/owned');
  const tl = t => `<a class="otask${t.due && t.due - Date.now() < 3600e3 ? ' hot' : ''}" href="#/dm/${encodeURIComponent(t.thread)}"><span class="grow"><b>${t.ultimatum ? '⚠️ ' : t.statement ? '📝 ' : '🎯 '}${esc(t.text)}</b>${t.from ? `<span class="tiny muted"> · u/${esc(t.from)}</span>` : ''}${t.extendAsked && !t.extendDecided ? '<span class="tiny muted"> · begged for time</span>' : ''}</span>${t.due ? `<span class="tdue small" data-due="${t.due}">⏱ ${leftText(t.due)}</span>` : '<span class="tiny muted">no deadline</span>'}</a>`;
  const st = o.standing;
  const stand = st.state === 'suspended' ? `<span class="danger-text">Suspended</span> until ${new Date(st.suspendedUntil).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })}` : st.recent ? `${st.recent} strike${st.recent === 1 ? '' : 's'} this week` : 'Clean';
  main.innerHTML = `<div class="narrow owned">
    <h1>🔒 Owned</h1>
    <a class="card offer" href="#/claim">🔨 <b>The Claim</b>: who bought which part of you, and when the next proof is due →</a>
    <div class="ostats"><div><b>${o.owners.length}</b><span>owner${o.owners.length === 1 ? '' : 's'}</span></div><div><b>${o.owners.reduce((a, x) => a + x.tasks.length, 0) + o.other.length}</b><span>open tasks</span></div><div><b>${o.cases.length}</b><span>open cases</span></div><div><b>${fmtN(o.karma)}</b><span>karma</span></div></div>
    <div class="card small">Account: <b>${stand}</b></div>
    ${o.offers.map(k => `<a class="card offer" href="#/dm/${encodeURIComponent(k.thread)}">📜 <b>u/${esc(k.from)}</b> sent you an agreement. Read it and sign or decline →</a>`).join('')}
    ${o.cases.length ? `<div class="card"><h2>🚔 Police cases</h2>${o.cases.map(c => `<a class="otask hot" href="#/dm/${o.police}"><span class="grow"><b>${NOTICE_NAME[c.kind] || 'Notice'} · ${esc(c.caseNo)}</b><span class="tiny muted"> · complainant u/${esc(c.complainant)} · fine ${c.fine} karma${c.status === 'penalty' ? ' · statement owed' : c.status === 'pleading' ? ' · plea pending' : ''}</span></span><span class="tdue small" data-due="${c.due}">⏱ ${leftText(c.due)}</span></a>`).join('')}<div class="tiny muted" style="margin-top:6px">Open the police chat to pay, accept the penalty or plead. Ignoring a notice gets a warrant.${o.closed ? ` ${o.closed} closed so far.` : ''}</div></div>` : ''}
    ${o.owners.length ? o.owners.map(w => `<div class="card owner">
      <div class="row">${avatar(w.username, 44)}<div class="grow"><a href="#/dm/${w.id}"><b>u/${esc(w.username)}</b></a><div class="tiny muted">owns you since ${ago(w.since)} ago · ${w.done} done · ${w.failed} failed${w.breaches ? ` · <span class="danger-text">${w.breaches} breach${w.breaches === 1 ? '' : 'es'}</span>` : ''}</div></div><a class="btn small ghost" href="#/dm/${w.id}">Chat</a></div>
      <details><summary class="small muted">The agreement (${w.terms.length} terms)</summary><ol class="small">${w.terms.map(t => `<li>${esc(t)}</li>`).join('')}</ol></details>
      ${w.tasks.length ? w.tasks.map(tl).join('') : '<div class="tiny muted" style="margin-top:6px">No open tasks. More will come.</div>'}
      ${w.crew ? `<div class="crew"><a href="#/dm/${encodeURIComponent(w.crew.id)}">🕴️ <b>${esc(w.crew.name)}</b></a> <span class="danger-text small">debt: ${w.crew.debt}</span>${w.crew.tasks.map(tl).join('')}</div>` : ''}
    </div>`).join('') : '<div class="card small muted">Nobody owns you yet. Doms send agreements on their own, sometimes after a bounty goes up in the Vault.</div>'}
    ${o.other.length ? `<div class="card"><h2>Other demands</h2>${o.other.map(tl).join('')}</div>` : ''}
    ${o.threats.length ? `<div class="card"><h2>Who's after you</h2>${o.threats.map(t => `<a class="otask" href="#/dm/${t.id}"><span class="grow">u/${esc(t.username)}${t.burner ? ' <span class="tiny muted">burner</span>' : ''}</span><span class="tiny muted">${t.stage ? ['', 'sniping your posts', 'called you out', 'leaked your chats', 'threatening you', 'threatening you', 'went quiet'][Math.floor(t.stage)] || '' : 'angry'}</span></a>`).join('')}</div>` : ''}
    ${o.vault.length ? `<div class="card vaultcard"><h2>🕳 About you in the Vault</h2>${o.vault.map(v => `<a class="otask" href="#/post/${v.id}"><span class="grow">${v.kind === 'leak' ? '📸' : '💀'} ${esc(v.title)}</span><span class="tiny muted">${ago(v.created)}</span></a>`).join('')}</div>` : ''}
  </div>`;
}

function viewSubs() {
  const list = [...S.subs].sort((a, b) => (a.archived - b.archived) || (b.born || 0) - (a.born || 0) || b.members - a.members);
  main.innerHTML = `<div class="narrow"><h1>Subreddits</h1><div class="list"><a class="prow vaultrow" href="#/r/TheVault"><span class="vdot">🕳</span><span class="grow"><b>r/TheVault</b><br><span class="muted small">Invite only. Anonymous.</span></span></a>${list.map(s => `<a class="prow" href="#/r/${s.name}" style="${s.archived ? 'opacity:.5' : ''}">${subDot(s.name)}<span class="grow" style="min-width:0"><b>r/${esc(s.name)}</b>${s.born && Date.now() - s.born < 3 * 864e5 ? ' <span class="tag you">new</span>' : ''}${s.archived ? ' <span class="tiny muted">dead</span>' : ''}<br><span class="muted small">${esc(s.title)}</span></span><span class="muted small" style="text-align:right;white-space:nowrap">${fmtN(s.members)} members<br>${s.archived ? '' : liveDot(s.online)}</span></a>`).join('')}</div></div>`;
}

// ---------- post page ----------
function buildTree(comments) {
  const kids = {};
  comments.forEach(c => { (kids[c.parentId || 'root'] = kids[c.parentId || 'root'] || []).push(c); });
  Object.values(kids).forEach(a => a.sort((x, y) => y.score - x.score || x.created - y.created));
  return kids;
}
function renderComment(c, kids, op, hl, depth = 0) {
  const ch = kids[c.id] || [];
  return `<div class="cmt${c.id === hl ? ' hl' : ''}" id="c-${c.id}">
    <div class="chead">${avImg(c.author)}${authorLink(c.author, op)}<span class="sep">•</span>${ago(c.created)}${c.removed ? ' <span class="tag removed">removed</span>' : ''}<span class="grow"></span><span class="collapse" data-act="collapse" title="Collapse thread">${ch.length ? '–' : ''}</span></div>
    <div class="cbody">
      ${c.claim && c.claim.amount ? `<div class="claimtag">${c.claim.kind === 'buyout' ? '🔥 buyout' : '🔨 bid'} on the <b>${esc(c.claim.spot)}</b>${c.claim.write ? ` · writes <b class="ink">${esc(c.claim.write)}</b>` : ''}</div>` : ''}
      ${c.rating ? `<span class="rscore">${c.rating}/10</span>` : ''}<div class="ctext">${md(c.body)}</div>${c.image ? `<img class="cimg" src="${esc(c.image)}" alt="Proof photo" loading="lazy">` : ''}
      ${c.removed && c.removedReason ? `<div class="removedNote">Removed by mods: ${esc(c.removedReason)}</div>` : ''}
      <div class="actions">${voteBox('comment', c, true)}
        <button class="linkbtn" data-act="reply" data-id="${c.id}">${I.reply}Reply</button>
        ${c.mine ? `<button class="linkbtn" data-act="delete" data-kind="comment" data-id="${c.id}">${I.trash}Delete</button>` : `<button class="linkbtn" data-act="report" data-kind="comment" data-id="${c.id}" title="Report">${I.flag}</button>`}
      </div>
      <div class="replyslot"></div>
      ${ch.length ? `<div class="kids">${ch.map(x => renderComment(x, kids, op, hl, depth + 1)).join('')}</div>` : ''}
    </div></div>`;
}
async function viewPost(id, hl) {
  const { post: p, comments, ban } = await api('/post/' + id);
  if (S.postId !== id) S.composerOpen = false;
  S.postId = id;
  const kids = buildTree(comments);
  main.innerHTML = `<div class="narrow"><article class="post-page">
    <div class="row" style="margin-bottom:6px"><a class="linkbtn" style="margin-left:-9px" href="javascript:history.back()">${I.back}Back</a></div>
    <div class="meta"><a class="subchip" href="#/r/${p.sub}">${subDot(p.sub)}r/${esc(p.sub)}</a><span class="sep">•</span>${ago(p.created)}</div>
    <div class="meta" style="margin-top:4px">${avImg(p.author)}${authorLink(p.author)}${p.removed ? ' <span class="tag removed">removed</span>' : ''}</div>
    <div class="ptitle">${esc(p.title)}</div>
    ${p.image ? mediaTag(p.image, p.mediaType !== 'video', p.mediaType) : ''}
    ${p.shot ? shotTag(p.shot) : ''}
    ${p.body ? `<div class="ptext" style="margin-top:8px">${md(p.shot ? withoutQuotes(p.body) : p.body)}</div>` : ''}
    ${p.demand ? `<div class="demandbox ${p.demand.status}">${p.demand.status === 'answered' ? `✅ You answered. <a href="#/post/${p.demand.answer}"><u>See the ratings</u></a>` : `${p.demand.status === 'missed' ? '⛔ You missed this one. Answering late gets noticed.' : `📏 Demand · <span class="tdue" data-due="${p.demand.due}">⏱ ${leftText(p.demand.due)}</span>`}<button class="btn small" data-act="ratePhoto" data-id="${p.id}">📸 Answer with a photo</button>`}<input type="file" id="rateFile" accept="image/*" capture="environment" hidden data-post="${p.id}"></div>` : ''}
    ${p.rated && p.rated.n ? `<div class="ratebig">${p.rated.avg.toFixed(1)}<span>/10 · ${p.rated.n} rating${p.rated.n === 1 ? '' : 's'}${p.rated.late ? ' · late' : ''}</span></div>` : ''}
    ${p.removed && p.removedReason ? `<div class="removedNote">This post was removed by the mods of r/${esc(p.sub)}: ${esc(p.removedReason)}</div>` : ''}
    <div class="actions">${voteBox('post', p)}<span class="chip" style="cursor:default">${I.comment}${fmtN(p.comments)}</span>
      ${p.mine ? `<button class="chip" data-act="delete" data-kind="post" data-id="${p.id}">${I.trash}Delete</button>` : `<button class="chip" data-act="report" data-kind="post" data-id="${p.id}">${I.flag}Report</button>`}</div>
  </article>
  ${ban ? `<div class="banbox">You're banned from r/${esc(p.sub)}, so you can't comment. <a href="#/dm/mod:${p.sub}"><u>Appeal</u></a></div>`
    : p.removed ? '' : `<div class="composer${S.composerOpen ? ' open' : ''}" id="composer"><button class="fake" data-act="openComposer">Join the conversation</button>
      <div class="real replybox"><textarea id="topReply" placeholder="Say something"></textarea><div class="row" style="justify-content:flex-end;margin-top:6px"><button class="linkbtn" data-act="closeComposer">Cancel</button><button class="btn small" data-act="sendComment">Comment</button></div></div></div>`}
  <div class="comments">${(kids.root || []).map(c => renderComment(c, kids, p.author.name, hl)).join('') || '<div class="empty"><b>No comments yet</b>Replies come in over minutes and hours, like on the real thing.</div>'}</div></div>`;
  if (hl) setTimeout(() => $('#c-' + hl)?.scrollIntoView({ block: 'center' }), 50);
}

// ---------- submit ----------
function viewSubmit(sub) {
  main.innerHTML = `<div class="narrow"><h1>New post</h1><div class="card">
    <label>Subreddit</label><select id="psub">${S.subs.map(s => `<option ${s.name === sub ? 'selected' : ''}>${esc(s.name)}</option>`).join('')}</select>
    <label>Photo, GIF or video</label>
    <label class="btn ghost" style="width:100%;margin:0;color:var(--text)"><input type="file" id="pimg" accept="image/*,video/*" hidden>Add a photo, GIF or video</label>
    <div id="pprev" style="margin-top:8px"></div>
    <label>Title</label><input id="ptitle" maxlength="300" placeholder="Title">
    <label>Text (optional)</label><textarea id="pbody" placeholder="Caption or story"></textarea>
    <p class="tiny muted">Only post yourself, consenting adults, or AI-generated people.</p>
    <button class="btn" style="width:100%;margin-top:6px" id="pgo">Post</button></div></div>`;
  let m = null;
  S.clearMedia = () => { m = null; $('#pprev').innerHTML = ''; $('#pimg').value = ''; };
  $('#pimg').onchange = async e => {
    const f = e.target.files[0];
    if (!f) return;
    $('#pgo').disabled = true;
    $('#pprev').innerHTML = `<div class="small muted">${kindOfFile(f) === 'image' ? 'Loading photo…' : 'Uploading…'}</div>`;
    try {
      m = await prepareMedia(f, pc => { $('#pprev').innerHTML = `<div class="small muted">Uploading… ${Math.round(pc * 100)}%</div>`; });
      $('#pprev').innerHTML = mediaPreview(m, 'Remove');
      if (m.kind !== 'image' && !m.sheet) toast('Uploaded. This browser couldn\'t read frames from it, so people will react to your title.', 1);
    } catch (err) { m = null; $('#pprev').innerHTML = ''; toast(err.message, 1); }
    finally { $('#pgo').disabled = false; }
  };
  $('#pgo').onclick = async () => {
    const btn = $('#pgo');
    btn.disabled = true;
    try {
      const p = await api('/post', { sub: $('#psub').value, title: $('#ptitle').value, body: $('#pbody').value, image: m?.image, media: m?.media, sheet: m?.sheet || undefined });
      location.hash = '#/post/' + p.id;
      toast('Posted. Replies take a few minutes to start.');
    } catch (e) { toast(e.message, 1); btn.disabled = false; }
  };
}

// ---------- inbox ----------
async function viewInbox(tab) {
  tab = tab || 'messages';
  const data = await api('/inbox');
  S.unread = data.unread;
  setBadges();
  const icon = t => ({ reply: '💬', mod: '🛡', dm: '✉', site: '🌱' }[t] || '🔔');
  let body = '';
  if (tab === 'notifications') {
    body = data.notifications.length ? `<div class="list">${data.notifications.map(n => `<a class="nitem${n.read ? '' : ' unread'}" href="${esc(n.link || '#/inbox')}">
      <div class="ic ${n.type}">${icon(n.type)}</div><div class="grow"><div class="small">${md(n.text)}</div><div class="tiny muted">${ago(n.created)}</div></div>${n.read ? '' : '<span class="dot"></span>'}</a>`).join('')}</div>`
      : '<div class="empty"><b>Nothing yet</b>Replies to your posts and comments show up here.</div>';
  } else {
    const list = data.threads.filter(t => (tab === 'modmail' ? t.kind === 'mod' : t.kind === 'dm'));
    body = list.length ? `<div class="list">${list.map(t => `<a class="nitem${t.unread ? ' unread' : ''}" href="#/dm/${encodeURIComponent(t.id)}">
      ${t.kind === 'mod' ? '<div class="ic mod">🛡</div>' : t.kind === 'group' ? `<div class="ic site" style="font-size:20px">${t.gtype === 'domme' ? '👑' : t.gtype === 'mafia' ? '🕴️' : t.gtype === 'cuck' ? '🤤' : t.gtype === 'sissyshow' ? '🎀' : '👥'}</div>` : avatar(t.name, 44)}
      <div class="grow" style="min-width:0"><div class="small"><b>${t.kind === 'mod' ? esc(t.name) : 'u/' + esc(t.name)}</b> <span class="muted tiny">· ${ago(t.at)}</span></div>
      <div class="small muted" style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${t.lastFromMe ? 'You: ' : ''}${esc(t.last)}</div></div>${t.unread ? '<span class="dot"></span>' : ''}</a>`).join('')}</div>`
      : `<div class="empty">${tab === 'modmail' ? '<b>No modmail</b>Messages to and from sub mods show up here.' : '<b>No messages yet</b>Post something and people will start sliding in.'}</div>`;
  }
  const unreadN = data.notifications.filter(n => !n.read).length;
  const dmUnread = data.threads.filter(t => t.kind === 'dm').reduce((a, t) => a + t.unread, 0);
  const modUnread = data.threads.filter(t => t.kind === 'mod').reduce((a, t) => a + t.unread, 0);
  main.innerHTML = `<div class="narrow"><h1>Inbox</h1><div class="tabs">
    <a href="#/inbox/messages" class="${tab === 'messages' ? 'on' : ''}">Messages${dmUnread ? ` (${dmUnread})` : ''}</a>
    <a href="#/inbox/notifications" class="${tab === 'notifications' ? 'on' : ''}">Notifications${unreadN ? ` (${unreadN})` : ''}</a>
    <a href="#/inbox/modmail" class="${tab === 'modmail' ? 'on' : ''}">Modmail${modUnread ? ` (${modUnread})` : ''}</a>
    <a href="#/owned">🔒 Owned</a>
    ${tab === 'notifications' && unreadN ? '<span class="grow"></span><button class="linkbtn" data-act="readAll">Mark all read</button>' : ''}
  </div>${body}</div>`;
}

// group bubbles; show a time label only when there's a real gap, like messaging apps do
function chatBubbles(t) {
  const isMod = t.kind === 'mod', isGroup = t.kind === 'group';
  let lastT = 0, lastFrom = '', sawBefore = false;
  const html = t.messages.map(m => {
    const gap = m.created - lastT > 45 * 60e3;
    lastT = m.created;
    let pre = gap ? `<div class="daysep">${new Date(m.created).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })}</div>` : '';
    if (m.beforeMe && !sawBefore) { sawBefore = true; pre = '<div class="daysep before">Messages from before you were added 👀</div>' + pre; }
    if (m.system) { lastFrom = ''; return `${pre}<div class="sysline">${esc(m.body)}</div>`; }
    const who = isGroup && !m.mine && (m.author !== lastFrom || gap) ? `<div class="gfrom">${avImg({ name: m.author })}<a href="#/u/${encodeURIComponent(m.author)}">${esc(m.author)}</a></div>` : '';
    lastFrom = m.mine ? '' : m.author;
    const media = m.viewOnce
      ? `<button class="vo${m.viewed ? ' opened' : ''}" data-act="viewOnce" data-id="${m.id}" ${m.viewed ? 'disabled' : ''}>${m.viewed ? '○ Opened' : `◉ ${m.mediaType === 'video' ? 'Video' : 'Photo'} · tap to view once`}</button>`
      : m.image ? `<a href="${esc(m.image)}" target="_blank">${imgTag(m.image, 'pimg')}</a>` : '';
    const shot = m.shot ? shotTag(m.shot) : '';
    const task = m.task ? taskCard(m) : '';
    const notice = m.notice ? noticeCard(m.notice) : '';
    const k = m.contract;
    const contract = k ? `<div class="contract ${k.status}"><div class="ktitle">📜 Slave agreement</div><div class="tiny muted">from u/${esc(m.author)}</div><ol>${k.terms.map(x => `<li>${esc(x)}</li>`).join('')}</ol><div class="small kcons">If you break it: ${esc(k.consequences)}</div>
      ${k.status === 'pending' ? `<div class="row" style="margin-top:10px"><button class="btn small" data-act="contract" data-id="${k.id}" data-a="1">Accept</button><button class="btn ghost small" data-act="contract" data-id="${k.id}" data-a="0">Decline</button></div>`
        : `<div class="kstat">${{ accepted: `✍️ Signed${k.breaches ? ` · broken ${k.breaches}×` : ''}`, declined: '✖ Declined', void: '📜 Cancelled' }[k.status] || ''}</div>`}</div>` : '';
    return `${pre}${who}<div class="bubble ${m.mine ? 'mine' : 'theirs'}${m.pending ? ' pending' : ''}${m.muted ? ' muted' : ''}" data-mid="${m.id}">${media}${m.body ? md(m.body) : ''}${m.muted ? '<span class="mutestamp">🔇 the object made a noise</span>' : ''}${shot}${isMod && !m.mine ? `<span class="t">u/${esc(m.author)}</span>` : ''}</div>${task}${notice}${contract}`;
  }).join('');
  return (html || '<div class="empty"><b>Say hi</b>Messages here are private.</div>') + (t.typing ? '<div class="bubble theirs dots" aria-label="typing"><span></span><span></span><span></span></div>' : '');
}
const nearBottom = () => window.innerHeight + window.scrollY >= document.body.scrollHeight - 160;
// refresh just the messages (keeps whatever you're typing); called every couple of seconds while a chat is open
// a leaked chat screenshot (an image the server draws from your real messages); tap to enlarge
const shotTag = id => `<img class="shot" src="/shot/${encodeURIComponent(id)}.svg" alt="Chat screenshot" loading="lazy" data-act="shotZoom">`;
// the screenshot already shows the quoted texts, so hide the quote block under it
const withoutQuotes = body => String(body).split('\n').filter(l => !/^>\s?/.test(l) && !/^📸 screenshots:?$/.test(l.trim())).join('\n').trim();
// time left on a deadline, e.g. "3h 12m left"
function leftText(due) {
  const ms = due - Date.now();
  if (ms <= 0) return 'deadline passed';
  const m = Math.round(ms / 60000), h = Math.floor(m / 60);
  return h ? `${h}h ${m % 60}m left` : `${m}m left`;
}
function taskCard(m) {
  const t = m.task, open = t.status === 'open';
  const label = t.statement ? '📝 Penalty' : t.ultimatum ? '⚠️ Ultimatum' : '🎯 Task';
  const stat = t.status === 'done' ? '✅ done' : t.status === 'failed' ? (t.refused ? '✋ refused' : '❌ failed') : '';
  const ext = t.extendDecided === 'granted' ? '<span class="tiny okay">+ more time granted</span>' : t.extendDecided === 'denied' ? '<span class="tiny danger-text">more time denied</span>' : t.extendAsked ? '<span class="tiny muted">begged for more time…</span>' : '';
  const btns = open && !m.mine && !t.statement ? `<div class="tbtns">
      <button class="btn small" data-act="doTask" data-kind="${t.kind}">${t.kind === 'photo' ? '📸 Send proof' : '✍️ Do it'}</button>
      ${t.due && !t.extendAsked ? `<button class="btn ghost small" data-act="taskMore" data-mid="${m.id}">⏳ Beg for time</button>` : ''}
      <button class="btn ghost small" data-act="taskRefuse" data-mid="${m.id}">✋ Refuse</button></div>`
    : open && t.statement ? `<div class="tbtns"><button class="btn small" data-act="doTask" data-kind="text">✍️ Write statement</button></div>` : '';
  const standin = open && (t.sissy === 'finish' || /finish|load|cum|bukkake|glaze|facial|nut|yogurt|lotion/i.test(t.text)) ? '<div class="standin">🧴 stand-in: food-safe in your mouth (yogurt, condensed milk) · lotion on your body · never near your eyes · nothing irritating on your genitals</div>' : '';
  return `<div class="taskcard ${t.status}${t.ultimatum ? ' ulti' : ''}${t.sissy ? ' sissy' : ''}"><div class="thead"><b>${t.furniture ? '🪑 Furniture duty' : t.sissy ? '🎀 ' + (t.sissy === 'dress' ? 'Dress order' : t.sissy === 'night' ? 'Night check' : t.sissy === 'finish' ? 'He finished on you' : t.sissy === 'use' ? 'Used' : 'Training') : t.orgasm ? '🎡 ' + (t.orgasm === 'ruined' ? 'Ruin it' : t.orgasm === 'cleanup' ? 'Clean up' : 'Allowed') : label}</b><span class="tstat">${stat}</span></div><div class="ttext">${esc(t.text)}</div>${standin}
    ${open && t.due ? `<div class="tdue" data-due="${t.due}">⏱ ${leftText(t.due)}</div>` : ''}${ext}${btns}</div>`;
}
const NOTICE_NAME = { intimation: 'Intimation', fir: 'FIR', seizure: 'Seizure order', complaint: 'Additional complaint', warrant: 'Warrant' };
function noticeCard(n) {
  const live = ['open', 'pleading', 'penalty'].includes(n.status);
  const done = { paid: '💸 Fine paid', served: '📝 Statement accepted', dismissed: '⚖️ Dismissed', ignored: '⛔ Ignored — warrant issued', superseded: 'Replaced by a newer notice' }[n.status] || '';
  return `<div class="noticecard ${n.status}"><div class="thead"><b>🚔 ${NOTICE_NAME[n.kind] || 'Notice'}</b><span class="tiny muted">Case ${esc(n.caseNo || '')}</span></div>
    ${live ? `<div class="small">Fine <b>${n.fine} karma</b> · <span class="tdue" data-due="${n.due}">⏱ ${leftText(n.due)}</span></div>
      ${n.status === 'penalty' ? '<div class="tiny muted">Penalty accepted: write your statement below.</div>' : n.status === 'pleading' ? '<div class="tiny muted">Write your plea below. The officer will rule on it.</div>' : ''}
      <div class="tbtns">${n.status !== 'penalty' ? `<button class="btn small" data-act="notice" data-a="pay" data-id="${n.id}">💸 Pay ${n.fine} karma</button><button class="btn ghost small" data-act="notice" data-a="penalty" data-id="${n.id}">📝 Accept penalty</button>${n.heard ? '' : `<button class="btn ghost small" data-act="notice" data-a="plead" data-id="${n.id}">🙏 Plead</button>`}` : ''}</div>`
      : `<div class="small">${done}</div>`}${n.verdict ? `<div class="tiny muted">Hearing: ${esc(n.verdict)}</div>` : ''}</div>`;
}
setInterval(() => { $$('[data-due]').forEach(el => { el.textContent = '⏱ ' + leftText(Number(el.dataset.due)); }); }, 30000);
const threadSig = t => t.messages.length + ':' + (t.messages[t.messages.length - 1]?.id || '') + ':' + t.typing + ':' + t.messages.map(m => (m.task ? m.task.status + (m.task.extendDecided || '') + (m.task.extendAsked ? 1 : 0) : '') + (m.notice ? m.notice.status + m.notice.fine : '') + (m.contract ? m.contract.status : '')).join('');

async function updateThread() {
  if (S.view !== 'thread' || !$('#chat') || S.threadBusy) return;
  S.threadBusy = true;
  try {
    const t = await api('/thread/' + encodeURIComponent(S.threadId));
    const sig = threadSig(t);
    if (sig === S.threadSig) return;
    const stick = nearBottom();
    S.threadSig = sig;
    $('#chat').innerHTML = chatBubbles(t);
    checkTrigger(t);
    const st = $('#chatStatus');
    if (st) st.textContent = t.typing ? 'typing…' : t.kind === 'mod' ? 'moderators' : t.online ? 'online' : 'direct message';
    if (stick) window.scrollTo(0, document.body.scrollHeight);
  } catch {} finally { S.threadBusy = false; }
}

// her trigger word in a fresh message drops you into a short trance (once per message)
function checkTrigger(t) {
  const m = [...t.messages].reverse().find(x => x.trigger && !x.mine && Date.now() - x.created < 20 * 60e3);
  if (!m) return;
  S.seenTrig = S.seenTrig || new Set();
  let seen = [];
  try { seen = JSON.parse(localStorage.getItem('seenTrig') || '[]'); } catch {}
  if (S.seenTrig.has(m.id) || seen.includes(m.id)) return;
  S.seenTrig.add(m.id);
  try { localStorage.setItem('seenTrig', JSON.stringify([...seen, m.id].slice(-50))); } catch {}
  miniTrance(m);
}
async function viewThread(id) {
  const t = await api('/thread/' + encodeURIComponent(id));
  S.threadId = id;
  S.threadSig = threadSig(t);
  const isMod = t.kind === 'mod', isGroup = t.kind === 'group';
  const canSend = !t.deleted && !t.blocked && (!isGroup || t.meIn);
  const bubbles = chatBubbles(t);
  clearInterval(S.threadTimer);
  S.threadTimer = setInterval(() => { if (S.view === 'thread' && !document.hidden) updateThread(); else if (S.view !== 'thread') clearInterval(S.threadTimer); }, 2000);
  setTimeout(() => checkTrigger(t), 600);
  main.innerHTML = `<div class="narrow"><div class="chathead"><a class="back" href="#/inbox/${isMod ? 'modmail' : 'messages'}" aria-label="Back to inbox">${I.back}</a>
      ${isMod ? '<div class="nitem" style="padding:0;border:0;background:none"><div class="ic mod">🛡</div></div>' : isGroup ? `<div class="nitem" style="padding:0;border:0;background:none"><div class="ic site" style="font-size:20px">${t.gtype === 'domme' ? '👑' : t.gtype === 'mafia' ? '🕴️' : t.gtype === 'cuck' ? '🤤' : t.gtype === 'sissyshow' ? '🎀' : '👥'}</div></div>` : avatar(t.deleted ? '[deleted]' : t.name, 40)}
      <div class="who grow"><b>${isMod || isGroup ? esc(t.name) : t.deleted ? '[deleted]' : 'u/' + esc(t.name)}</b><span class="tiny muted" id="chatStatus">${isGroup ? `${t.members.length} members${t.gtype === 'domme' ? ` · obedience ${t.score >= 0 ? '+' : ''}${t.score}${t.paused ? ' · paused' : ''}` : t.gtype === 'mafia' ? ` · ${t.dead ? 'debt cleared' : `debt: ${t.debt} task${t.debt === 1 ? '' : 's'}`}${t.paused ? ' · paused' : ''}` : ''}` : t.typing ? 'typing…' : isMod ? 'moderators' : t.online ? 'online' : 'direct message'}</span></div>
      ${isGroup ? (t.meIn ? `<button class="linkbtn" data-act="leaveGroup" data-id="${esc(id)}">Leave</button>` : '') : !isMod && !t.deleted ? `<a class="linkbtn" href="#/u/${encodeURIComponent(t.name)}">Profile</a>` : ''}</div>
    ${isGroup ? `<div class="tiny muted" style="margin:-4px 0 8px">${t.members.map(m => `<a href="#/u/${encodeURIComponent(m)}">u/${esc(m)}</a>`).join(', ')}</div>` : ''}
    <div class="chat" id="chat">${bubbles}</div>
    ${isGroup && !t.meIn ? '<div class="empty small">You left this group.</div>' : t.deleted ? '<div class="empty small">This account has been deleted.</div>' : t.blocked ? '<div class="empty small">You blocked this user.</div>' : `
    <div id="dmprev"></div>
    <div class="chatbar">${!isMod ? `<label class="attach" title="Send a photo"><input type="file" id="dmimg" accept="image/*" hidden>${I.camera}</label>` : ''}
      <textarea id="dmText" placeholder="Message" rows="1"></textarea><button class="btn" data-act="sendDM" data-to="${esc(id)}">Send</button></div><div class="chatpad"></div>`}</div>`;
  if (canSend && $('#dmimg')) {
    S.dmImage = null;
    $('#dmimg').onchange = async e => {
      const f = e.target.files[0];
      if (!f) return;
      $('#dmprev').innerHTML = '<div class="small muted">Preparing…</div>';
      try {
        S.dmImage = await prepareMedia(f, pc => { $('#dmprev').innerHTML = `<div class="small muted">Uploading… ${Math.round(pc * 100)}%</div>`; });
        const m = S.dmImage;
        $('#dmprev').innerHTML = `<div class="row small muted">${m.kind === 'video' ? `<video src="${m.preview}" muted style="height:60px;border-radius:6px"></video>` : `<img src="${m.preview || m.image}" style="height:60px;border-radius:6px">`} ${m.kind === 'image' ? 'Photo' : m.kind === 'gif' ? 'GIF' : 'Video'} attached <button class="linkbtn" data-act="rmDmImg">✕</button></div>`;
      }
      catch (err) { toast(err.message, 1); }
    };
  }
  window.scrollTo(0, document.body.scrollHeight);
  S.version = 0; // reading marks things read; resync badge on next poll
}

// ---------- profiles ----------
async function viewUser(name, tab) {
  const u = await api('/u/' + encodeURIComponent(name));
  if (u.deleted) { main.innerHTML = '<div class="empty">This account has been deleted.</div>'; return; }
  tab = tab || 'posts';
  const base = `#/u/${encodeURIComponent(u.username)}`;
  let extra = '';
  if (u.me) {
    const bans = u.bans.map(b => `<div class="banbox">Banned from r/${esc(b.sub)} ${b.until ? 'until ' + new Date(b.until).toLocaleString() : 'permanently'}: ${esc(b.reason)} · <a href="#/dm/mod:${b.sub}"><u>Appeal</u></a></div>`).join('');
    const warns = Object.entries(u.warnings).filter(([, n]) => n).map(([s, n]) => `r/${esc(s)}: ${n}`).join(', ');
    const st = u.standing;
    const stLabel = { good: '✅ Good standing', 'ok-strikes': '🟡 1 recent strike', warning: '🟠 Warning: one more strike this week means a suspension', suspended: '⛔ Suspended' }[st.state];
    const standingCard = `<div class="card"><h2>Account standing</h2><div class="small" style="color:var(--text2)">${stLabel}${st.suspendedUntil ? ` until ${new Date(st.suspendedUntil).toLocaleString()} (${esc(st.suspendReason)}) · <a href="#/dm/${st.safetyId}"><u>Appeal</u></a>` : ''}</div>
      ${st.strikes.length ? `<details style="margin-top:6px"><summary class="small muted">${st.recent} strike${st.recent === 1 ? '' : 's'} in the last 7 days</summary>${st.strikes.map(x => `<div class="tiny muted" style="margin-top:4px">${ago(x.at)} · r/${esc(x.sub || '?')}: ${esc(x.reason)}</div>`).join('')}</details>` : ''}
      ${st.drama.length ? `<div class="small" style="margin-top:8px;color:var(--warn)">😠 Drama with ${st.drama.map(x => 'u/' + esc(x.username)).join(', ')}. An apology in DMs might calm it down.</div>` : ''}</div>`;
    extra = standingCard + bans + (warns ? `<div class="warnbar">Warnings: ${warns}</div>` : '');
  }
  const posts = u.posts.length ? u.posts.map(p => postCard(p)).join('') : '<div class="empty">No posts.</div>';
  const comments = u.comments.length ? `<div class="list">${u.comments.map(c => `<a class="nitem" href="#/post/${c.postId}/${c.id}"><div class="grow"><div class="tiny muted">on "${esc(c.postTitle || '')}" · ${ago(c.created)} · ${fmtN(c.score)} points${c.removed ? ' · <span class="danger-text">removed</span>' : ''}</div><div class="small">${md(c.body)}</div></div></a>`).join('')}</div>` : '<div class="empty">No comments.</div>';
  main.innerHTML = `<div class="narrow"><div class="profile-card"><div class="banner" style="background:${subColor(u.username)}"></div><div class="inner">
    <div class="row" style="align-items:flex-end">${avatar(u.username, 84)}<span class="grow"></span>${u.me ? '<a class="btn ghost small" href="#/settings">Settings</a>' : `<a class="btn small" href="#/dm/${u.id}">Message</a><button class="btn ghost small" data-act="block" data-id="${u.id}" data-on="${u.blocked ? 0 : 1}">${u.blocked ? 'Unblock' : 'Block'}</button>`}</div>
    <h1>u/${esc(u.username)}</h1>
    <div class="row" style="gap:6px">${u.role === 'streamer' ? '<span class="tag star">🎥 streamer</span>' : u.fame >= 2 ? '<span class="tag star">⭐ site famous</span>' : u.fame === 1 ? '<span class="tag op">rising</span>' : ''}${u.created && Date.now() - u.created < 3 * 864e5 ? '<span class="tag you">new here</span>' : ''}</div>
    ${u.about ? `<div class="small" style="color:var(--text2);margin-top:6px">${esc(u.about)}</div>` : ''}
    <div class="stats"><span class="stat"><b>${fmtN(u.karma)}</b><span class="muted tiny">karma</span></span>${u.followers ? `<span class="stat"><b>${fmtN(u.followers)}</b><span class="muted tiny">followers</span></span>` : ''}<span class="stat"><b>${new Date(u.created).toLocaleDateString([], { month: 'short', year: 'numeric' })}</b><span class="muted tiny">joined</span></span>
    ${u.modOf?.length ? `<span class="stat"><b>${u.modOf.length}</b><span class="muted tiny">mod of ${u.modOf.map(s => 'r/' + esc(s)).join(', ')}</span></span>` : ''}</div>
  </div></div>${extra}
  <div class="tabs"><a href="${base}/posts" class="${tab === 'posts' ? 'on' : ''}">Posts</a><a href="${base}/comments" class="${tab === 'comments' ? 'on' : ''}">Comments</a></div>
  ${tab === 'posts' ? `<div class="feed">${posts}</div>` : comments}</div>`;
}

// ---------- settings ----------
async function viewSettings() {
  const st = await api('/settings');
  S.settings = st;
  const provOpts = sel => st.providers.map(p => `<option value="${p.id}" ${p.id === sel ? 'selected' : ''}>${esc(p.name)}</option>`).join('');
  const im = st.image;
  const xai = Object.entries(st.presets).find(([k]) => k === 'xai');
  const sw0 = await api('/safeword');
  main.innerHTML = `<h1>Settings</h1>
  <div class="card ${sw0.hushed ? 'hushcard' : ''}"><h2>🤫 Secret safeword</h2>
    ${sw0.hushed ? `<p class="small"><b>Everything is paused by your safeword</b> since ${new Date(sw0.since).toLocaleString([], { weekday: 'short', hour: 'numeric', minute: '2-digit' })}. No tasks, deadlines, sales or punishments are running. Resume whenever you're ready: every clock picks up where it left off.</p><button class="btn small" data-act="swResume">Resume everything</button>`
      : `<p class="small muted">One private word only you know. Type it anywhere (a DM, a group, a comment, a post, a trance, a plea) and everything stops silently: no penalties, no breaches, no leaks. Nobody in the story notices. ${sw0.set ? '<b>Your safeword is set.</b>' : ''}</p>
      <div class="row"><input id="swWord" type="password" placeholder="${sw0.set ? 'change it…' : 'pick a word nobody would type'}" autocomplete="off" style="flex:1"><button class="btn small" data-act="swSet">${sw0.set ? 'Change' : 'Set'}</button>${sw0.set ? '<button class="btn ghost small" data-act="swClear">Remove</button>' : ''}</div>`}</div>
  <div class="card"><h2>AI key</h2>
    <p class="small muted">Paste your key and press <b>💸 Cheapest</b>. It picks the cheapest Grok models, tests them, and sets up vision for photos. That's all you need.</p>
    <div id="provs">${st.providers.map(p => providerRow(p)).join('') || (xai ? providerRow({ name: xai[1].name, baseUrl: xai[1].baseUrl, apiKey: '' }) : '')}</div>
    <details style="margin-top:8px"><summary class="small muted">Add another provider (backup)</summary>
      <div class="row" style="margin-top:6px">${Object.entries(st.presets).map(([k, v]) => `<button class="btn ghost small" data-act="addProv" data-k="${k}">+ ${esc(v.name)}</button>`).join('')}</div></details>
    <div class="small" style="margin-top:10px">Using: ${st.modelChain.length ? st.modelChain.map(m => `<span class="mono">${esc(m.model)}</span>`).join(' → ') : '<span class="muted">nothing yet</span>'} · Vision: ${st.vision?.model ? `<span class="mono">${esc(st.vision.model)}</span>` : '<span class="muted">off</span>'}</div>
  </div>
  <details class="card"><summary>Advanced: models, vision, image generator</summary>
  <div style="margin-top:10px"><h3>Models, in order</h3>
    <p class="small muted">The first model is used. If it fails or refuses, the next one is tried.</p>
    <div id="chain">${st.modelChain.map((m, i) => chainRow(m, i, provOpts)).join('') || '<div class="muted small">No models yet.</div>'}</div>
    <datalist id="modelList"></datalist>
    <button class="btn ghost small" style="margin-top:8px" data-act="addModel" ${st.providers.length ? '' : 'disabled'}>+ Add model</button>
  </div>
  <div><h3>Vision model</h3>
    <div class="row"><select id="vprov" style="max-width:180px"><option value="">Off</option>${provOpts(st.vision?.provider)}</select>
    <input id="vmodel" class="grow" list="modelList" placeholder="vision model id" value="${esc(st.vision?.model || '')}"><button class="linkbtn" data-act="testVision">Test</button></div>
    <div id="vstatus" class="small" style="margin-top:6px"></div>
  </div>
  <div><h3>Image generator</h3>
    <p class="small muted">Only used when your photo library has nothing for someone.</p>
    <select id="ikind">
      <option value="none" ${im.kind === 'none' ? 'selected' : ''}>Off: photo library only</option>
      <option value="sd" ${im.kind === 'sd' ? 'selected' : ''}>Local Stable Diffusion (free)</option>
      <option value="openai" ${im.kind === 'openai' ? 'selected' : ''}>OpenAI-style image API (paid)</option></select>
    <div id="ifields"></div>
  </div></details>
  <div class="row"><button class="btn" data-act="saveSettings">Save settings</button><span class="grow"></span><a class="linkbtn" href="#/admin">Admin panel →</a></div>
  <div class="card" style="margin-top:14px"><h2>Display</h2>
    <div class="switch"><span class="lbl">Blur images until tapped<small>Handy on your phone in public</small></span><input type="checkbox" id="blurT" ${blurOn() ? 'checked' : ''}></div></div>
  <div class="card"><h2>Change PIN</h2><div class="row"><input id="oldpin" type="password" inputmode="numeric" placeholder="Current PIN" style="max-width:140px"><input id="newpin" type="password" inputmode="numeric" placeholder="New PIN" style="max-width:140px"><button class="btn ghost small" data-act="changePin">Change</button></div></div>`;
  renderImageFields(im);
  $('#ikind').onchange = () => renderImageFields({ ...readImageFields(), kind: $('#ikind').value });
  $('#blurT').onchange = e => { LS.set('blur', e.target.checked); };
  $('#chain').addEventListener('focusin', e => { if (e.target.matches('input[data-f=model]')) loadModelList(e.target.closest('.chainrow').querySelector('select').value); });
  $('#vmodel').addEventListener('focus', () => { if ($('#vprov').value) loadModelList($('#vprov').value); });
  $('#provs').addEventListener('input', e => { if (e.target.matches('[data-f=name]')) refreshProvSelects(); });
}
const newId = () => 'pr' + Math.random().toString(36).slice(2, 12);
function providerRow(p) {
  return `<div class="card provrow" data-id="${p.id || newId()}" style="background:var(--surface2)">
    <div class="row"><input data-f="name" value="${esc(p.name)}" style="max-width:160px" placeholder="Name"><input data-f="baseUrl" class="grow" value="${esc(p.baseUrl)}" placeholder="https://…/v1"></div>
    <div class="row" style="margin-top:6px"><input data-f="apiKey" class="grow" type="password" value="${esc(p.apiKey)}" placeholder="API key (blank for local Ollama)"><button class="btn small" data-act="connectProv">Connect</button><button class="btn ghost small" data-act="connectProv" data-cheap="1" title="Switch this provider to its cheapest good models">💸 Cheapest</button><button class="linkbtn" data-act="rmRow">Remove</button></div>
    <div class="provstatus small" style="margin-top:6px"></div></div>`;
}
function chainRow(m, i, provOpts) {
  return `<div class="row chainrow" style="margin-bottom:6px"><span class="muted small" style="width:18px">${i + 1}.</span>
    <select data-f="provider" style="max-width:150px">${provOpts(m.provider)}</select>
    <input data-f="model" class="grow" list="modelList" value="${esc(m.model)}" placeholder="model id">
    <button class="linkbtn" data-act="testModel">Test</button><button class="linkbtn" data-act="moveUp">↑</button><button class="linkbtn" data-act="rmRow">✕</button></div>`;
}
function currentProviders() {
  return $$('.provrow').map(r => ({ id: r.dataset.id, name: $('[data-f=name]', r).value || 'Provider' }));
}
function refreshProvSelects() {
  const ps = currentProviders();
  const fill = (sel, extra = '') => { const v = sel.value; sel.innerHTML = extra + ps.map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join(''); if (ps.some(p => p.id === v) || (extra && !v)) sel.value = v; };
  $$('.chainrow select[data-f=provider]').forEach(sel => fill(sel));
  if ($('#vprov')) fill($('#vprov'), '<option value="">Off</option>');
  const add = $('[data-act=addModel]');
  if (add) add.disabled = !ps.length;
}
const modelCache = {};
async function loadModelList(pid) {
  if (!pid || pid === 'new') return;
  if (!modelCache[pid]) { try { modelCache[pid] = (await api('/models', { provider: pid })).models; } catch { modelCache[pid] = []; } }
  $('#modelList').innerHTML = modelCache[pid].map(m => `<option value="${esc(m)}">`).join('');
}
function renderImageFields(im) {
  const k = im.kind;
  if (k === 'none') { $('#ifields').innerHTML = ''; return; }
  const sd = k === 'sd';
  $('#ifields').innerHTML = `
    <label>${sd ? 'Web UI address (start it with the --api flag)' : 'API base URL'}</label><input data-i="baseUrl" value="${esc(im.baseUrl || (sd ? 'http://127.0.0.1:7860' : ''))}" placeholder="${sd ? 'http://127.0.0.1:7860' : 'https://api.together.xyz/v1'}">
    ${sd ? '' : `<label>API key</label><input data-i="apiKey" type="password" value="${esc(im.apiKey || '')}">`}
    <label>${sd ? 'Checkpoint (optional, blank = whatever is loaded)' : 'Model'}</label><input data-i="model" value="${esc(im.model || '')}" placeholder="${sd ? 'e.g. realisticVisionV60' : 'e.g. black-forest-labs/FLUX.1-schnell'}">
    <div class="row"><div class="grow"><label>Size</label><input data-i="size" value="${esc(im.size || (sd ? '768x1024' : '1024x1024'))}"></div>
    ${sd ? `<div class="grow"><label>Steps</label><input data-i="steps" type="number" value="${im.steps || 25}"></div><div class="grow"><label>CFG</label><input data-i="cfg" type="number" step="0.5" value="${im.cfg || 6}"></div>` : ''}
    <div class="grow"><label>Max images / hour</label><input data-i="maxPerHour" type="number" value="${im.maxPerHour || 30}"></div></div>
    ${sd ? `<label>Sampler (optional)</label><input data-i="sampler" value="${esc(im.sampler || '')}" placeholder="e.g. DPM++ 2M Karras">` : ''}
    <div class="row" style="margin-top:10px"><button class="btn ghost small" data-act="testImage">Save & generate a test image</button></div><div id="itest"></div>`;
}
function readImageFields() {
  const o = { kind: $('#ikind').value };
  $$('[data-i]').forEach(el => { o[el.dataset.i] = el.value; });
  return o;
}
function collectSettings() {
  const providers = $$('.provrow').map(r => ({ id: r.dataset.id || undefined, name: $('[data-f=name]', r).value, baseUrl: $('[data-f=baseUrl]', r).value, apiKey: $('[data-f=apiKey]', r).value }));
  const modelChain = $$('.chainrow').map(r => ({ provider: $('[data-f=provider]', r).value, model: $('[data-f=model]', r).value }));
  return { providers, modelChain, image: readImageFields(), vision: { provider: $('#vprov').value, model: $('#vmodel').value } };
}

// ---------- admin ----------
async function viewAdmin(tab, sub) {
  const tabs = [['sim', 'Controls'], ['library', 'Photos'], ['pfp', 'Profile pics'], ['personas', 'People'], ['prompts', 'Prompts']];
  const more = [['history', 'History'], ['subs', 'Subs'], ['me', 'My account'], ['log', 'AI log']];
  const head = `<h1>Admin <span class="tag mod">only you</span></h1><div class="tabs">${tabs.map(([k, l]) => `<a href="#/admin/${k}" class="${k === tab ? 'on' : ''}">${l}</a>`).join('')}
    <span class="grow"></span>${more.map(([k, l]) => `<a href="#/admin/${k}" class="${k === tab ? 'on' : ''}" style="font-weight:500;font-size:13px">${l}</a>`).join('')}</div>`;
  const fn = { pfp: adminPfp, history: adminHistory, sim: adminSim, library: adminLibrary, prompts: adminPrompts, personas: adminPersonas, subs: adminSubs, me: adminMe, log: adminLog }[tab] || adminSim;
  main.innerHTML = head + '<div id="adm"><div class="loading">Loading…</div></div>';
  await fn(sub);
}
const sw = (key, label, hint, on) => `<div class="switch"><span class="lbl">${label}${hint ? `<small>${hint}</small>` : ''}</span><input type="checkbox" data-cfg="${key}" ${on ? 'checked' : ''}></div>`;
const numRow = (key, label, hint, val, attrs = '') => `<div class="switch"><span class="lbl">${label}${hint ? `<small>${hint}</small>` : ''}</span><input type="number" data-cfg="${key}" value="${val}" ${attrs}></div>`;
const selRow = (key, label, hint, val, opts) => `<div class="switch"><span class="lbl">${label}${hint ? `<small>${hint}</small>` : ''}</span><select data-cfg="${key}">${opts.map(([v, l]) => `<option value="${v}" ${String(v) === String(val) ? 'selected' : ''}>${l}</option>`).join('')}</select></div>`;

async function adminPfp() {
  const { status: st, items } = await api('/admin/avatars');
  const g = { F: 'woman', M: 'man', '': '?' };
  $('#adm').innerHTML = `<div class="card"><h2>Profile pictures</h2>
    <p class="small" style="color:var(--text2);margin-top:0">Add your AI-generated faces here and everyone gets one automatically: women get women's pictures, men get men's${st.visionReady ? ', and ages roughly match (your vision model checks each picture once)' : ''}. People without one keep a drawn avatar. New users who join later get one too.</p>
    <div class="row"><select id="pfpGender" style="max-width:190px">${st.visionReady ? '<option value="">Detect automatically</option>' : ''}<option value="F">These are women</option><option value="M">These are men</option>${st.visionReady ? '' : '<option value="">Mixed / not sure</option>'}</select>
      <label class="btn small" style="margin:0"><input type="file" id="pfpFiles" accept="image/*" multiple hidden>Upload pictures</label></div>
    <div id="pfpStatus" class="small muted" style="margin-top:6px"></div>
    <details style="margin-top:8px"><summary class="small muted">Have hundreds? Use the folder</summary>
      <div class="small muted" style="margin-top:6px">Copy them into <span class="mono">${esc(st.dir)}</span>. Put women's in a <span class="mono">women</span> subfolder and men's in <span class="mono">men</span> (or leave them loose${st.visionReady ? ' and they\'re detected' : ''}). Then press Scan.</div>
      <button class="btn ghost small" style="margin-top:8px" data-act="pfpScan">Scan folder</button></details>
  </div>
  <div class="card">
    <div class="admin-grid">
      <div class="kv"><b>${st.total}</b><span class="tiny muted">pictures (${st.women} women, ${st.men} men)</span></div>
      <div class="kv"><b>${st.peopleWith}/${st.people}</b><span class="tiny muted">users with a picture</span></div>
      <div class="kv"><b>${st.free}</b><span class="tiny muted">unused pictures</span></div>
      <div class="kv"><b>${st.womenWithout}</b><span class="tiny muted">women still without one${st.menWithout ? `, ${st.menWithout} men` : ''}</span></div>
    </div>
    ${st.unchecked ? `<div class="small muted" style="margin-top:8px">Checking ${st.unchecked} new picture${st.unchecked === 1 ? '' : 's'}…</div>` : ''}
    ${st.flagged ? `<div class="small danger-text" style="margin-top:8px">${st.flagged} picture${st.flagged === 1 ? ' was' : 's were'} not used because the person looked under 18.</div>` : ''}
    ${sw('autoAvatars', 'Hand out pictures automatically', 'Gives a picture to anyone without one, including new users.', st.auto)}
    <div class="row" style="margin-top:6px"><button class="btn small" data-act="pfpAssign">Give everyone a picture now</button><button class="btn ghost small" data-act="pfpReshuffle">Reshuffle all</button><button class="linkbtn" data-act="pfpClear">Remove all from users</button></div>
  </div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(96px,1fr));gap:8px">${items.map(x => `
    <div style="text-align:center;${x.flagged ? 'opacity:.35' : ''}">
      <img src="${esc(x.url)}" loading="lazy" style="width:100%;aspect-ratio:1;object-fit:cover;border-radius:50%;background:var(--surface2)">
      <div class="tiny" style="margin-top:4px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${x.who ? 'u/' + esc(x.who) : '<span class="muted">unused</span>'}</div>
      <div class="tiny muted"><a href="#" data-act="pfpGender" data-id="${x.id}" data-g="${x.gender === 'F' ? 'M' : 'F'}" title="Tap to switch">${g[x.gender || '']}${x.age ? ' · ' + esc(x.age) : ''}</a> · <a href="#" data-act="pfpDel" data-id="${x.id}">✕</a></div>
    </div>`).join('') || '<div class="empty" style="grid-column:1/-1"><b>No pictures yet</b>Upload some above.</div>'}</div>`;
  $$('[data-cfg]', $('#adm')).forEach(el => el.addEventListener('change', async () => { await api('/admin/config', { [el.dataset.cfg]: el.checked }); toast('Saved'); }));
  $('#pfpFiles').onchange = async e => {
    const files = [...e.target.files];
    let done = 0;
    for (let i = 0; i < files.length; i += 8) {
      const batch = [];
      for (const f of files.slice(i, i + 8)) { try { batch.push({ data: await readImage(f, 512) }); } catch (err) { toast(`${f.name}: ${err.message}`, 1); } }
      try { done += (await api('/admin/avatars/upload', { files: batch, gender: $('#pfpGender').value })).added; } catch (err) { toast(err.message, 1); }
      $('#pfpStatus').textContent = `Uploaded ${done} / ${files.length}…`;
    }
    toast(`Uploaded ${done} pictures. They'll be handed out in a few seconds.`);
    adminPfp();
  };
  clearTimeout(S.pfpT);
  if (st.unchecked || (st.auto && st.free && (st.womenWithout || st.menWithout))) S.pfpT = setTimeout(() => { if (location.hash.includes('admin/pfp')) adminPfp(); }, 5000);
}

async function adminHistory() {
  const { history } = await api('/admin/history');
  const icon = { sub: '🌱', dead: '🪦', revive: '♻️', growth: '📈', fame: '⭐', users: '👥' };
  $('#adm').innerHTML = `<div class="card"><h2>How the site has changed</h2><div class="small muted">Everything the site did on its own, newest first.</div></div>
    <div class="list">${history.map(h => `<a class="nitem" ${h.link ? `href="${esc(h.link)}"` : ''}><div class="ic">${icon[h.type] || '•'}</div><div class="grow"><div class="small">${esc(h.text)}</div><div class="tiny muted">${ago(h.at)}</div></div></a>`).join('') || '<div class="empty">Nothing yet. Give it some time, or press "Evolve one step" in Controls.</div>'}</div>`;
}

async function adminSim() {
  const a = await api('/admin');
  const c = a.config, st = a.stats;
  const nw = a.news || {};
  const angry = a.threats.filter(t => t.stage >= 1 || t.hostility >= 5).length;
  $('#adm').innerHTML = `
  ${st.aiReady ? '' : '<div class="warnbar">No AI set up yet. <a href="#/settings">Add your Grok key in Settings</a>.</div>'}
  <div class="card small muted">${a.counts.posts} posts · ${a.counts.comments} comments · ${st.callsLastHour} AI calls this hour · <b style="color:var(--text)">≈ $${a.usage.cost.toFixed(2)} today</b></div>

  <div class="card"><h2>Mode</h2><div class="tiny muted" style="margin-bottom:8px">One tap sets everything below. You can still fine-tune afterwards.</div>
    <div class="presets">${[['chill', '😌 Chill', 'flirty only: no threats, auctions or ownership'], ['spicy', '🌶️ Spicy', 'dares, the Claim, some drama, the Vault'], ['brutal', '🔥 Brutal', 'everything on, extreme tasks'], ['owned', '🔒 Owned 24/7', 'agreements, deeds, keyholder, constant check-ins'], ['cuck', '🤤 Cuck', 'bulls, cuck groups, cuck tasks, trances'], ['sissy', '🎀 Sissy toy', 'sissy track, men use you, object mode, orgasm control']].map(([k, l, d]) => `<button class="preset${c.preset === k ? ' on' : ''}" data-act="preset" data-name="${k}"><b>${l}</b><span>${d}</span></button>`).join('')}</div></div>
  <div class="card collapsed" id="ctlcard"><h2>Controls</h2><button class="btn ghost small showall" data-act="showAll">Show every switch</button>
    ${sw('paused', 'Pause everything', 'Nothing posts or replies until you turn this off.', c.paused)}
    ${selRow('activity', 'How busy', '', c.activity, [[0.6, 'Quiet'], [1, 'Normal'], [1.6, 'Busy'], [2.5, 'Chaos']])}
    ${selRow('spend', 'Spending', 'Saver = cheapest. Many people just vote instead of commenting.', c.spend || 'balanced', [['saver', 'Saver'], ['balanced', 'Balanced'], ['max', 'Max chatter']])}
    ${sw('dms', 'DMs from strangers', '', c.dms)}
    ${sw('dares', 'Dares & tasks in DMs', 'People sometimes give you tasks in chat (a pic, a confession, a flirty line, "you\'re mine now" rules) and judge if you did them.', c.dares !== false)}
    ${sw('groups', 'Girls\' group chats', 'Women who know you start groups, gossip about you, and add you later. Scroll up to read what they said.', c.groups !== false)}
    <div class="row" style="margin-top:8px"><button class="btn ghost small" data-act="groupNow">👥 Start a group now</button><button class="btn ghost small" data-act="addMeNow">➕ Get added now</button><button class="btn ghost small" data-act="dommeNow">👑 Start the slave group</button><button class="btn ghost small" data-act="contractNow">📜 Get a slave agreement</button><button class="btn ghost small" data-act="breachNow">🚨 Break my agreement</button></div>
    ${sw('contracts', 'Slave agreements', 'Any of the ~56 doms (women and men) can send you one out of the blue, especially after a bounty in the Vault. Sign it and you get several tasks a day with deadlines; breaking it brings police notices, her crew, exposure and account seizure.', c.contracts !== false)}
    <div class="tiny muted" style="margin-top:4px">Slave group: a few women boss you around and give you tasks in the chat. Typing "red" or "stop" there quietly pauses it ("green" resumes); leaving the group ends it. Slave agreements: "red" in that DM cancels the agreement.</div>
    ${selRow('taskIntensity', 'How hardcore tasks are', 'For doms, owners, the slave group and the crew. Edit the wording in Prompts → Slaves, tasks & doms.', c.taskIntensity ?? 2, [[1, 'Soft'], [2, 'Hard'], [3, 'Extreme']])}
    ${sw('strangers', 'Burners & rude strangers in DMs', 'Anonymous accounts and people who can\'t stand you message you out of nowhere: insults, demands, ultimatums with a 6-hour deadline.', c.strangers !== false)}
    ${selRow('strangersPerDay', 'How many a day', '', c.strangersPerDay ?? 4, [[2, '2'], [4, '4'], [8, '8'], [14, '14']])}
    ${sw('claims', '🔨 The Claim (body auction)', 'Every 12 hours your body is auctioned spot by spot; winners\' names get written on you, with photo check-ins. Bids are play money.', c.claims !== false)}
    ${sw('naming', '🏷️ Naming rights', 'Doms bid to rename you for 24 hours; the whole site calls you that.', c.naming !== false)}
    ${sw('keyholder', '🔑 Keyholder', 'A dom buys the right to decide when you finish (3 days). Ask permission, keep the streak, others bet on you.', c.keyholder !== false)}
    ${sw('cuck', '🤤 Cuck mode', 'Doms get bulls (fictional AI men). Stories, comparisons, cuck tasks, a group where you\'re the joke.', c.cuck === true)}
    ${selRow('cuckPerDay', 'Cuck moments a day', '', c.cuckPerDay ?? 4, [[2, '2'], [4, '4'], [6, '6'], [10, '10']])}
    ${sw('rateHim', '📏 r/RateHim', 'Doms-only sub that keeps demanding pics of your shaft and balls, then rates and humiliates them.', c.rateHim !== false)}
    ${selRow('rateDemands', 'Demands a day', '', c.rateDemands ?? 4, [[2, '2'], [4, '4'], [6, '6'], [10, '10']])}
    ${sw('sissy', '🎀 Sissy mode', 'Your wardrobe, daily dress orders and night checks, training, a sissy name and level.', c.sissy === true)}
    ${sw('sissyMen', '💦 Men use the sissy', 'Male doms use you, sometimes finish on you (stand-ins + proof); watched groups and bukkake nights.', c.sissyMen !== false)}
    <div class="spotrow"><b>Sissy training tasks</b><small class="muted">separate with ";"</small><textarea data-cfg="sissyTasks" rows="3">${esc(c.sissyTasks ?? '')}</textarea></div>
    ${sw('objectMode', '📦 Object mode', 'The whole site treats you as an item: "it", product page, usage log, furniture duty, defect reports, clearance.', c.objectMode === true)}
    ${sw('objectMute', '🔇 Objects don\'t talk', 'You can only send approved phrases; anything else is stamped and ignored.', c.objectMute === true)}
    <div class="spotrow"><b>Approved phrases</b><small class="muted">comma-separated</small><textarea data-cfg="objectPhrases" rows="1">${esc(c.objectPhrases ?? '')}</textarea></div>
    ${sw('orgasm', '🎡 Orgasm control', 'Monthly tokens, the beg wheel, stroke sessions.', c.orgasm !== false)}
    ${selRow('orgasmsPerMonth', 'Tokens a month', '', c.orgasmsPerMonth ?? 4, [[0, '0'], [2, '2'], [4, '4'], [8, '8']])}
    <div class="row" style="margin-top:6px"><button class="btn ghost small" data-act="dressNow">🎀 Dress order now</button><button class="btn ghost small" data-act="useNow">💦 A man uses me now</button><button class="btn ghost small" data-act="finishNow">💦 Finish on me now</button><button class="btn ghost small" data-act="showNow">👀 Watched group</button><button class="btn ghost small" data-act="bukkakeNow">💦 Bukkake night</button><button class="btn ghost small" data-act="furnitureNow">🪑 Furniture duty</button></div>
    ${sw('museum', '🏛 The Museum', 'Doms curate your best and worst proof pics into public exhibits with plaques; visitors comment.', c.museum !== false)}
    <div class="spotrow"><b>Poses doms can demand</b><small class="muted">comma-separated; used in r/RateHim demands and owners' photo tasks</small><textarea data-cfg="poses" rows="3">${esc(c.poses ?? '')}</textarea></div>
    <div class="row" style="margin-top:6px"><button class="btn ghost small" data-act="museumNow">🏛 Curate an exhibit now</button><button class="btn ghost small" data-act="namingSell">🏷️ Auction my name now</button><button class="btn ghost small" data-act="keySell">🔑 Auction my key now</button><button class="btn ghost small" data-act="cuckNow">🤤 Cuck moment now</button><button class="btn ghost small" data-act="rateNow">📏 New demand now</button></div>
    ${sw('deeds', '📜 Deeds', 'Doms buy lasting ownership of these parts, set rules for them, check in with tasks, and re-auction them when they like.', c.deeds !== false)}
    <div class="spotrow"><b>Parts sold by deed + starting price (₹)</b><small class="muted">owned until resold; kept out of the 12-hour auction while owned</small><textarea data-cfg="deedParts" rows="1">${esc(c.deedParts ?? '')}</textarea></div>
    <div class="row" style="margin-top:6px"><button class="btn ghost small" data-act="deedSell">📜 Put a deed up for sale now</button><button class="btn ghost small" data-act="deedNext">⏭ Next deed-sale step</button></div>
    <div class="spotrow"><b>Spots up for auction + starting price (₹)</b><small class="muted">comma-separated, like "chest 800, hips 1500"</small><textarea data-cfg="claimSpots" rows="2">${esc(c.claimSpots ?? '')}</textarea></div>
    <div class="spotrow"><b>Intimate spots 🔥 + starting price (₹)</b><small class="muted">doms fight harder for these and bids climb higher. Leave empty to turn them off.</small><textarea data-cfg="claimBold" rows="2">${esc(c.claimBold ?? '')}</textarea></div>
    <div class="row" style="margin-top:8px"><button class="btn ghost small" data-act="claimOpen">🔨 Start / close the auction now</button><button class="btn ghost small" data-act="claimNext">⏭ Next claim step now</button><button class="btn ghost small" data-act="claimEnd">🏁 End the claim</button></div>
    ${sw('vault', '🕳 The Vault', 'The hidden anonymous board: your DMs get leaked there, bounties go up on you, and the owned list is posted.', c.vault !== false)}
    <div class="row" style="margin-top:8px"><button class="btn ghost small" data-act="strangerNow">👤 Stranger DMs me</button><button class="btn ghost small" data-act="vaultLeak">🕳 Leak my DMs</button><button class="btn ghost small" data-act="vaultBounty">💀 Bounty on me</button><button class="btn ghost small" data-act="ownedList">🔒 Post the owned list</button></div>
    ${sw('threats', 'Threats & stalkers', 'Angry users escalate from creepy to cyber-cell threats. All in-app.', c.threats)}
    <button class="btn calm" style="width:100%;margin-top:10px" data-act="calm">🕊 Calm mode: stop all threats now</button>
  </div>

  <div class="card"><h2>🌱 Site evolves on its own</h2>
    ${sw('evolve', 'Evolution on', 'New subs are born from drama and hot topics, dead subs fade, new users join, some leave, and users who blow up become famous or start streaming.', c.evolve !== false)}
    ${selRow('evolveRate', 'How fast it changes', '', c.evolveRate ?? 1, [[0.5, 'Slow'], [1, 'Normal'], [2, 'Fast'], [4, 'Wild']])}
    <div class="row" style="margin-top:8px"><button class="btn ghost small" data-act="newSubNow">🌱 Start a new sub now</button><button class="btn ghost small" data-act="evolveNow">⏩ Evolve one step</button><a class="linkbtn" href="#/admin/history">See history →</a></div>
  </div>

  <div class="card"><h2>📰 What people talk about</h2>
    ${sw('news', 'Live Indian news', `Free headlines from Google News, Times of India, NDTV, Hindustan Times and The Hindu, refreshed every 2 hours.${nw.count ? ` <b class="good-text">${nw.count} headlines loaded</b>${nw.at ? ` ${ago(nw.at)} ago` : ''}.` : ''}${nw.error ? ` <span class="danger-text">${esc(nw.error)}</span>` : ''}`, nw.on)}
    <button class="btn ghost small" data-act="newsRefresh">↻ Load news now</button>
    <label>Your own trending topics (one per line)</label>
    <textarea id="trending" placeholder="e.g. India vs Pakistan match tonight&#10;new Netflix show everyone hates&#10;Bangalore rain chaos">${esc(c.trending || '')}</textarea>
    <button class="btn ghost small" style="margin-top:6px" data-act="saveTrending">Save topics</button>
  </div>

  ${angry ? `<details class="card"><summary>😠 ${angry} user${angry === 1 ? ' is' : 's are'} angry at you</summary>
    <div class="list" style="margin-top:8px">${a.threats.sort((x, y) => y.stage - x.stage || y.hostility - x.hostility).map(t => `<div class="prow" data-act="openPersona" data-id="${t.id}">
      <span>u/${esc(t.username)} <span class="muted tiny">${t.archetype}${t.deleted ? ' · vanished' : ''}</span></span>
      <span class="tiny muted">hate <span class="bar"><i style="width:${t.hostility * 10}%"></i></span> ${t.stage >= 1 ? `<b class="danger-text">stage ${Math.floor(t.stage)}</b>` : ''}</span></div>`).join('')}</div></details>` : ''}

  <details class="card"><summary>Advanced</summary>
    ${selRow('speed', 'Time speed', 'For testing.', c.speed, [[1, 'Real time'], [10, '10×'], [60, '60×']])}
    ${numRow('dmsPerDay', 'Stranger DMs per day', '', c.dmsPerDay, 'min="0" max="50"')}
    ${numRow('maxCallsPerHour', 'Max AI calls / hour', 'Hard cost ceiling', c.maxCallsPerHour, 'min="10"')}
    ${selRow('threatIntensity', 'Threat speed', '', c.threatIntensity, [[1, 'Slow (days)'], [3, 'Normal'], [5, 'Fast (hours)']])}
    ${selRow('imagePostRate', 'Photo posts', '', c.imagePostRate, [[0, 'None'], [0.3, '30%'], [0.7, '70%'], [1, 'All']])}
    ${selRow('imageWomenShare', 'Who posts photos', '', c.imageWomenShare, [[0.5, 'Mixed'], [0.7, 'Mostly women'], [1, 'Women only'], [0.2, 'Mostly men']])}
    ${sw('dmPhotos', 'Pics in DMs', '', c.dmPhotos)}
    <div class="row" style="margin-top:10px"><select id="fpSub" style="max-width:200px">${S.subs.map(s => `<option>${esc(s.name)}</option>`).join('')}</select><button class="btn ghost small" data-act="forcePost">New AI post now</button></div>
  </details>`;
  $$('[data-cfg]', $('#adm')).forEach(el => el.addEventListener('change', async () => {
    const v = el.type === 'checkbox' ? el.checked : el.tagName === 'TEXTAREA' || el.type === 'text' ? el.value : el.tagName === 'SELECT' && isNaN(Number(el.value)) ? el.value : Number(el.value);
    try { await api('/admin/config', { [el.dataset.cfg]: v }); toast('Saved'); } catch (e) { toast(e.message, 1); }
  }));
}

function describeCard(st) {
  const pct = st.total ? Math.round((st.described / st.total) * 100) : 0;
  let line;
  if (!st.visionReady) line = '<span class="danger-text">No working vision model yet.</span> <a href="#/settings" style="text-decoration:underline">Set one up in Settings</a> and descriptions start automatically.';
  else if (!st.on) line = 'Auto-describe is off.';
  else if (st.waiting) line = `${st.running ? 'Describing now' : 'Waiting'}: ${st.waiting} photo${st.waiting === 1 ? '' : 's'} left${st.usedThisHour >= st.perHour ? ` (hourly limit of ${st.perHour} reached, continues next hour)` : ', about 1 every few seconds'}.`;
  else line = '<span class="good-text">All caught up.</span>';
  return `<div class="switch" style="padding-top:0"><span class="lbl">✨ Auto-describe photos<small>A vision model looks at each photo once, so AI users react to what's actually in it. Your own photos go first.</small></span><input type="checkbox" data-cfg-desc ${st.on ? 'checked' : ''}></div>
    <div class="small" style="margin:6px 0">${line}</div>
    <div class="row small" style="margin-bottom:8px"><span class="muted">Speed limit</span>
      <select data-desc-limit style="max-width:170px">${[[120, '120 / hour'], [300, '300 / hour'], [600, '600 / hour'], [2000, '2000 / hour'], [100000, 'No limit']].map(([v, l]) => `<option value="${v}" ${st.perHour === v ? 'selected' : ''}>${l}</option>`).join('')}${[120, 300, 600, 2000, 100000].includes(st.perHour) ? '' : `<option selected value="${st.perHour}">${st.perHour} / hour</option>`}</select>
      <select data-desc-par style="max-width:150px">${[1, 2, 3, 4].map(n => `<option value="${n}" ${st.parallel === n ? 'selected' : ''}>${n} at a time</option>`).join('')}</select></div>
    <div class="bar" style="width:100%;height:8px"><i style="width:${pct}%;background:var(--leaf)"></i></div>
    <div class="tiny muted" style="margin-top:6px">${st.described}/${st.total} described${st.failed ? ` · <b class="danger-text">${st.failed} couldn't be described</b>` : ''}${st.flagged ? ` · ${st.flagged} hidden (looked underage)` : ''}${st.needsThumb ? ` · ${st.needsThumb} too big, shrinking them in this tab` : ''}</div>
    ${st.lastError ? `<div class="tiny danger-text" style="margin-top:4px">${esc(st.lastError)}</div>` : ''}
    ${st.total ? `<button class="btn ghost small" style="margin-top:8px" data-act="libRedescribe" title="Uses one vision call per photo">🔁 Re-read all photos with the improved reader</button> ` : ''}
    ${st.failed ? '<button class="btn ghost small" style="margin-top:8px" data-act="libRetry">Retry the ones that failed</button> <span class="tiny muted">Tip: if your vision model keeps refusing, try a different one (e.g. an uncensored one on OpenRouter).</span>' : ''}`;
}
// photos over ~3.5 MB are too big for vision APIs; shrink a copy in the browser and send it back
async function makeThumbs() {
  if (S.thumbing) return;
  S.thumbing = true;
  try {
    const { items } = await api('/admin/library/needs-thumb');
    for (const it of items) {
      try {
        let data;
        if (it.type === 'video' || it.type === 'gif') data = await makeSheet(it.url, it.type);
        else {
          const blob = await (await fetch(it.url)).blob();
          data = await readImage(new File([blob], 'x', { type: blob.type || 'image/jpeg' }), 1280);
        }
        await api('/admin/library/thumb', { id: it.id, data });
      } catch {}
    }
  } finally { S.thumbing = false; }
}

async function adminLibrary() {
  const L = await api('/admin/library');
  S.lib = L;
  S.libSel = S.libSel || new Set();
  const filter = S.libFilter || 'all';
  let items = L.items;
  if (filter === 'unassigned') items = items.filter(x => !x.persona);
  if (filter === 'nodesc') items = items.filter(x => !x.desc);
  if (filter === 'hidden') items = items.filter(x => x.hidden);
  if (filter === 'failed') items = items.filter(x => x.descFailed);
  const pOpts = `<option value="">— unassigned —</option>` + L.personas.map(p => `<option value="${p.id}">u/${esc(p.username)} (${p.gender})</option>`).join('');
  $('#adm').innerHTML = `
  <div class="card"><h2>Image library</h2>
    <div class="callout">AI users post these as their own photos. One persona keeps the same face: pictures get locked to whoever posts them first, or you assign them here. <b>Only use AI-generated images, or photos of yourself or consenting adults. No real people from the internet.</b></div>
    <div class="row"><select id="upGender" style="max-width:170px"><option value="">Gender: any</option><option value="F">Woman</option><option value="M">Man</option><option value="NB">Non-binary</option></select>
    <select id="upPersona" style="max-width:220px">${pOpts}</select>
    <label class="btn small" style="margin:0;color:#fff"><input type="file" id="upFiles" accept="image/*,video/*" multiple hidden>⬆ Upload photos, GIFs, videos</label></div>
    <div id="upStatus" class="small muted" style="margin-top:6px"></div>
    <h3>Big library? Use the folder</h3>
    <div class="small muted">Copy images into <span class="mono">${esc(L.folder)}</span>, then press Scan. Each subfolder is one person and goes to one AI user. Start a folder name with <span class="mono">f_</span>, <span class="mono">m_</span> or <span class="mono">nb_</span> to set the gender, e.g. <span class="mono">f_priya</span>.</div>
    <button class="btn ghost small" data-act="libScan" style="margin-top:8px">⟳ Scan folder</button>
  </div>
  <div class="card" id="descCard">${describeCard(L.describe)}</div>
  <div class="tabs">${[['all', `All (${L.items.length})`], ['unassigned', 'Unassigned'], ['nodesc', 'No description'], ['failed', `Couldn't describe (${L.describe.failed})`], ['hidden', 'Hidden']].map(([k, l]) => `<button class="${filter === k ? 'on' : ''}" data-act="libFilter" data-f="${k}">${l}</button>`).join('')}</div>
  <div class="card" style="position:sticky;top:58px;z-index:5"><div class="row small">
    <span><b id="selN">${S.libSel.size}</b> selected</span><button class="linkbtn" data-act="libSelAll">Select all shown</button><button class="linkbtn" data-act="libSelNone">Clear</button><span class="grow"></span>
    ${L.visionReady ? '<button class="btn ghost small" data-act="libDescribe">✨ Auto-describe</button>' : '<span class="tiny muted">Set a vision model to auto-describe</span>'}
    <select id="bulkPersona" style="max-width:180px">${pOpts}</select><button class="btn ghost small" data-act="libAssign">Assign</button>
    <select id="bulkGender" style="max-width:110px"><option value="">any</option><option value="F">Woman</option><option value="M">Man</option><option value="NB">NB</option></select><button class="btn ghost small" data-act="libGender">Set gender</button>
    <button class="btn ghost small" data-act="libHide">Hide/unhide</button><button class="btn ghost small danger-text" data-act="libDelete">Delete</button></div></div>
  <div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:8px">${items.slice(0, S.libLimit || 120).map(x => `
    <div class="card" style="position:relative;padding:6px;margin:0;${S.libSel.has(x.id) ? 'outline:2px solid var(--marigold)' : ''}${x.hidden ? ';opacity:.45' : ''}">
      ${x.mediaType !== 'image' ? `<span class="mbadge" style="z-index:1">${x.mediaType === 'gif' ? 'GIF' : 'video'}</span>` : ''}<img src="${esc(x.mediaType === 'image' ? x.thumbUrl || x.url : x.mediaType === 'gif' ? x.url : x.thumbUrl || '/icon.svg')}" loading="lazy" style="width:100%;aspect-ratio:3/4;object-fit:cover;border-radius:6px;cursor:pointer" data-act="libToggle" data-id="${x.id}">
      <div class="tiny muted" style="margin-top:4px">${x.personaName ? 'u/' + esc(x.personaName) : 'unassigned'} · ${x.gender || 'any'} · used ${x.used}${x.flagged ? ' · <span class="danger-text">hidden: looked underage</span>' : ''}${x.descFailed ? ` · <span class="danger-text" title="${esc(x.descError || '')}">couldn't describe</span>` : ''}${x.needsThumb ? ' · <span class="muted">shrinking…</span>' : ''}</div>
      <textarea class="tiny" data-libdesc="${x.id}" style="min-height:54px;margin-top:4px;font-size:12px" placeholder="Describe the photo (what AI users 'see')">${esc(x.desc)}</textarea>
    </div>`).join('') || '<div class="empty">No images yet.</div>'}</div>
  ${items.length > (S.libLimit || 120) ? `<div style="text-align:center;margin:12px"><button class="btn ghost" data-act="libMore">Show more (${items.length - (S.libLimit || 120)} left)</button></div>` : ''}`;
  $('#upFiles').onchange = async e => {
    const files = [...e.target.files];
    let done = 0;
    for (let i = 0; i < files.length; i += 5) {
      const batch = [];
      for (const f of files.slice(i, i + 5)) {
        try {
          if (kindOfFile(f) === 'image') batch.push({ name: f.name, data: await readImage(f, 1600) });
          else batch.push({ name: f.name, media: (await uploadRaw(f)).path });
        } catch (err) { toast(`${f.name}: ${err.message}`, 1); }
      }
      try { await api('/admin/library/upload', { files: batch, gender: $('#upGender').value, persona: $('#upPersona').value || null }); done += batch.length; }
      catch (err) { toast(err.message, 1); }
      $('#upStatus').textContent = `Uploaded ${done} / ${files.length}…`;
    }
    toast(`Uploaded ${done} images`);
    adminLibrary();
  };
  makeThumbs();
  clearInterval(S.descTimer);
  S.descTimer = setInterval(async () => {
    if (!location.hash.includes('admin') || !$('#descCard')) return clearInterval(S.descTimer);
    try { $('#descCard').innerHTML = describeCard(await api('/admin/library/status')); } catch {}
  }, 5000);
  $$('[data-libdesc]').forEach(t => t.addEventListener('change', async () => {
    try { await api('/admin/library/update', { ids: [t.dataset.libdesc], desc: t.value }); toast('Saved'); } catch (e) { toast(e.message, 1); }
  }));
}

async function adminPrompts() {
  const { prompts, defaults, locked, guide, sections, drop } = await api('/admin/prompts');
  S.prompts = prompts;
  const field = (key, label, hint) => {
    const path = key.split('.');
    const val = path.reduce((o, k) => (o ? o[k] : undefined), prompts) ?? '';
    const def = path.reduce((o, k) => (o ? o[k] : undefined), defaults);
    return `<div class="card"><div class="row"><b class="grow">${esc(label)}</b>${def !== undefined && val !== def ? `<button class="linkbtn" data-act="resetPrompt" data-path="${key}">Reset to default</button>` : ''}</div>
      ${hint ? `<div class="tiny muted">${esc(hint)}</div>` : ''}<textarea class="prompt-area" data-path="${key}">${esc(val)}</textarea></div>`;
  };
  // custom personality types you added yourself also get a box
  const listed = new Set(guide.map(g => g.key));
  const extra = Object.keys(prompts.archetypes).filter(k => !listed.has('archetypes.' + k)).map(k => ({ key: 'archetypes.' + k, section: 'Personality types', group: null, title: k[0].toUpperCase() + k.slice(1), hint: 'Your own type' }));
  const all = [...guide, ...extra];
  const sectionHtml = sec => {
    const items = all.filter(g => g.section === sec);
    const groups = [...new Set(items.map(g => g.group).filter(Boolean))];
    const body = items.filter(g => !g.group).map(g => field(g.key, g.title, g.hint)).join('')
      + groups.map(gr => `<details class="card"><summary>${esc(gr)}</summary>${items.filter(g => g.group === gr).map(g => field(g.key, g.title, g.hint)).join('')}</details>`).join('');
    if (sec === 'Personality types' || sec === 'Advanced') return `<details class="card"><summary>${sec === 'Advanced' ? 'Advanced: post, comment, DM, photo, threat and mod templates' : 'Personality types'}</summary>${body}</details>`;
    return `<h3>${esc(sec)}</h3>${body}`;
  };
  $('#adm').innerHTML = `
  <div class="callout">Most of the time you only need the first two boxes. <b>Content style</b> sets how wild the whole site is; <b>How everyone talks</b> sets the general voice. Changes apply to the next thing generated.</div>
  <div class="card"><b>Fill them in a file</b><div class="tiny muted" style="margin:4px 0 8px">Download every prompt as one file with what each one does, its placeholders and the lines it must keep. Fill the "new" fields yourself or give the file to another AI, then import it. You can also drop the filled file into the app's data folder as <code>prompts-fill.json</code> and it's picked up within 10 seconds.</div>
    <div class="row"><a class="btn small" href="/api/admin/prompts/fillfile" download="reddish-prompts-fill.json">⬇ Download fill-in file</a><button class="btn ghost small" data-act="importPrompts">⬆ Import filled file</button><input type="file" id="promptFile" accept=".json,application/json" hidden></div>
    <div id="importResult"></div></div>
  <details class="card"><summary>🔒 Locked rules (always sent first, can't be edited)</summary><pre class="mono" style="white-space:pre-wrap">${esc(locked)}</pre></details>
  ${sections.map(sectionHtml).join('')}
  <div style="position:sticky;bottom:76px;padding:8px 0"><button class="btn" style="width:100%" data-act="savePrompts">Save all prompts</button></div>`;
  $('#promptFile').onchange = async e => {
    const f = e.target.files[0];
    if (!f) return;
    let file;
    try { file = JSON.parse(await f.text()); } catch { toast("That file isn't valid JSON", 1); return; }
    try {
      const r = await api('/admin/prompts/import', { file });
      await adminPrompts();
      $('#importResult').innerHTML = `<div class="small" style="margin-top:8px">✅ ${r.applied.length} prompt${r.applied.length === 1 ? '' : 's'} updated${r.applied.length ? `: ${r.applied.map(esc).join(', ')}` : ''}</div>
        ${r.skipped.map(x => `<div class="tiny danger-text">Skipped ${esc(x.key)}: ${esc(x.why)}</div>`).join('')}
        ${r.warnings.map(x => `<div class="tiny muted">Note on ${esc(x.key)}: ${esc(x.note)}</div>`).join('')}`;
      toast(`Imported ${r.applied.length} prompt${r.applied.length === 1 ? '' : 's'}`);
    } catch (err) { toast(err.message, 1); }
  };
}

async function adminPersonas(id) {
  const data = await api('/admin/personas');
  S.pdata = data;
  if (id) return personaEditor(data.personas.find(p => p.id === id) || { id: '', username: '', age: 24, gender: 'F', city: 'Delhi', occupation: '', archetype: 'thirsty', bio: '', style: data.styles[0], look: '', quirks: [], activeHours: [21, 4], karma: 1, custom: '', hostility: 0, attraction: 0, threatStage: 0, subs: [], modOf: [] });
  const q = (S.pq || '').toLowerCase();
  const list = data.personas.filter(p => !q || p.username.toLowerCase().includes(q) || p.archetype.includes(q) || (p.city || '').toLowerCase().includes(q));
  $('#adm').innerHTML = `<div class="row" style="margin-bottom:8px"><input id="pq" class="grow" placeholder="Search name, type, city" value="${esc(S.pq || '')}"><a class="btn small" href="#/admin/personas/new">+ New persona</a></div>
  <div class="list">${list.map(p => `<a class="prow" href="#/admin/personas/${p.id}"><span>${p.deleted ? '<s>' : ''}u/${esc(p.username)}${p.deleted ? '</s>' : ''} <span class="muted tiny">${p.age}${p.gender} · ${p.archetype} · ${esc(p.city)}${p.modOf?.length ? ' · mod' : ''}${p.blocked ? ' · blocked' : ''}</span></span>
    <span class="tiny muted"><span class="bar"><i style="width:${p.hostility * 10}%"></i></span> <span class="bar a"><i style="width:${p.attraction * 10}%"></i></span>${p.threatStage >= 1 ? ` <b class="danger-text">S${Math.floor(p.threatStage)}</b>` : ''}</span></a>`).join('')}</div>`;
  $('#pq').oninput = e => { S.pq = e.target.value; clearTimeout(S.pqT); S.pqT = setTimeout(() => adminPersonas().then(() => { const i = $('#pq'); i.focus(); i.setSelectionRange(i.value.length, i.value.length); }), 250); };
}
function personaEditor(p) {
  const d = S.pdata;
  const inp = (k, label, type = 'text', extra = '') => `<div class="grow"><label>${label}</label><input data-pf="${k}" type="${type}" value="${esc(p[k] ?? '')}" ${extra}></div>`;
  $('#adm').innerHTML = `<a class="linkbtn" href="#/admin/personas">← All personas</a>
  <div class="card"><h2>${p.id ? 'u/' + esc(p.username) : 'New persona'}</h2>
    <div class="row">${inp('username', 'Username')}${inp('age', 'Age (18+)', 'number', 'min="18"')}
      <div class="grow"><label>Gender</label><select data-pf="gender">${['F', 'M', 'NB'].map(g => `<option ${p.gender === g ? 'selected' : ''}>${g}</option>`).join('')}</select></div></div>
    <div class="row">${inp('city', 'City')}${inp('occupation', 'Job')}
      <div class="grow"><label>Personality type</label><select data-pf="archetype">${d.archetypes.map(a => `<option ${p.archetype === a ? 'selected' : ''}>${a}</option>`).join('')}</select></div></div>
    <label>Public "about" (shown on profile)</label><input data-pf="bio" value="${esc(p.bio)}">
    <label>Language</label><select data-pf="lang">${[['hinglish', 'Hinglish (Roman script)'], ['hindi', 'Hindi (देवनागरी)'], ['english', 'Indian English']].map(([v, l]) => `<option value="${v}" ${(p.lang || 'hinglish') === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
    <label>Writing style</label><input data-pf="style" value="${esc(p.style)}" list="styleList"><datalist id="styleList">${d.styles.map(s => `<option value="${esc(s)}">`).join('')}</datalist>
    <label>Quirks (comma separated)</label><input data-pf="quirks" value="${esc((p.quirks || []).join(', '))}">
    <label>Appearance (used for their AI photos)</label><textarea data-pf="look" style="min-height:60px">${esc(p.look || '')}</textarea>
    <label>Custom instructions: your extra prompt for this one user</label><textarea data-pf="custom" class="prompt-area" style="min-height:100px">${esc(p.custom || '')}</textarea>
    <div class="row">${inp('activeHours', 'Online hours (start,end · 24h)', 'text')}${inp('karma', 'Karma', 'number')}</div>
    <div class="row">${inp('hostility', 'Hostility to you (0–10)', 'number', 'min="0" max="10" step="0.5"')}${inp('attraction', 'Attraction to you (0–10)', 'number', 'min="0" max="10" step="0.5"')}${inp('threatStage', 'Threat stage (0–5)', 'number', 'min="0" max="6"')}</div>
    <label>Member of</label><div class="row small">${d.subs.map(s => `<label class="row" style="margin:0;color:var(--text)"><input type="checkbox" style="width:auto" data-sub="${s}" ${(p.subs || []).includes(s) ? 'checked' : ''}> r/${s}</label>`).join('')}</div>
    <label>Moderator of</label><div class="row small">${d.subs.map(s => `<label class="row" style="margin:0;color:var(--text)"><input type="checkbox" style="width:auto" data-mod="${s}" ${(p.modOf || []).includes(s) ? 'checked' : ''}> r/${s}</label>`).join('')}</div>
    ${(p.memory || []).length ? `<label>What they remember about you</label><ul class="small muted">${p.memory.map(m => `<li>${esc(m)}</li>`).join('')}</ul>` : ''}
    <div class="row" style="margin-top:14px"><button class="btn" data-act="savePersona" data-id="${p.id}">Save</button>
      ${p.id ? `<button class="btn ghost small" data-act="pForceDM" data-id="${p.id}">DM me now</button><button class="btn ghost small" data-act="pForcePost" data-id="${p.id}">Post now</button>
      <button class="btn ghost small danger-text" data-act="pEscalate" data-id="${p.id}">Escalate threat</button><button class="btn ghost small" data-act="pReset" data-id="${p.id}">Reset feelings</button>` : ''}</div>
  </div>`;
}
function readPersona(id) {
  const o = { id: id || undefined };
  $$('[data-pf]').forEach(el => { o[el.dataset.pf] = el.value; });
  o.quirks = o.quirks.split(',').map(s => s.trim()).filter(Boolean);
  o.activeHours = String(o.activeHours).split(',').map(Number).slice(0, 2);
  if (o.activeHours.length < 2 || o.activeHours.some(isNaN)) o.activeHours = [0, 24];
  o.subs = $$('[data-sub]').filter(x => x.checked).map(x => x.dataset.sub);
  o.modOf = $$('[data-mod]').filter(x => x.checked).map(x => x.dataset.mod);
  return o;
}

async function adminSubs(name) {
  const base = await api('/base');
  S.subs = base.subs;
  if (name) {
    const s = name === 'new' ? { name: '', title: '', description: '', tone: '', rules: ['18+ only', 'No minors, ever'], promptExtra: '', postsPerDay: 6, reportThreshold: 2 } : (await api('/admin/sub/' + encodeURIComponent(name))).sub;
    $('#adm').innerHTML = `<a class="linkbtn" href="#/admin/subs">← All subs</a><div class="card"><h2>${s.name ? 'r/' + esc(s.name) : 'New subreddit'}</h2>
      ${s.name ? '' : '<label>Name (letters, numbers, _)</label><input data-sf="name">'}
      <label>Title</label><input data-sf="title" value="${esc(s.title)}">
      <label>Description</label><textarea data-sf="description" style="min-height:60px">${esc(s.description)}</textarea>
      <label>Vibe / tone (tells AI users how to behave here)</label><input data-sf="tone" value="${esc(s.tone)}">
      <label>Rules (one per line)</label><textarea data-sf="rules">${esc(s.rules.join('\n'))}</textarea>
      <label>Extra prompt for this sub</label><textarea data-sf="promptExtra" class="prompt-area" style="min-height:80px">${esc(s.promptExtra || '')}</textarea>
      <div class="row"><div class="grow"><label>Posts per day</label><input data-sf="postsPerDay" type="number" value="${s.postsPerDay}"></div><div class="grow"><label>Reports before mod review</label><input data-sf="reportThreshold" type="number" value="${s.reportThreshold}"></div></div>
      ${s.mods ? `<div class="small muted" style="margin-top:8px">Mods: ${s.mods.map(m => 'u/' + esc(m)).join(', ')} · change them from each persona's page</div>` : ''}
      <button class="btn" style="margin-top:12px" data-act="saveSub" data-name="${esc(s.name)}">Save</button></div>`;
    return;
  }
  $('#adm').innerHTML = `<div class="row" style="margin-bottom:8px"><span class="grow"></span><a class="btn small" href="#/admin/subs/new">+ New subreddit</a></div>
  <div class="list">${S.subs.map(s => `<a class="prow" href="#/admin/subs/${s.name}"><span><b>r/${esc(s.name)}</b> <span class="muted small">${esc(s.title)}</span></span><span class="muted small">${s.members} members</span></a>`).join('')}</div>`;
}

async function adminMe() {
  const a = await api('/admin');
  const me = a.me;
  $('#adm').innerHTML = `<div class="card"><h2>u/${esc(me.username)}</h2>
    <div class="row"><label style="margin:0">Karma</label><input id="setK" type="number" value="${me.karma}" style="max-width:140px"><button class="btn ghost small" data-act="setKarma">Set</button></div>
    <h3>Bans</h3>${Object.keys(me.bans).length ? Object.entries(me.bans).map(([s, b]) => `<div class="row small" style="margin-bottom:6px"><span class="grow">r/${esc(s)}: ${b.until ? 'until ' + new Date(b.until).toLocaleString() : 'permanent'} · ${esc(b.reason)}</span><button class="btn ghost small" data-act="unban" data-sub="${s}">Lift</button></div>`).join('') + '<button class="btn ghost small" data-act="unban">Lift all bans</button>' : '<div class="muted small">No bans.</div>'}
    <h3>Warnings & removals</h3><div class="small muted">${esc(JSON.stringify(me.warnings))} · ${esc(JSON.stringify(me.removals))}</div>
    <button class="btn ghost small" style="margin-top:8px" data-act="clearWarnings">Clear warnings, removals & mutes</button></div>`;
}

async function adminLog() {
  const a = await api('/admin');
  $('#adm').innerHTML = `<div class="card"><div class="row"><h2 class="grow">Recent AI calls</h2><button class="linkbtn" data-act="refreshLog">Refresh</button></div>
    <div class="log mono">${a.log.map(l => `<div><span class="${l.ok ? 'good-text' : 'danger-text'}">${l.ok ? '✓' : '✗'}</span> ${new Date(l.at).toLocaleTimeString()} · ${esc(l.model)} · ${esc(l.tag)} · ${l.ms}ms${l.err ? `<br><span class="danger-text">${esc(l.err)}</span>` : ''}</div>`).join('') || '<div class="muted">Nothing yet.</div>'}</div></div>`;
}

// ---------- click handling ----------
let logoTaps = 0, logoT;
$('#logo').addEventListener('click', e => {
  logoTaps++;
  clearTimeout(logoT);
  logoT = setTimeout(() => { logoTaps = 0; }, 1500);
  if (logoTaps >= 5) { e.preventDefault(); logoTaps = 0; location.hash = '#/admin'; }
});

document.addEventListener('click', async e => {
  const el = e.target.closest('[data-act]');
  const card = e.target.closest('.post[data-href]');
  if (!el && card && !e.target.closest('a, button, input, textarea')) { location.hash = card.dataset.href; return; }
  if (!el) return;
  const act = el.dataset.act;
  try {
    switch (act) {
      case 'vote': {
        e.preventDefault(); e.stopPropagation();
        const box = el.closest('.vote');
        const cur = box.querySelector('.up.on') ? 1 : box.querySelector('.down.on') ? -1 : 0;
        const dir = Number(el.dataset.dir) === cur ? 0 : Number(el.dataset.dir);
        const r = await api('/vote', { kind: box.dataset.kind, id: box.dataset.id, dir });
        box.querySelector('.up').classList.toggle('on', r.myVote > 0);
        box.querySelector('.down').classList.toggle('on', r.myVote < 0);
        box.classList.toggle('is-up', r.myVote > 0);
        box.classList.toggle('is-down', r.myVote < 0);
        box.querySelector('.score').textContent = fmtN(r.score);
        box.classList.remove('pop'); void box.offsetWidth; if (r.myVote) box.classList.add('pop');
        break;
      }
      case 'unblur': if (el.classList.contains('blur')) { e.preventDefault(); e.stopPropagation(); el.classList.remove('blur'); } else if (!e.target.closest('a') && e.target.tagName !== 'VIDEO') { const c = el.closest('.post[data-href]'); if (c) location.hash = c.dataset.href; } break;
      case 'rmMedia': S.clearMedia?.(); break;
      case 'openComposer': S.composerOpen = true; $('#composer').classList.add('open'); $('#topReply').focus(); break;
      case 'closeComposer': S.composerOpen = false; $('#composer').classList.remove('open'); break;
      case 'toggleblur': LS.set('blur', !blurOn()); route(true); break;
      case 'collapse': { const c = el.closest('.cmt'); c.classList.toggle('collapsed'); el.textContent = c.classList.contains('collapsed') ? '+' : '–'; break; }
      case 'reply': {
        const slot = el.closest('.cbody').querySelector('.replyslot');
        if (slot.innerHTML) { slot.innerHTML = ''; break; }
        slot.innerHTML = `<div class="replybox"><textarea placeholder="Reply"></textarea><div class="row" style="justify-content:flex-end;margin-top:6px"><button class="linkbtn" data-act="cancelReply">Cancel</button><button class="btn small" data-act="sendReply" data-id="${el.dataset.id}">Reply</button></div></div>`;
        slot.querySelector('textarea').focus();
        break;
      }
      case 'cancelReply': el.closest('.replyslot').innerHTML = ''; break;
      case 'sendReply': case 'sendComment': {
        const ta = act === 'sendComment' ? $('#topReply') : el.closest('.replybox').querySelector('textarea');
        if (!ta.value.trim()) return;
        el.disabled = true;
        await api('/comment', { postId: S.postId, parentId: act === 'sendReply' ? el.dataset.id : null, body: ta.value });
        ta.value = '';
        S.composerOpen = false;
        await refresh();
        break;
      }
      case 'report': {
        const reason = prompt('Report reason (which rule does it break?)', 'Breaks the rules');
        if (reason === null) return;
        await api('/report', { kind: el.dataset.kind, id: el.dataset.id, reason });
        toast('Reported. The mods will look at it.');
        break;
      }
      case 'delete':
        if (!confirm('Delete this?')) return;
        await api('/delete', { kind: el.dataset.kind, id: el.dataset.id });
        toast('Deleted');
        route(true);
        break;
      case 'readAll': await api('/inbox/read', {}); route(true); break;
      case 'sendDM': {
        const ta = $('#dmText');
        if (!ta.value.trim() && !S.dmImage) return;
        el.disabled = true;
        const text = ta.value, m = S.dmImage;
        // show it right away, like a real chat app
        $('#chat .empty')?.remove();
        $('#chat').insertAdjacentHTML('beforeend', `<div class="bubble mine pending">${m ? (m.kind === 'video' ? `<video class="pimg" src="${m.preview}" muted playsinline></video>` : `<img class="pimg" src="${m.preview || m.image}">`) : ''}${text ? md(text) : ''}</div>`);
        ta.value = ''; ta.style.height = ''; S.dmImage = null; $('#dmprev').innerHTML = '';
        window.scrollTo(0, document.body.scrollHeight);
        try { const r = await api('/dm', { to: el.dataset.to, body: text, image: m?.image, media: m?.media, sheet: m?.sheet || undefined }); if (r && r.hushed) { S.hushed = true; } S.threadSig = ''; await updateThread(); }
        catch (err) { toast(err.message, 1); ta.value = text; $$('#chat .pending').forEach(x => x.remove()); }
        finally { el.disabled = false; ta.focus(); }
        break;
      }
      case 'viewOnce': {
        try {
          const r = await api('/viewonce', { id: el.dataset.id });
          const ov = document.createElement('div');
          ov.className = 'vo-overlay';
          ov.innerHTML = `${r.mediaType === 'video' ? `<video src="${esc(r.image)}" autoplay playsinline controls></video>` : `<img src="${esc(r.image)}" alt="">`}<div class="vo-hint">View once · tap anywhere to close</div>`;
          ov.onclick = () => { ov.remove(); S.threadSig = ''; updateThread(); };
          document.body.appendChild(ov);
        } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'contract': {
        const accept = el.dataset.a === '1';
        if (accept && !confirmTap(el, 'Tap again to sign')) break;
        try { await api('/contract', { id: el.dataset.id, accept }); S.threadSig = ''; await updateThread(); toast(accept ? 'Signed ✍️' : 'Declined'); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'importPrompts': $('#promptFile').click(); break;
      case 'wake': if (S.trance) S.trance(); else document.getElementById('trance')?.remove(); break;
      case 'tranceStart': {
        el.disabled = true; toast('She\'s writing your session…');
        try { const s = await api('/trance/start', { theme: el.dataset.theme }); location.hash = '#/trance/' + s.id; } catch (err) { toast(err.message, 1); el.disabled = false; }
        break;
      }
      case 'nowProof': S.picking = Date.now(); $('#nowProofFile').click(); break;
      case 'ratePhoto': {
        S.picking = Date.now();
        let inp = $('#rateFile');
        if (!inp) { inp = document.createElement('input'); inp.type = 'file'; inp.accept = 'image/*'; inp.hidden = true; inp.id = 'rateFile'; document.body.appendChild(inp); }
        inp.dataset.post = el.dataset.id;
        inp.onchange = async e => {
          const f = e.target.files[0]; if (!f) return;
          try { toast('Posting it for them…'); const r = await api('/rate/answer', { postId: inp.dataset.post, image: await readImage(f) }); S.picking = 0; toast('Posted. The ratings are coming.'); location.hash = '#/post/' + r.id; } catch (err) { toast(err.message, 1); }
        };
        inp.click();
        break;
      }
      case 'keyAsk': {
        const body = prompt('What do you want to say to her?', 'please… can I?');
        if (body === null) break;
        try { await api('/keyholder/ask', { body }); toast('Asked. Wait for her.'); route(true); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'keySlip': {
        if (!confirmTap(el, 'Tap again to confess')) break;
        try { await api('/keyholder/slip', {}); toast('Confessed. She knows.'); route(true); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'preset': {
        try { S.config = await api('/admin/preset', { name: el.dataset.name }); toast(`${el.textContent.trim()} mode on`); route(true); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'showAll': $('#ctlcard').classList.remove('collapsed'); el.remove(); break;
      case 'namingSell': case 'keySell': case 'cuckNow': case 'rateNow': case 'museumNow': {
        try { await api('/admin/action', { action: act }); toast('Done.'); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'swSet': case 'swClear': {
        try { await api('/safeword/set', { word: act === 'swClear' ? '' : $('#swWord').value }); toast(act === 'swClear' ? 'Safeword removed' : 'Safeword set. Nobody will see it.'); viewSettings(); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'swResume': await api('/safeword/resume', {}); toast('Resumed. Everything picks up where it left off.'); viewSettings(); break;
      case 'sissyName': await api('/sissy/name', { name: $('#sname').value }); viewSissy(); break;
      case 'wAdd': { const v = $('#wnew').value.trim(); if (v) { const s = await api('/sissy'); await saveWardrobe([...s.wardrobe, v]); } break; }
      case 'wQuick': { const s = await api('/sissy'); await saveWardrobe([...s.wardrobe, el.dataset.w]); break; }
      case 'wDel': { const s = await api('/sissy'); await saveWardrobe(s.wardrobe.filter(x => x !== el.dataset.w)); break; }
      case 'itemLabel': await api('/item/label', { label: $('#ilabel').value }); viewItem(); break;
      case 'begSpin': spinWheel(el); break;
      case 'edged': {
        const r = await api('/orgasm/edge', { id: S.stroke?.id }).catch(() => null);
        if (r && $('#edges')) $('#edges').textContent = r.edges;
        if (navigator.vibrate) navigator.vibrate(60);
        break;
      }
      case 'dressNow': case 'useNow': case 'finishNow': case 'showNow': case 'bukkakeNow': case 'furnitureNow': {
        try { await api('/admin/action', { action: act }); toast('Done. Check your DMs.'); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'shotZoom': e.preventDefault(); el.classList.toggle('big'); break;
      case 'doTask': {
        const box = $('#dmText');
        if (el.dataset.kind === 'photo' && $('#dmimg')) $('#dmimg').click();
        else if (box) { box.focus(); box.scrollIntoView({ block: 'center' }); }
        break;
      }
      case 'taskMore': case 'taskRefuse': {
        if (act === 'taskRefuse' && !confirmTap(el, 'Tap again to refuse')) break;
        try { await api('/task', { msgId: el.dataset.mid, action: act === 'taskMore' ? 'more' : 'refuse' }); S.threadSig = ''; await updateThread(); toast(act === 'taskMore' ? 'You begged. Wait for the answer…' : 'Refused. They won\'t like that.'); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'notice': {
        const a = el.dataset.a;
        if (a === 'pay' && !confirmTap(el, 'Tap again to pay')) break;
        try {
          await api('/notice', { id: el.dataset.id, action: a });
          S.threadSig = ''; await updateThread();
          if (a !== 'pay') { const box = $('#dmText'); if (box) { box.placeholder = a === 'plead' ? 'Write your plea to the officer…' : 'Write your apology statement (40+ words)…'; box.focus(); } }
          toast(a === 'pay' ? 'Fine paid' : a === 'plead' ? 'Write your plea below' : 'Penalty accepted');
        } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'leaveGroup': if (!confirmTap(el, 'Tap again to leave')) break; await api('/group/leave', { id: el.dataset.id }); toast('You left the group'); location.hash = '#/inbox/messages'; break;
      case 'rmDmImg': S.dmImage = null; $('#dmprev').innerHTML = ''; break;
      case 'block': await api('/block', { id: el.dataset.id, on: el.dataset.on === '1' }); toast(el.dataset.on === '1' ? 'Blocked' : 'Unblocked'); route(true); break;

      // settings
      case 'addProv': {
        const pr = S.settings.presets[el.dataset.k];
        $('#provs').insertAdjacentHTML('beforeend', providerRow({ name: pr.name, baseUrl: pr.baseUrl, apiKey: '' }));
        $('#provs .muted.small')?.remove();
        refreshProvSelects();
        $('#provs .provrow:last-child [data-f=apiKey]').focus();
        break;
      }
      case 'rmRow': el.closest('.provrow, .chainrow').remove(); refreshProvSelects(); break;
      case 'addModel': {
        const opts = currentProviders().map(p => `<option value="${p.id}">${esc(p.name)}</option>`).join('');
        $('#chain').insertAdjacentHTML('beforeend', chainRow({ provider: '', model: '' }, $$('.chainrow').length, () => opts));
        break;
      }
      case 'moveUp': { const r = el.closest('.chainrow'); if (r.previousElementSibling) r.parentNode.insertBefore(r, r.previousElementSibling); break; }
      case 'saveSettings': {
        const r = await api('/settings', collectSettings());
        S.settings = { ...S.settings, ...r };
        toast('Saved');
        await loadBase();
        viewSettings();
        break;
      }
      case 'testModel': {
        await api('/settings', collectSettings());
        const row = el.closest('.chainrow');
        el.textContent = '…';
        try {
          const r = await api('/test-model', { provider: $('[data-f=provider]', row).value, model: $('[data-f=model]', row).value });
          toast(`✓ Works: "${r.text}" in ${(r.ms / 1000).toFixed(1)}s`);
        } catch (err) { toast(err.message, 1); }
        finally { el.textContent = 'Test'; }
        break;
      }
      case 'testVision': {
        await api('/settings', collectSettings());
        $('#vstatus').innerHTML = '<span class="muted">Showing it a red square…</span>';
        try {
          const r = await api('/test-vision', { provider: $('#vprov').value, model: $('#vmodel').value });
          $('#vstatus').innerHTML = `<span class="good-text">✓ It can see. It said "${esc(r.text)}" (${(r.ms / 1000).toFixed(1)}s)</span>`;
        } catch (err) { $('#vstatus').innerHTML = `<span class="danger-text">${esc(err.message)}</span>`; }
        break;
      }
      case 'connectProv': {
        const row = el.closest('.provrow');
        const st = $('.provstatus', row);
        if (!$('[data-f=apiKey]', row).value.trim() && !/localhost|127\.0\.0\.1/.test($('[data-f=baseUrl]', row).value)) { st.innerHTML = '<span class="danger-text">Paste your API key first.</span>'; break; }
        st.innerHTML = '<span class="muted">Checking key and loading models…</span>';
        el.disabled = true;
        try {
          await api('/settings', collectSettings());
          const r = await api('/connect', { provider: row.dataset.id, cheapest: el.dataset.cheap === '1' });
          delete modelCache[row.dataset.id];
          const bits = [`✓ Key works. ${r.models} models available.`];
          if (r.addedText) bits.push(`Added <b>${esc(r.text)}</b> to your models.`);
          if (r.setVision) bits.push(`Vision: tested and set <b>${esc(r.vision)}</b> ✓`);
          else if (r.vision) bits.push(`Vision: <b>${esc(r.vision)}</b> still works ✓`);
          else bits.push(`<span class="danger-text">No model on this key could see a test image${r.visionError ? ` (${esc(r.visionError)})` : ''}. Add a provider with a vision model.</span>`);
          if (r.test) bits.push(`Test reply: "${esc(r.test.text)}".`);
          if (r.testError) bits.push(`<span class="danger-text">But the test message failed: ${esc(r.testError)}</span>`);
          const msg = bits.join(' ');
          await loadBase();
          await viewSettings();
          const again = $(`.provrow[data-id="${row.dataset.id}"] .provstatus`);
          if (again) again.innerHTML = `<span class="${r.testError ? '' : 'good-text'}">${msg}</span>`;
        } catch (err) {
          st.innerHTML = `<span class="danger-text">${esc(err.message)}</span>`;
        } finally { el.disabled = false; }
        break;
      }
      case 'testImage': {
        await api('/settings', collectSettings());
        $('#itest').innerHTML = '<div class="muted small" style="margin-top:8px">Generating… (local SD can take a minute)</div>';
        try { const r = await api('/test-image', {}); $('#itest').innerHTML = `<img src="${r.url}" class="pimg" style="max-width:260px">`; }
        catch (err) { $('#itest').innerHTML = `<div class="danger-text small" style="margin-top:8px">${esc(err.message)}</div>`; }
        break;
      }
      case 'newSubNow': el.disabled = true; el.textContent = 'Creating…'; try { await api('/admin/action', { action: 'newSubNow' }); await loadBase(); toast('A new sub was just created. Check the Subs list.'); } finally { el.disabled = false; el.textContent = '🌱 Start a new sub now'; } break;
      case 'evolveNow': el.disabled = true; try { await api('/admin/action', { action: 'evolveNow' }); await loadBase(); toast('The site moved forward one step. See History.'); } finally { el.disabled = false; } break;
      case 'newsRefresh': el.disabled = true; el.textContent = 'Loading…'; try { await api('/admin/action', { action: 'newsRefresh' }); await adminSim(); } finally { el.disabled = false; } break;
      case 'deedSell': case 'deedNext':
      case 'claimOpen': case 'claimNext': case 'claimEnd': {
        try { await api('/admin/action', { action: act }); toast('Done. Open the Claim page to watch.'); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'claimProof': S.picking = Date.now(); $('#proofFile').click(); break;
      case 'claimPause': {
        if (!confirmTap(el, 'Tap again to pause')) break;
        await api('/claim/pause', {}); toast('Paused. No penalties.'); viewClaim(); break;
      }
      case 'strangerNow': case 'vaultLeak': case 'vaultBounty': case 'ownedList': {
        try { await api('/admin/action', { action: act }); toast(act === 'strangerNow' ? 'Someone will DM you in a minute 👤' : 'Posted in r/TheVault 🕳'); } catch (err) { toast(err.message, 1); }
        break;
      }
      case 'groupNow': case 'addMeNow': case 'dommeNow': case 'contractNow': case 'breachNow': {
        try { await api('/admin/action', { action: act }); toast(act === 'groupNow' ? 'A group was started. They\'ll add you later (or tap "Get added now").' : act === 'addMeNow' ? 'You were added. Check your messages.' : act === 'contractNow' ? 'Someone sent you an agreement 📜 Check your messages.' : 'Done. Check your messages 👑'); }
        catch (err) { toast(err.message, 1); }
        break;
      }
      case 'saveTrending': await api('/admin/config', { trending: $('#trending').value }); toast('Topics saved. People will start talking about them.'); break;
      case 'changePin': await api('/pin', { old: $('#oldpin').value, pin: $('#newpin').value }); toast('PIN changed'); break;

      // admin
      case 'calm': await api('/admin/action', { action: 'calm' }); toast('Calm mode: all threats stopped and switched off'); adminSim(); break;
      case 'forcePost': await api('/admin/action', { action: 'forcePost', sub: $('#fpSub').value }); toast('Queued. Watch the sub in a moment.'); break;
      case 'backfill': await api('/admin/action', { action: 'backfill', n: 10 }); toast('Generating 10 posts…'); break;
      case 'runDue': if (confirm('Run every scheduled event now? This can be a lot of AI calls.')) { await api('/admin/action', { action: 'runDue' }); toast('Running…'); } break;
      case 'clearQueue': if (confirm('Delete every scheduled reply, DM and mod action?')) { await api('/admin/action', { action: 'clearQueue' }); adminSim(); } break;
      case 'openPersona': location.hash = '#/admin/personas/' + el.dataset.id; break;
      case 'savePersona': {
        const r = await api('/admin/persona', { persona: readPersona(el.dataset.id) });
        toast('Saved');
        location.hash = '#/admin/personas/' + r.persona.id;
        break;
      }
      case 'pForceDM': await api('/admin/action', { action: 'forceDM', pid: el.dataset.id }); toast('They\'re typing…'); break;
      case 'pForcePost': { const p = S.pdata.personas.find(x => x.id === el.dataset.id); await api('/admin/action', { action: 'forcePost', sub: p.subs[0] || S.subs[0].name, pid: p.id }); toast('Queued'); break; }
      case 'pEscalate': if (confirm('Push this user to the next threat stage now?')) { await api('/admin/action', { action: 'escalate', pid: el.dataset.id }); toast('Escalating…'); } break;
      case 'pReset': await api('/admin/action', { action: 'resetPersona', pid: el.dataset.id }); toast('Reset'); adminPersonas(el.dataset.id); break;
      case 'saveSub': {
        const o = { originalName: el.dataset.name || undefined };
        $$('[data-sf]').forEach(x => { o[x.dataset.sf] = x.value; });
        if (!o.name) o.name = el.dataset.name;
        if (o.rules) o.rules = o.rules.split('\n').map(s => s.trim()).filter(Boolean);
        await api('/admin/sub', { sub: o });
        await loadBase();
        toast('Saved');
        location.hash = '#/admin/subs';
        break;
      }
      case 'savePrompts': {
        const p = JSON.parse(JSON.stringify(S.prompts));
        $$('textarea[data-path]').forEach(t => { const path = t.dataset.path.split('.'); let o = p; path.slice(0, -1).forEach(k => { o = o[k]; }); o[path[path.length - 1]] = t.value; });
        await api('/admin/prompts', { prompts: p });
        toast('Prompts saved');
        adminPrompts();
        break;
      }
      case 'resetPrompt': {
        const { defaults } = await api('/admin/prompts');
        const path = el.dataset.path.split('.');
        const t = $(`textarea[data-path="${el.dataset.path}"]`);
        t.value = path.reduce((o, k) => o[k], defaults);
        toast('Reset. Press Save to keep it.');
        break;
      }
      case 'addArch': {
        const k = $('#newArch').value.trim().toLowerCase().replace(/[^a-z_]/g, '');
        if (!k) return;
        $$('textarea[data-path]').forEach(t => { const path = t.dataset.path.split('.'); let o = S.prompts; path.slice(0, -1).forEach(x => { o = o[x]; }); o[path[path.length - 1]] = t.value; });
        S.prompts.archetypes[k] = 'Describe this personality type…';
        await api('/admin/prompts', { prompts: S.prompts });
        adminPrompts();
        break;
      }
      case 'setKarma': await api('/admin/action', { action: 'setKarma', karma: $('#setK').value }); toast('Karma set'); break;
      case 'unban': await api('/admin/action', { action: 'unban', sub: el.dataset.sub }); toast('Ban lifted'); adminMe(); break;
      case 'clearWarnings': await api('/admin/action', { action: 'clearWarnings' }); toast('Cleared'); adminMe(); break;
      case 'refreshLog': adminLog(); break;

      // library
      case 'libFilter': S.libFilter = el.dataset.f; adminLibrary(); break;
      case 'libToggle': {
        const id = el.dataset.id;
        S.libSel.has(id) ? S.libSel.delete(id) : S.libSel.add(id);
        el.closest('.card').style.outline = S.libSel.has(id) ? '2px solid var(--marigold)' : '';
        $('#selN').textContent = S.libSel.size;
        break;
      }
      case 'libSelAll': $$('[data-act=libToggle]').forEach(i => S.libSel.add(i.dataset.id)); adminLibrary(); break;
      case 'libSelNone': S.libSel.clear(); adminLibrary(); break;
      case 'libRedescribe': if (!confirmTap(el, 'Tap again to confirm (one AI call per photo)')) break; $('#descCard').innerHTML = describeCard(await api('/admin/library/redescribe', {})); toast('Re-reading all photos in the background'); break;
      case 'libRetry': $('#descCard').innerHTML = describeCard(await api('/admin/library/retry', {})); toast('Retrying'); break;
      case 'pfpScan': { const r = await api('/admin/avatars/scan', {}); toast(`Scan done: ${r.added} new, ${r.total} total`); adminPfp(); break; }
      case 'pfpAssign': { const r = await api('/admin/avatars/assign', {}); toast(r.assigned ? `Gave pictures to ${r.assigned} users` : 'Everyone who can get a picture already has one'); adminPfp(); break; }
      case 'pfpReshuffle': if (!confirmTap(el, 'Tap again to reshuffle everyone')) break; { const r = await api('/admin/avatars/assign', { reshuffle: true }); toast(`Reshuffled: ${r.assigned} users`); adminPfp(); break; }
      case 'pfpClear': if (!confirmTap(el, 'Tap again to remove')) break; await api('/admin/avatars/clear', {}); await api('/admin/config', { autoAvatars: false }); toast('Removed. Auto hand-out is now off.'); adminPfp(); break;
      case 'pfpDel': e.preventDefault(); await api('/admin/avatars/delete', { ids: [el.dataset.id] }); adminPfp(); break;
      case 'pfpGender': e.preventDefault(); await api('/admin/avatars/gender', { id: el.dataset.id, gender: el.dataset.g }); adminPfp(); break;
      case 'libMore': S.libLimit = (S.libLimit || 120) + 240; adminLibrary(); break;
      case 'libScan': {
        const r = await api('/admin/library/scan', {});
        toast(`Scan done: ${r.added} new, ${r.removed} removed, ${r.total} total${r.skipped ? `. Skipped ${r.skipped} HEIC/other files: convert them to JPG` : ''}`, r.skipped ? 1 : 0);
        adminLibrary();
        break;
      }
      case 'libAssign': case 'libGender': case 'libHide': case 'libDelete': case 'libDescribe': {
        const ids = [...S.libSel];
        if (!ids.length) return toast('Select some images first', 1);
        if (act === 'libAssign') await api('/admin/library/update', { ids, persona: $('#bulkPersona').value || null });
        if (act === 'libGender') await api('/admin/library/update', { ids, gender: $('#bulkGender').value });
        if (act === 'libHide') { const anyShown = S.lib.items.some(x => ids.includes(x.id) && !x.hidden); await api('/admin/library/update', { ids, hidden: anyShown }); }
        if (act === 'libDelete') { if (!confirm(`Delete ${ids.length} images?`)) return; await api('/admin/library/delete', { ids }); S.libSel.clear(); }
        if (act === 'libDescribe') {
          let done = 0, flagged = 0, failed = 0, big = 0, why = '';
          el.disabled = true;
          for (let i = 0; i < ids.length; i += 3) {
            el.textContent = `Describing ${Math.min(i + 3, ids.length)}/${ids.length}…`;
            const r = await api('/admin/library/describe', { ids: ids.slice(i, i + 3) });
            done += r.done; flagged += r.flagged; failed += r.failed; big += r.tooBig; why = r.errors[0] || why;
          }
          if (big) makeThumbs();
          toast(`Described ${done}${flagged ? `, hid ${flagged} that looked underage` : ''}${big ? `, ${big} too big (shrinking, will retry)` : ''}${failed ? `, ${failed} failed: ${why}` : ''}`, failed && !done ? 1 : 0);
        } else toast('Done');
        adminLibrary();
        break;
      }
    }
  } catch (err) {
    if (err.message !== 'Login required') toast(err.message, 1);
    if (el.disabled !== undefined) el.disabled = false;
  }
});

boot();

// auto-describe on/off (the card re-renders, so listen at the document level)
document.addEventListener('change', async e => {
  if (e.target.matches('[data-desc-limit], [data-desc-par]')) {
    try {
      await api('/admin/config', e.target.matches('[data-desc-limit]') ? { maxDescribesPerHour: Number(e.target.value) } : { describeParallel: Number(e.target.value) });
      $('#descCard').innerHTML = describeCard(await api('/admin/library/status'));
      toast('Saved');
    } catch (err) { toast(err.message, 1); }
    return;
  }
  if (!e.target.matches('[data-cfg-desc]')) return;
  try {
    await api('/admin/config', { autoDescribe: e.target.checked });
    $('#descCard').innerHTML = describeCard(await api('/admin/library/status'));
    toast(e.target.checked ? 'Auto-describe on' : 'Auto-describe off');
  } catch (err) { toast(err.message, 1); }
});

// a deleted or missing image shouldn't leave a broken icon
document.addEventListener('error', e => {
  const t = e.target;
  if (t.tagName === 'IMG' && t.hasAttribute('data-av')) { t.remove(); return; } // no avatar: the letter shows
  if (t.tagName !== 'IMG' || t.dataset.broken) return;
  t.dataset.broken = '1';
  t.removeAttribute('src');
  t.alt = 'Image missing';
  t.style.minHeight = '60px';
  t.style.background = 'var(--surface2)';
}, true);

// chat box grows with what you type; Enter sends on a computer (Shift+Enter for a new line)
document.addEventListener('input', e => {
  if (e.target.id !== 'dmText') return;
  e.target.style.height = 'auto';
  e.target.style.height = Math.min(140, e.target.scrollHeight) + 'px';
});
document.addEventListener('keydown', e => {
  if (e.target.id === 'dmText' && e.key === 'Enter' && !e.shiftKey && !('ontouchstart' in window)) {
    e.preventDefault();
    document.querySelector('[data-act=sendDM]')?.click();
  }
});
